import React from 'react';
import { View } from 'react-native';
import OnboardingScreen from '@screens/Onboarding/OnboardingScreen';
import IntroScreen from '@screens/Onboarding/IntroScreen';
import { ListAppsScreen } from '@screens/Multistore';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import { NavigationContainer } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Feather';
import { createStackNavigator } from '@react-navigation/stack';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import theme from '@utils/theme';
import {
  Login,
  MultiStepForm,
  ResetPassword,
  CreateNewPassword,
  Verification
} from '@screens/Auth';
import HomeDrawerNavigator from './home/HomeDrawer';
import { HeaderText } from './Navigation.styled';

const Onboarding = createStackNavigator();

const MainNavigation = () => {
  const persistedState = useSelector((state) => state);
  const miniTutorialState = persistedState.onBoarding;
  const userIsLoggedIn = persistedState.authentication.isLoggedIn;
  // const userIsRegistered = persistedState.authentication.isRegistered;
  const skipState = miniTutorialState.skippedTutorial;
  const appLoaded = miniTutorialState.initialLoad;
  const initialRoute = 'ListAppsScreen';
  // if (skipState) {
  //   initialRoute = 'AppIntroScreen';
  // }
  // if (userIsRegistered) {
  //   initialRoute = 'SignInScreen';
  // }

  return (
    <NavigationContainer>
      {userIsLoggedIn && userIsLoggedIn !== undefined ? (
        <HomeDrawerNavigator />
      ) : (
        <OnboardingStackNavigator
          initialRoute={initialRoute}
          skipState={skipState}
          appLoaded={appLoaded}
        />
      )}
    </NavigationContainer>
  );
};

// Onboarding Stack

const stackOptions = (title, navigation) => ({
  headerTitle: <HeaderText>{title}</HeaderText>,
  headerLeft: () => (
    <View style={{ paddingHorizontal: 15 }}>
      <Icon.Button
        name="arrow-left"
        size={24}
        color={theme.colors.white}
        backgroundColor={theme.colors.none}
        onPress={() => navigation.goBack()}
      />
    </View>
  )
});

const OnboardingStackNavigator = ({ initialRoute }) => (
  <Onboarding.Navigator
    initialRouteName={initialRoute}
    screenOptions={{
      headerTintColor: theme.colors.textWhite,
      headerTitle: <HeaderText>Get Started</HeaderText>,
      headerStyle: {
        backgroundColor: theme.colors.black
      }
    }}
  >
    <Onboarding.Screen
      name="ListAppsScreen"
      component={ListAppsScreen}
      options={{ headerShown: false }}
    />
    <Onboarding.Screen
      name="AppIntroScreen"
      component={IntroScreen}
      options={({ navigation }) => ({
        headerLeft: () => (
          <View style={{ paddingHorizontal: 10 }}>
            <MIcon.Button
              name="arrow-left"
              size={24}
              backgroundColor={theme.colors.none}
              onPress={() => navigation.goBack()}
            />
          </View>
        )
      })}
    />
    <Onboarding.Screen
      options={({ navigation }) => ({
        headerLeft: () => (
          <View style={{ paddingHorizontal: 10 }}>
            <MIcon.Button
              name="arrow-left"
              size={24}
              backgroundColor={theme.colors.none}
              onPress={() => navigation.goBack()}
            />
          </View>
        )
      })}
      name="AppMiniTutorialScreen"
      component={OnboardingScreen}
    />
    <Onboarding.Screen name="SignUpScreen" component={MultiStepForm} />
    <Onboarding.Screen
      options={{ headerShown: false }}
      name="SignInScreen"
      component={Login}
    />
    <Onboarding.Screen
      options={({ navigation }) => stackOptions('Forgot Password', navigation)}
      name="ResetPassword"
      component={ResetPassword}
    />
    <Onboarding.Screen
      options={({ navigation }) => stackOptions('Verification', navigation)}
      name="Verification"
      component={Verification}
    />
    <Onboarding.Screen
      options={({ navigation }) =>
        stackOptions('Create New Password', navigation)
      }
      name="CreateNewPassword"
      component={CreateNewPassword}
    />
  </Onboarding.Navigator>
);
OnboardingStackNavigator.propTypes = {
  // skipState: PropTypes.bool.isRequired,
  // appLoaded: PropTypes.bool.isRequired,
  initialRoute: PropTypes.string.isRequired
};

export default MainNavigation;
