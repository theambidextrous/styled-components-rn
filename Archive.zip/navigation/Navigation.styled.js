import React from 'react';
import { TouchableOpacity, View } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import styled from 'styled-components/native';
import theme from '@utils/theme';

const BaseTextStyles = `
font-size: 18px;
 line-height: 22px;
  font-family: 'MarkOffcPro-Bold';
  align-items: center;
`;

export const HeaderText = styled.Text`
  ${BaseTextStyles}
`;

export const goBackHeader = () => (
  <TouchableOpacity activeOpacity={1} style={{ paddingHorizontal: 20 }}>
    <View>
      <Icon
        name="arrow-back"
        size={24}
        style={{
          color: theme.colors.textWhite
        }}
      />
    </View>
  </TouchableOpacity>
);
