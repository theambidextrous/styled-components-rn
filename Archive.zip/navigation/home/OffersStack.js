import React from 'react';
import { View } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import { useSelector } from 'react-redux';
import Icon from 'react-native-vector-icons/Feather';
import { theme, getTierHeaderColor, getTierColor } from '@utils/index';
import PropTypes from 'prop-types';
import { OffersScreen } from '@screens';
import { CartCounter } from '@components';

const OfferStack = createStackNavigator();
const StackOptions = (
  title,
  navigation,
  iconLeft,
  headerBgColor,
  color
  // navParams = null
) => ({
  headerShown: true,
  headerTransparent: !headerBgColor,
  title,
  headerStyle: {
    backgroundColor: headerBgColor || 'transparent'
  },
  headerTitleStyle: {
    fontSize: 18,
    fontWeight: 'bold',
    color,
    textTransform: 'none',
    fontFamily: 'MarkOffcPro'
  },
  headerLeft: () =>
    iconLeft && (
      <View style={{ paddingHorizontal: 15 }}>
        <Icon.Button
          name={iconLeft}
          size={24}
          color={color}
          backgroundColor={theme.colors.none}
          onPress={() => navigation.toggleDrawer()}
        />
      </View>
    ),
  headerRight: () => <CartCounter navigation={navigation} count={0} />
});
const OffersStackScreen = ({ navigation }) => {
  const userState = useSelector((state) => state);
  const { tierName } = userState.points;
  return (
    <OfferStack.Navigator initialRouteName="Offers">
      <OfferStack.Screen
        name="OfferList"
        component={OffersScreen}
        options={StackOptions(
          'Offers',
          navigation,
          'menu',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'Home', screen: 'UserWelcome' }
        )}
      />
    </OfferStack.Navigator>
  );
};
OffersStackScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

export default OffersStackScreen;
