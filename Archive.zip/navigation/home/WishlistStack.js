import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { View } from 'react-native';
import { useSelector } from 'react-redux';
import { getTierHeaderColor, getTierColor, theme } from '@utils/index';
import Icon from 'react-native-vector-icons/Feather';
import PropTypes from 'prop-types';
import { CartCounter } from '@components';
import { WishlistScreen } from '@screens';

const Stack = createStackNavigator();
const StackOptions = (
  title,
  navigation,
  iconLeft,
  headerBgColor,
  color,
  navParams = null
) => ({
  headerShown: true,
  headerTransparent: !headerBgColor,
  title,
  headerStyle: {
    backgroundColor: headerBgColor || 'transparent'
  },
  headerTitleStyle: {
    fontSize: 18,
    fontWeight: '700',
    color,
    textTransform: 'capitalize',
    fontFamily: 'MarkOffcPro'
  },
  headerLeft: () =>
    iconLeft && (
      <View style={{ paddingHorizontal: 15 }}>
        <Icon.Button
          name={iconLeft}
          size={24}
          color={color}
          backgroundColor={theme.colors.none}
          onPress={() =>
            navigation.navigate(navParams.route, { screen: navParams.screen })
          }
        />
      </View>
    ),
  headerRight: () => <CartCounter navigation={navigation} count={0} />
});
const WishlistStack = ({ navigation }) => {
  const userState = useSelector((state) => state);
  const { tierName } = userState.points;
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="MyWishlist"
        component={WishlistScreen}
        options={StackOptions(
          'My Wishlist',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'Home', screen: 'UserWelcome' }
        )}
      />
    </Stack.Navigator>
  );
};

WishlistStack.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

export default WishlistStack;
