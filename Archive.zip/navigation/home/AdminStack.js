import {
  createStackNavigator,
  TransitionPresets
} from '@react-navigation/stack';
import { AdminIndexScreen } from '@screens/index';
import { theme } from '@utils/index';
import PropTypes from 'prop-types';
import React from 'react';
import { View } from 'react-native';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';

const Stack = createStackNavigator();
const StackOptions = (
  title,
  navigation,
  iconLeft,
  headerBgColor,
  navParams = null
) => ({
  headerShown: true,
  headerTransparent: !headerBgColor,
  title,
  headerStyle: {
    backgroundColor: headerBgColor || 'transparent'
  },
  headerTitleStyle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: theme.colors.textWhite,
    fontFamily: 'MarkOffcPro'
  },
  headerLeft: () =>
    iconLeft && (
      <View style={{ paddingHorizontal: 10 }}>
        <MIcon.Button
          name={iconLeft}
          size={24}
          backgroundColor={theme.colors.none}
          onPress={() =>
            navigation.navigate(navParams.route, { screen: navParams.screen })
          }
        />
      </View>
    ),
  headerRight: () => null
});
const AdminStack = ({ navigation }) => (
  <Stack.Navigator
    initialRouteName="AdminUsers"
    screenOptions={{
      headerShown: false,
      ...TransitionPresets.SlideFromRightIOS
    }}
  >
    <Stack.Screen
      name="AdminUsers"
      component={AdminIndexScreen}
      options={StackOptions(
        'Admin User',
        navigation,
        'arrow-left',
        theme.colors.black,
        { route: 'Home', screen: 'UserWelcome' }
      )}
    />
  </Stack.Navigator>
);
AdminStack.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

export default AdminStack;
