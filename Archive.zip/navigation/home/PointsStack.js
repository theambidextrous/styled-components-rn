import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { View } from 'react-native';
import { useSelector } from 'react-redux';
import { getTierHeaderColor, getTierColor, theme } from '@utils/index';
import Icon from 'react-native-vector-icons/Feather';
import PropTypes from 'prop-types';
import { CartCounter } from '@components';
import { PointsScreen } from '@screens';

const Stack = createStackNavigator();
const StackOptions = (
  title,
  navigation,
  iconLeft,
  headerBgColor,
  color
  // navParams = null
) => ({
  headerShown: true,
  headerTransparent: !headerBgColor,
  title,
  headerStyle: {
    backgroundColor: headerBgColor || 'transparent'
  },
  headerTitleStyle: {
    fontSize: 18,
    fontWeight: '700',
    color,
    textTransform: 'capitalize',
    fontFamily: 'MarkOffcPro'
  },
  headerLeft: () =>
    iconLeft && (
      <View style={{ paddingHorizontal: 15 }}>
        <Icon.Button
          name={iconLeft}
          size={24}
          color={color}
          backgroundColor={theme.colors.none}
          onPress={() => navigation.toggleDrawer()}
        />
      </View>
    ),
  headerRight: () => <CartCounter navigation={navigation} count={0} />
});
const PointsStack = ({ navigation }) => {
  const userState = useSelector((state) => state);
  const { tierName } = userState.points;
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="MyPoints"
        component={PointsScreen}
        options={StackOptions(
          'My Points',
          navigation,
          'menu',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'Home', screen: 'UserWelcome' }
        )}
      />
    </Stack.Navigator>
  );
};

PointsStack.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

export default PointsStack;
