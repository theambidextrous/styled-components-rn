import React from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { View } from 'react-native';
import { useSelector } from 'react-redux';
import { getTierHeaderColor, getTierColor, theme } from '@utils/index';
import Icon from 'react-native-vector-icons/Feather';
import PropTypes from 'prop-types';

// Screens
import { FeedbackScreen, FeaturePreference } from '@screens/index';

const Stack = createStackNavigator();
const StackOptions = (
  title,
  navigation,
  iconLeft,
  headerBgColor,
  color,
  navParams = null
) => ({
  headerShown: true,
  headerTransparent: !headerBgColor,
  title,
  headerStyle: {
    backgroundColor: headerBgColor || 'transparent'
  },
  headerTitleStyle: {
    fontSize: 18,
    fontWeight: '700',
    color,
    textTransform: 'capitalize',
    fontFamily: 'MarkOffcPro'
  },
  headerLeft: () =>
    iconLeft && (
      <View style={{ paddingHorizontal: 15 }}>
        <Icon.Button
          name={iconLeft}
          size={24}
          color={color}
          backgroundColor={theme.colors.none}
          onPress={() =>
            navigation.navigate(navParams.route, { screen: navParams.screen })
          }
        />
      </View>
    )
  //   headerRight: () => <CartCounter navigation={navigation} count={0} />
});
const UserAccountStack = ({ navigation }) => {
  const userState = useSelector((state) => state);
  const { tierName } = userState.points;
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Feedback"
        component={FeedbackScreen}
        options={StackOptions(
          'Feedback',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'Home', screen: 'Account' }
        )}
      />
      <Stack.Screen
        name="FeaturePreference"
        component={FeaturePreference}
        options={StackOptions(
          'Features Preference',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'Home', screen: 'Account' }
        )}
      />
    </Stack.Navigator>
  );
};

UserAccountStack.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

export default UserAccountStack;
