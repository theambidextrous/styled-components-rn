import React from 'react';
import { View } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';
import Icon from 'react-native-vector-icons/Feather';

// Utils
import { getTierHeaderColor, getTierColor, theme } from '@utils/index';

// Screens
import { ProfileAccount } from '@screens/index';

const ProfileStack = createStackNavigator();
const StackOptions = (title, navigation, iconLeft, headerBgColor, color) => ({
  headerShown: true,
  headerTransparent: !headerBgColor,
  title,
  headerStyle: {
    backgroundColor: headerBgColor || 'transparent'
  },
  headerTitleStyle: {
    fontSize: 18,
    fontWeight: 'bold',
    color,
    textTransform: 'none',
    fontFamily: 'MarkOffcPro'
  },
  headerLeft: () =>
    iconLeft && (
      <View style={{ paddingHorizontal: 15 }}>
        <Icon.Button
          name={iconLeft}
          size={24}
          color={color}
          backgroundColor={theme.colors.none}
          onPress={() => navigation.toggleDrawer()}
        />
      </View>
    )
  // headerRight: () => <CartCounter navigation={navigation} count={0} />
});
const ProfileStackScreen = ({ navigation }) => {
  const userState = useSelector((state) => state);
  const { tierName } = userState.points;
  return (
    <ProfileStack.Navigator initialRouteName="Account">
      <ProfileStack.Screen
        name="Account"
        component={ProfileAccount}
        options={StackOptions(
          'Account',
          navigation,
          'menu',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'Home', screen: 'Account' }
        )}
      />
    </ProfileStack.Navigator>
  );
};
ProfileStackScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

export default ProfileStackScreen;
