export const UserItems = [
  // {
  //   label: 'My Profile',
  //   icon: 'account-outline',
  //   iconFocused: 'account',
  //   route: {
  //     route: 'Home',
  //     screen: 'UserProfile'
  //   },
  //   actAndNavigate: false,
  //   isLight: false
  // },
  {
    label: 'My Wishlist',
    icon: 'heart-outline',
    iconFocused: 'heart',
    route: {
      route: 'MyWishlist',
      screen: 'MyWishlist'
    }
  },
  {
    label: 'My Cards',
    icon: 'credit-card-outline',
    iconFocused: 'credit-card',
    route: {
      route: 'CobrandCards',
      screen: null
    },
    actAndNavigate: false,
    isLight: false
  },
  {
    label: 'Admin',
    icon: 'account-group-outline',
    iconFocused: 'account-group',
    route: {
      route: 'AdminUsers',
      screen: null
    },
    actAndNavigate: false,
    isLight: true
  },
  {
    label: 'dynamic',
    icon: 'cart-outline',
    iconFocused: 'cart',
    route: {
      route: 'Cart',
      screen: null
    },
    actAndNavigate: true,
    isLight: false
  }
];

export const MerchantItems = [
  {
    label: 'About us',
    icon: 'web',
    iconFocused: 'web'
  },
  {
    label: 'Privacy Policy',
    icon: 'text-box-multiple-outline',
    iconFocused: 'text-box-multiple'
  },
  {
    label: 'Terms and Conditions',
    icon: 'information-outline',
    iconFocused: 'information'
  }
];
