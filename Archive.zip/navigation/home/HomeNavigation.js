/* eslint-disable react/prop-types */
import React from 'react';
import { Platform } from 'react-native';
import { ifIphoneX } from 'react-native-iphone-x-helper';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import {
  createStackNavigator,
  TransitionPresets
} from '@react-navigation/stack';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import { theme, DEVICE_WIDTH } from '@utils/index';
import styled from 'styled-components/native';
import { useTheme } from 'styled-components';
import ShopStackScreen from './ShopStack';
import OffersStackScreen from './OffersStack';
import PointsStack from './PointsStack';
import ProfileStackScreen from './ProfileStack';
import { CheckoutStack, CartStack } from './TablessStacks';
import CobrandCardsStack from './CobrandCardsStack';
import WelcomeStackScreen from './WelcomStack';
import AdminStack from './AdminStack';
import WishlistStack from './WishlistStack';
import UserAccountStack from './UserAccountStack';

const Tab = createBottomTabNavigator();

const StyledTabLabel = styled.Text`
  color: ${theme.colors.black};
  font-weight: 600;
  font-size: 12px;
  font-weight: bold;
  font-family: 'MarkOffcPro';
`;
const StyledShopTabBarOuter = styled.View`
  background-color: ${(props) =>
    props.theme.colors.primary || theme.colors.primary};
  width: 52px;
  height: 52px;
  align-items: center;
  justify-content: center;
  border-radius: 51px;
  position: absolute;
  bottom: ${Platform.OS === 'ios' ? 28 : 0}px;
`;
const StyledShopTabBarInner = styled.View`
  background-color: ${(props) =>
    props.theme.colors.primary || theme.colors.primary};
  width: 47px;
  height: 47px;
  align-items: center;
  justify-content: center;
  border-radius: 40px;
  z-index: 9999999;
`;

const ShopTabBar = () => (
  <StyledShopTabBarOuter>
    <StyledShopTabBarInner>
      <MIcon name="cart-outline" color={theme.colors.textWhite} size={24} />
    </StyledShopTabBarInner>
  </StyledShopTabBarOuter>
);

const TabbedStackScreens = ({ navigation }) => {
  const shopTheme = useTheme();
  return (
    <Tab.Navigator
      initialRouteName="UserWelcome"
      sceneContainerStyle={{ backgroundColor: theme.colors.black }}
      tabBarOptions={{
        activeTintColor: shopTheme.colors.primary,
        inactiveTintColor: theme.colors.black,
        tabBarStyle: { position: 'absolute' },
        tabStyle: [
          {
            marginTop: 5
          }
        ],
        style: {
          backgroundColor: theme.colors.textWhite,
          position: 'absolute',
          padding: 10,
          elavation: 0,
          width: DEVICE_WIDTH,
          ...ifIphoneX(
            {
              height: 90
            },
            {
              height: 60
            }
          ),
          // height: 0,
          zIndex: 8
        }
      }}
    >
      <Tab.Screen
        name="UserWelcome"
        component={WelcomeStackScreen}
        options={{
          tabBarLabel: () => <StyledTabLabel>Home</StyledTabLabel>,
          tabBarIcon: ({ color }) => (
            <MIcon name="home-variant" color={color} size={25} />
          )
        }}
      />
      <Tab.Screen
        name="UserPoints"
        component={PointsStack}
        options={{
          tabBarLabel: () => <StyledTabLabel>Points</StyledTabLabel>,
          tabBarIcon: ({ color }) => (
            <MIcon name="star-circle" color={color} size={24} />
          )
        }}
      />
      <Tab.Screen
        name="MainShop"
        component={ShopStackScreen}
        options={{
          tabBarLabel: () => null,
          tabBarIcon: ({ focused, color }) => {
            if (focused) {
              return (
                <ShopTabBar
                  navigation={navigation}
                  color={theme.colors.textWhite}
                  bgColor={shopTheme.colors.primary}
                />
              );
            }
            return (
              <ShopTabBar
                nagation={navigation}
                color={color}
                bgColor={theme.colors.black}
              />
            );
          }
        }}
      />

      <Tab.Screen
        name="UserOffers"
        component={OffersStackScreen}
        options={{
          tabBarLabel: () => <StyledTabLabel>Offers</StyledTabLabel>,
          tabBarIcon: ({ color }) => (
            <MIcon name="tag" color={color} size={25} />
          )
        }}
      />
      <Tab.Screen
        name="UserProfile"
        component={ProfileStackScreen}
        options={{
          tabBarLabel: () => <StyledTabLabel>Profile</StyledTabLabel>,
          tabBarIcon: ({ color }) => (
            <MIcon name="account" color={color} size={25} />
          )
        }}
      />
    </Tab.Navigator>
  );
};

const MainStack = createStackNavigator();
const MainStackScreens = () => (
  <MainStack.Navigator
    headerMode="none"
    initialRouteName="Home"
    screenOptions={{
      headerShown: false,
      ...TransitionPresets.SlideFromRightIOS
    }}
  >
    <MainStack.Screen name="Home" component={TabbedStackScreens} />
    <MainStack.Screen name="Checkout" component={CheckoutStack} />
    <MainStack.Screen name="Cart" component={CartStack} />
    <MainStack.Screen name="CobrandCards" component={CobrandCardsStack} />
    <MainStack.Screen name="AdminUsers" component={AdminStack} />
    <MainStack.Screen name="MyWishlist" component={WishlistStack} />
    <MainStack.Screen name="UserAccountStack" component={UserAccountStack} />
  </MainStack.Navigator>
);
export { MainStackScreens, TabbedStackScreens };
