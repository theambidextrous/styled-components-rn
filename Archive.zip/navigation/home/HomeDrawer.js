/* eslint-disable react/prop-types */
import React from 'react';
import { Dimensions, Text } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import * as actions from '@stores/actions';
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItem
} from '@react-navigation/drawer';
import { theme, DEVICE_WIDTH, triggerImpactLightHaptic } from '@utils/index';
import styled from 'styled-components/native';
import { useTheme } from 'styled-components';
import { UserItems } from './DrawerItems';
import { MainStackScreens } from './HomeNavigation';

const HomeDrawer = createDrawerNavigator();
const avatar = require('@assets/images/others/avatar.png');

const HomeDrawerNavigator = () => {
  const dispatcher = useDispatch();
  const userState = useSelector((state) => state);
  const currentShop = userState.multiStore;
  const { thirdPartyShopName } = currentShop;
  const { firstName, lastName } = userState.authentication.user;
  const { tierName } = userState.points;
  const { email } = userState.authentication.session;
  /** for the sake of 3rd party shop menu */
  const { thirdPartyProduct } = userState.thirdParty;
  const handleSignOut = () => {
    dispatcher(actions.clearDemoUsers());
    dispatcher(actions.userSignedIn({}, false));
    dispatcher(actions.clearCart());
  };

  return (
    <HomeDrawer.Navigator
      screenOptions={{ gestureEnabled: true, swipeEnabled: true }}
      initialRouteName="Home"
      drawerType="back"
      defaultStatus="closed"
      backBehavior="initialRoute"
      drawerContent={(props) => (
        <CustomDrawerContent
          email={email}
          tierName={tierName}
          fullName={`${firstName} ${lastName}`}
          thirdPartyProduct={thirdPartyProduct}
          dispatcher={dispatcher}
          thirdPtyShop={thirdPartyShopName}
          handleSignOut={handleSignOut}
          {...props}
        />
      )}
      drawerStyle={{
        backgroundColor: theme.colors.background,
        width: DEVICE_WIDTH * 0.8
      }}
    >
      <HomeDrawer.Screen name="Dashboard" component={MainStackScreens} />
    </HomeDrawer.Navigator>
  );
};
const CustomDrawerContent = (props) => {
  const {
    thirdPartyProduct,
    tierName,
    fullName,
    dispatcher,
    navigation,
    thirdPtyShop,
    handleSignOut
  } = props;
  const prodSizes =
    thirdPartyProduct !== undefined &&
    Object.getOwnPropertyNames(thirdPartyProduct).length > 0
      ? thirdPartyProduct.sizes
      : [];
  const prodColors =
    thirdPartyProduct !== undefined &&
    Object.getOwnPropertyNames(thirdPartyProduct).length > 0
      ? thirdPartyProduct.colors
      : [];
  const cartEntry = {
    id: thirdPartyProduct.id,
    name: thirdPartyProduct.name,
    price: thirdPartyProduct.salePrice,
    category: thirdPartyProduct.category,
    image: thirdPartyProduct.image,
    sku: thirdPartyProduct.sku,
    quantity: 1,
    size: prodSizes.length > 1 ? prodSizes[1] : null,
    color: prodColors.length > 0 ? prodColors[0] : null,
    sizes: prodSizes,
    colors: prodColors
  };
  const shopTheme = useTheme();
  return (
    <>
      <DrawerContentScrollView showsVerticalScrollIndicator={false} {...props}>
        <DrawerItemsWrapper>
          <DrawerItemsTopContainer>
            <UserMetaWrapper>
              <UserAvatar imageStyle={{ borderRadius: 70 }} source={avatar} />
              <UserMetaName>{fullName}</UserMetaName>
              <UserMetaTier>{`${tierName} Member`}</UserMetaTier>
              {/* <UserMetaEmail>{email}</UserMetaEmail> */}
            </UserMetaWrapper>
          </DrawerItemsTopContainer>
          <DrawerItemsBottomContainer>
            <DrawerSection>
              <DrawerSectionHeader>
                <SectionHeaderText>Account</SectionHeaderText>
              </DrawerSectionHeader>
              {UserItems.map((uItem, index) => (
                <DrawerItem
                  style={{
                    margin: 0,
                    padding: 0
                  }}
                  key={String(index)}
                  label={({ color }) => (
                    <Text
                      style={{
                        color: uItem.isLight
                          ? shopTheme.colors.primary || theme.colors.primary
                          : color,
                        fontFamily: 'MarkOffcPro',
                        fontWeight: 'bold'
                      }}
                    >
                      {uItem.label === 'dynamic' ? thirdPtyShop : uItem.label}
                    </Text>
                  )}
                  icon={({ focused, color }) => (
                    <MIcon
                      color={
                        uItem.isLight
                          ? shopTheme.colors.primary || theme.colors.primary
                          : color
                      }
                      size={24}
                      name={focused ? uItem.iconFocused : uItem.icon}
                    />
                  )}
                  inactiveTintColor={theme.colors.textPrimary}
                  onPress={() => {
                    if (uItem.actAndNavigate) {
                      if (cartEntry.sku && cartEntry.sku.length > 0) {
                        /** add to cart */
                        dispatcher(actions.setIsThirdParty(true));
                        dispatcher(actions.addToCart(cartEntry));
                        navigation.navigate(uItem.route.route, {
                          screen: uItem.route.screen
                        });
                      } else {
                        navigation.closeDrawer();
                      }
                    } else {
                      navigation.navigate(uItem.route.route, {
                        screen: uItem.route.screen
                      });
                    }
                  }}
                />
              ))}
            </DrawerSection>
          </DrawerItemsBottomContainer>
        </DrawerItemsWrapper>
      </DrawerContentScrollView>
      <ButtonContainer>
        <LogOutButton
          onPress={() => {
            triggerImpactLightHaptic();
            handleSignOut();
          }}
        >
          <SignOutText>Sign out</SignOutText>
        </LogOutButton>
      </ButtonContainer>
    </>
  );
};
const DrawerItemsWrapper = styled.View`
  height: ${Dimensions.get('screen').height}px;
  padding: 0 16px;
  background-color: ${theme.colors.background};
`;
const DrawerItemsTopContainer = styled.View`
  background-color: ${theme.colors.background};
  border-bottom-color: ${theme.colors.border};
  border-bottom-width: 1px;
  padding-bottom: 28px;
  padding: 0 16px 28px 16px;
  margin-bottom: 16px;
`;
const DrawerItemsBottomContainer = styled.View`
  background-color: ${theme.colors.background};
`;

const DrawerSection = styled.View`
  /* border-bottom-color: ${theme.colors.primary};
  border-bottom-width: 1px; */
`;

const UserMetaWrapper = styled.View`
  justify-content: center;
  align-items: center;
  align-self: center;
  padding-left: 20px;
  margin-top: 24px;
`;
const UserAvatar = styled.ImageBackground`
  width: 80px;
  height: 80px;
  margin-bottom: 8px;
`;
const UserMetaName = styled.Text`
  color: ${theme.colors.textPrimary};
  margin-top: 5px;
  font-weight: bold;
  font-size: 26px;
  font-family: 'MarkOffcPro';
`;
const UserMetaTier = styled.Text`
  color: ${theme.colors.textSecondary};
  font-weight: bold;
  font-family: 'MarkOffcPro';
`;

const ButtonContainer = styled.View`
  padding: 0px 16px 32px 16px;
  justify-content: flex-end;
`;
const LogOutButton = styled.TouchableOpacity`
  border-width: 1px;
  border-color: ${theme.colors.textPrimary};
  padding: 10px;
  border-radius: 20px;
`;

const DrawerSectionHeader = styled.View`
  background-color: ${theme.colors.backgroundColor};
  justify-content: center;
  margin-bottom: 6px;
  padding: 12px 0;
`;

const SectionHeaderText = styled.Text`
  margin-left: 20px;
  font-weight: bold;
  font-size: 16px;
  font-family: 'MarkOffcPro';
  color: ${theme.colors.textPrimary};
`;
const SignOutText = styled.Text`
  font-size: 16px;
  font-weight: bold;
  font-family: 'MarkOffcPro';
  color: ${theme.colors.textPrimary};
  text-align: center;
`;

export default HomeDrawerNavigator;
