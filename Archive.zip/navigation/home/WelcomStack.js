import React from 'react';
import { View } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import { useSelector } from 'react-redux';
import Icon from 'react-native-vector-icons/Feather';
import { theme } from '@utils/index';
import PropTypes from 'prop-types';
import { WelcomeScreen } from '@screens';
import { CartCounter } from '@components';

const WelcomeStack = createStackNavigator();
const WelcomeStackScreen = ({ navigation }) => {
  const userState = useSelector((state) => state);
  const currentShop = userState.multiStore;
  const { shopName } = currentShop;
  const { tierName } = userState.points;
  const getDashboardTierColor = () => {
    if (tierName === 'Silver') {
      return theme.colors.textWhite;
    }

    return theme.colors.textBlack;
  };

  return (
    <WelcomeStack.Navigator>
      <WelcomeStack.Screen
        name="UserWelcome"
        component={WelcomeScreen}
        options={StackOptions(
          shopName,
          navigation,
          'menu',
          getDashboardTierColor()
        )}
      />
    </WelcomeStack.Navigator>
  );
};

WelcomeStackScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

const StackOptions = (title, navigation, iconLeft, color, headerBgColor) => ({
  headerShown: true,
  headerTransparent: !headerBgColor,
  title,
  headerStyle: {
    backgroundColor: headerBgColor || 'transparent'
  },
  headerTitleStyle: {
    fontSize: 18,
    fontWeight: 'bold',
    color,
    textTransform: 'uppercase',
    fontFamily: 'MarkOffcPro',
    alignSelf: 'center'
  },
  headerLeft: () =>
    iconLeft && (
      <View style={{ paddingHorizontal: 15 }}>
        <Icon.Button
          name={iconLeft}
          size={24}
          color={color}
          backgroundColor={theme.colors.none}
          onPress={() => navigation.toggleDrawer()}
        />
      </View>
    ),
  headerRight: () => (
    <CartCounter navigation={navigation} count={0} color={color} />
  )
});

export default WelcomeStackScreen;
