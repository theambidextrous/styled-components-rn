import {
  createStackNavigator,
  TransitionPresets
} from '@react-navigation/stack';
import { useSelector } from 'react-redux';
import {
  AddCardOnFile,
  CardDetailsScreen,
  CobrandCardScreen,
  CoBrandForm,
  IntroScreen
} from '@screens/index';
import { theme, getTierHeaderColor, getTierColor } from '@utils/index';
import PropTypes from 'prop-types';
import React from 'react';
import { View } from 'react-native';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';

const Stack = createStackNavigator();
const StackOptions = (
  title,
  navigation,
  iconLeft,
  headerBgColor,
  color,
  navParams = null
) => ({
  headerShown: true,
  headerTransparent: !headerBgColor,
  title,
  headerStyle: {
    backgroundColor: headerBgColor || 'transparent'
  },
  headerTitleStyle: {
    fontSize: 18,
    fontWeight: 'bold',
    color,
    fontFamily: 'MarkOffcPro'
  },
  headerLeft: () =>
    iconLeft && (
      <View style={{ paddingHorizontal: 10 }}>
        <MIcon.Button
          name={iconLeft}
          size={24}
          color={color}
          backgroundColor={theme.colors.none}
          onPress={() =>
            navigation.navigate(navParams.route, { screen: navParams.screen })
          }
        />
      </View>
    ),
  headerRight: () => null
});
const CobrandCardsStack = ({ navigation }) => {
  const persistedState = useSelector((state) => state);
  const { tierName } = persistedState.points;
  return (
    <Stack.Navigator
      initialRouteName="CobrandCards"
      screenOptions={{
        headerShown: false,
        ...TransitionPresets.SlideFromRightIOS
      }}
    >
      <Stack.Screen
        name="CobrandCards"
        component={CobrandCardScreen}
        options={StackOptions(
          'Wallet',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'Home', screen: 'UserWelcome' }
        )}
      />
      <Stack.Screen
        name="AddCardOnFile"
        component={AddCardOnFile}
        options={StackOptions(
          'Add Card',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'CobrandCards', screen: 'CobrandCards' }
        )}
      />
      <Stack.Screen
        name="CardDetails"
        component={CardDetailsScreen}
        options={StackOptions(
          'Pay with Rewards',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'CobrandCards', screen: 'CobrandCards' }
        )}
      />
      <Stack.Screen
        name="CoBrandCardBanner"
        component={IntroScreen}
        options={StackOptions(
          'Co-Brand Card',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'CobrandCards', screen: 'CobrandCards' }
        )}
      />
      <Stack.Screen
        name="AddCoBrandCard"
        component={CoBrandForm}
        options={StackOptions(
          'Co-Brand Card',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'CoBrandCardBanner', screen: 'CoBrandCardBanner' }
        )}
      />
    </Stack.Navigator>
  );
};
CobrandCardsStack.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

export default CobrandCardsStack;
