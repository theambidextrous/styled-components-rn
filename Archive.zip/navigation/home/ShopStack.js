import React from 'react';
import { View } from 'react-native';
import {
  createStackNavigator,
  TransitionPresets
} from '@react-navigation/stack';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import { theme, getTierHeaderColor, getTierColor } from '@utils/index';
import PropTypes from 'prop-types';
import { CartCounter } from '@components';
import { ShopScreen, CategoryDetailsScreen } from '@screens';
import { useSelector } from 'react-redux';

const ShopStack = createStackNavigator();
const StackOptions = (
  title,
  navigation,
  iconLeft,
  headerBgColor,
  color,
  navParams = null
) => ({
  headerShown: true,
  headerTransparent: !headerBgColor,
  title,
  headerStyle: {
    backgroundColor: headerBgColor || 'transparent'
  },
  headerTitleStyle: {
    fontSize: 18,
    fontWeight: 'bold',
    color,
    textTransform: 'capitalize',
    fontFamily: 'MarkOffcPro'
  },
  headerLeft: () =>
    iconLeft && (
      <View style={{ paddingHorizontal: 10 }}>
        <MIcon.Button
          name={iconLeft}
          size={24}
          color={color}
          backgroundColor={theme.colors.none}
          onPress={() =>
            navigation.navigate(navParams.route, { screen: navParams.screen })
          }
        />
      </View>
    ),
  headerRight: () => <CartCounter navigation={navigation} count={0} />
});
const ShopStackScreen = ({ navigation }) => {
  const persistedState = useSelector((state) => state);
  const category = persistedState.shop.category;
  const { tierName } = persistedState.points;
  return (
    <ShopStack.Navigator
      screenOptions={{
        headerShown: false,
        ...TransitionPresets.SlideFromRightIOS
      }}
    >
      <ShopStack.Screen
        name="AllCategories"
        component={ShopScreen}
        options={StackOptions(
          'Shop',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'Home', screen: 'UserWelcome' }
        )}
      />
      <ShopStack.Screen
        name="Category"
        component={CategoryDetailsScreen}
        options={StackOptions(
          category ? category.name : 'T-Shirts',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'MainShop', screen: 'AllCategories' }
        )}
      />
    </ShopStack.Navigator>
  );
};
ShopStackScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

export default ShopStackScreen;
