import React from 'react';
import { View } from 'react-native';
import {
  createStackNavigator,
  TransitionPresets
} from '@react-navigation/stack';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';

// Components
import { CartCounter } from '@components';

// Screens
import {
  ProductDetailsScreen,
  CartScreen,
  PaymentScreen,
  ConfirmationScreen,
  CheckoutPreferenceScreen
} from '@screens/index';

// Utils
import { theme, getTierHeaderColor, getTierColor } from '@utils/index';

const Stack = createStackNavigator();

const StackOptions = (
  title,
  navigation,
  iconLeft,
  headerBgColor,
  color,
  backRoute = { route: 'Cart', screen: null }
) => ({
  headerShown: true,
  headerTransparent: !headerBgColor,
  title,
  headerStyle: {
    backgroundColor: headerBgColor || 'transparent'
  },
  headerTitleStyle: {
    fontSize: 18,
    fontWeight: 'bold',
    color,
    fontFamily: 'MarkOffcPro'
  },
  headerLeft: () =>
    iconLeft && (
      <View style={{ paddingHorizontal: 10 }}>
        <MIcon.Button
          name={iconLeft}
          size={24}
          color={color}
          backgroundColor={theme.colors.none}
          onPress={() => {
            if (backRoute.screen === null) {
              navigation.goBack();
            } else {
              navigation.navigate(backRoute.route, {
                screen: backRoute.screen
              });
            }
          }}
        />
      </View>
    ),
  headerRight: () => <CartCounter navigation={navigation} count={0} />
});
const CartStack = ({ navigation }) => {
  const userState = useSelector((state) => state);
  const { isThirdParty } = userState.thirdParty;
  const { tierName } = userState.points;
  return (
    <Stack.Navigator
      initialRouteName="Cart"
      screenOptions={{ ...TransitionPresets.SlideFromRightIOS }}
    >
      <Stack.Screen
        name="Cart"
        component={CartScreen}
        options={StackOptions(
          'Bag',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          {
            route: isThirdParty ? 'Home' : 'Cart',
            screen: isThirdParty ? 'Home' : null
          }
        )}
      />
      <Stack.Screen
        name="Payment"
        component={PaymentScreen}
        options={StackOptions(
          'Payment',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'Cart', screen: 'Cart' }
        )}
      />

      <Stack.Screen
        name="PayWithPoints"
        component={CheckoutPreferenceScreen}
        options={StackOptions(
          'Pay with Rewards',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'Cart', screen: 'Payment' }
        )}
      />

      <Stack.Screen
        name="Confirmation"
        component={ConfirmationScreen}
        options={StackOptions(
          'Confirmation',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'Cart', screen: 'Payment' }
        )}
      />
    </Stack.Navigator>
  );
};

const CheckoutStack = ({ navigation }) => {
  const persistedState = useSelector((state) => state);
  const { tierName } = persistedState.points;
  const product = persistedState.shop.product;
  return (
    <Stack.Navigator initialRouteName="ProductDetails">
      <Stack.Screen
        name="ProductDetails"
        component={ProductDetailsScreen}
        options={StackOptions(
          product ? product.name : 'T-Shirt',
          navigation,
          'arrow-left',
          getTierHeaderColor(tierName),
          getTierColor(tierName),
          { route: 'Checkout', screen: null }
        )}
      />
    </Stack.Navigator>
  );
};

CheckoutStack.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

CartStack.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

export { CheckoutStack, CartStack };
