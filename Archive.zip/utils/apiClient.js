import { ApiClient } from 'mastercard_loyalty_sandbox_api';
/* eslint consistent-return: "off" */
import { Platform } from 'react-native';
import { ENV, API_URL, API_URL_IOS, API_URL_ANDROID } from '@env';

let BACKEND_SERVICE = Platform.OS === 'ios' ? API_URL_IOS
  : API_URL_ANDROID; // prettier-ignore
if (ENV !== 'local') {
  BACKEND_SERVICE = API_URL;
}

const SERVER_API = BACKEND_SERVICE;

const client = new ApiClient();
client.basePath = SERVER_API;

const WOOCOMERCE_TIMEOUT = 30000;

const DEFAULT_TIMEOUT = 60000;

const StringIsValidJson = (string) => {
  try {
    JSON.parse(string);
  } catch (e) {
    return false;
  }
  return true;
};
function extractError(payload) {
  /** timeout error format - [Error: Timeout of 5000ms exceeded] */
  if (String(payload).includes('Timeout of')) {
    return {
      Details: 'Request timed out. Try again'
    };
  }
  if (!payload || payload.response === undefined) {
    return {
      Details: 'Unknown error occurred'
    };
  }
  if (!StringIsValidJson(payload.response.text)) {
    return { Details: 'Invalid response. Try again later' };
  }
  const errorMessage = JSON.parse(payload.response.text);
  return errorMessage.Errors
    ? errorMessage.Errors.Error[0]
    : { Details: 'Service unavailable. Try again later' };
}

export {
  client,
  extractError,
  SERVER_API,
  WOOCOMERCE_TIMEOUT,
  DEFAULT_TIMEOUT
};
