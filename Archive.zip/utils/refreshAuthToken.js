import { refreshUserToken } from '@api/api';
import { store } from '@stores/index';
import * as actions from '@stores/actions';

const HasExpired = (expiry) => {
  const timeNow = Math.floor(Date.now() / 1000);
  return Number(timeNow) > Number(expiry);
};

const RefreshAuthToken = async (accessToken, refreshToken, expiresAt) => {
  try {
    if (HasExpired(expiresAt)) {
      const tokenRequestBody = { refreshToken };
      const res = await refreshUserToken(tokenRequestBody);
      store.dispatch(
        actions.userTokenRefreshed(
          res.accessToken,
          res.refreshToken,
          res.expiresAt
        )
      );
      return store.getState().authentication.session;
    }
    return {
      accessToken,
      refreshToken,
      expiresAt,
      expiresIn: 3600
    };
  } catch (error) {
    return {
      accessToken,
      refreshToken,
      expiresAt,
      expiresIn: 3600
    };
  }
};

export default RefreshAuthToken;
