import { Dimensions } from 'react-native';
import {
  client,
  extractError,
  SERVER_API,
  WOOCOMERCE_TIMEOUT,
  DEFAULT_TIMEOUT
} from './apiClient';
import {
  isBiometricDevice,
  enableBiometrics,
  authenticateBiometrics
} from './biometrics';
import countries from './countries';
import months from './months';
import theme from './theme';
import { cartTotal, cartQuantity } from './cart';
import RefreshAuthToken from './refreshAuthToken';
import normalize from './normalize';
import refreshUserProfile from './refreshUserProfile';
import PullGearProduct from './PullGearProduct';
import AppTracker from './initMixPanel';

const DEVICE_WIDTH = Dimensions.get('window').width;
const DEVICE_HEIGHT = Dimensions.get('window').height;

const SERVICE_ERROR_MESSAGE =
  "We're sorry, but something went wrong, PLease try again.";

export * from './format';
export * from './tierImages';
export * from './pushNotification';
export * from './haptic';
export * from './helpers';

export {
  client,
  theme,
  countries,
  extractError,
  isBiometricDevice,
  enableBiometrics,
  authenticateBiometrics,
  DEVICE_WIDTH,
  DEVICE_HEIGHT,
  SERVICE_ERROR_MESSAGE,
  SERVER_API,
  WOOCOMERCE_TIMEOUT,
  DEFAULT_TIMEOUT,
  cartTotal,
  cartQuantity,
  RefreshAuthToken,
  refreshUserProfile,
  months,
  normalize,
  PullGearProduct,
  AppTracker
};
