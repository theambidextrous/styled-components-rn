import { Text, TextInput } from 'react-native';
import moment from 'moment';

export const applyGlobalTextStyle = () => {
  Text.defaultProps = Text.defaultProps || {};
  Text.defaultProps.allowFontScaling = false;

  TextInput.defaultProps = TextInput.defaultProps || {};
  TextInput.defaultProps.allowFontScaling = false;
};

export const getStatusBar = (tier = 'bronze') => {
  switch (tier.toUpperCase()) {
    case 'BRONZE':
      return false;
    case 'SILVER':
      return false;
    case 'GOLD':
      return false;
    default:
      return false;
  }
};

export function removeDuplicates(data) {
  return data.filter((value) => data.indexOf(value.id) !== value.id);
}

export const dateFormat = (date) =>
  moment(date).calendar(null, {
    lastDay: 'MMM DD, YYYY, hh:mm',
    lastWeek: 'MMM DD, YYYY, hh:mm',
    sameElse: 'MMM DD, YYYY, hh:mm',
    sameDay: 'MMM DD, YYYY, hh:mm'
  });
