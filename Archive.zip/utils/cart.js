export const cartTotal = (cart) => {
  let total = 0;

  Object.keys(cart).forEach((id) => {
    const item = cart[id];
    total += item.price * item.quantity;
  });
  return total;
};

export const cartQuantity = (cart) => {
  let quantity = 0;

  Object.keys(cart).forEach((id) => {
    const item = cart[id];
    quantity += item.quantity;
  });

  return quantity;
};
