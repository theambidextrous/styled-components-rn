import ReactNativeHapticFeedback from 'react-native-haptic-feedback';

const options = {
  enableVibrateFallback: false,
  ignoreAndroidSystemSettings: false
};

export const triggerLightHaptic = () => {
  ReactNativeHapticFeedback.trigger('selection', options);
};

export const triggerImpactLightHaptic = () => {
  ReactNativeHapticFeedback.trigger('impactLight', options);
};
export const triggerSuccessHaptic = () => {
  ReactNativeHapticFeedback.trigger('notificationSuccess', options);
};

export const triggerWarningHaptic = () => {
  ReactNativeHapticFeedback.trigger('notificationWarning', options);
};

export const triggerErrorHaptic = () => {
  ReactNativeHapticFeedback.trigger('notificationError', options);
};
export const triggerHeavyHaptic = () => {
  ReactNativeHapticFeedback.trigger('impactHeavy', options);
};
