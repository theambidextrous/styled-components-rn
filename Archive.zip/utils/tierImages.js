import theme from './theme';

/** backgrounds */
const bronzeBg = require('@assets/images/others/silverTier.png');
const silverBg = require('@assets/images/others/silverTier.png');
const goldBg = require('@assets/images/others/goldTier.png');
const platinumBg = require('@assets/images/others/platinumTier.png');

/** reward backgrounds */
const bronzeRewardBg = require('@assets/images/others/welcomeOffer.png');
const silverRewardBg = require('@assets/images/others/welcomeOffer.png');
const goldRewardBg = require('@assets/images/others/welcomeOffer.png');
const platinumRewardBg = require('@assets/images/others/welcomeOffer.png');
/** icons */
const bronzeIcon = require('@assets/images/others/bronze_small.png');
const silverIcon = require('@assets/images/others/silver_small.png');
const goldIcon = require('@assets/images/others/gold_small.png');

/** badges */
const bronzeBadge = require('@assets/images/others/bronze.png');
const silverBadge = require('@assets/images/others/silver.png');
const goldBadge = require('@assets/images/others/gold.png');

// header background
const bronzeHeaderBg = require('@assets/images/others/bronzeHeaderBackground.png');
const silverHeaderBg = require('@assets/images/others/silverHeaderBackground.png');
const goldHeaderBg = require('@assets/images/others/goldHeaderBackground.png');
const platinumHeaderBg = require('@assets/images/others/platinumHeaderBackground.png');

export const getTierBadge = (tier = 'bronze') => {
  switch (tier.toUpperCase()) {
    case 'BRONZE':
      return bronzeBadge;
    case 'SILVER':
      return silverBadge;
    case 'GOLD':
      return goldBadge;
    case 'PLATINUM':
      return silverBadge;
    default:
      return bronzeBadge;
  }
};

export const getTierIcon = (tier = 'bronze') => {
  switch (tier.toUpperCase()) {
    case 'BRONZE':
      return bronzeIcon;
    case 'SILVER':
      return silverIcon;
    case 'GOLD':
      return goldIcon;
    default:
      return bronzeIcon;
  }
};

export const getTierBackground = (tier = 'bronze') => {
  switch (tier.toUpperCase()) {
    case 'BRONZE':
      return bronzeBg;
    case 'SILVER':
      return silverBg;
    case 'GOLD':
      return goldBg;
    case 'PLATINUM':
      return platinumBg;
    default:
      return bronzeBg;
  }
};

export const getRewardBackground = (tier = 'bronze') => {
  switch (tier.toUpperCase()) {
    case 'BRONZE':
      return bronzeRewardBg;
    case 'SILVER':
      return silverRewardBg;
    case 'GOLD':
      return goldRewardBg;
    case 'PLATINUM':
      return platinumRewardBg;
    default:
      return bronzeRewardBg;
  }
};
export const getTierHeaderBackground = (tier = 'bronze') => {
  switch (tier.toUpperCase()) {
    case 'BRONZE':
      return bronzeHeaderBg;
    case 'SILVER':
      return silverHeaderBg;
    case 'GOLD':
      return goldHeaderBg;
    case 'PLATINUM':
      return platinumHeaderBg;
    default:
      return bronzeHeaderBg;
  }
};

export const getTierHeaderColor = (tier = 'bronze') => {
  switch (tier.toUpperCase()) {
    case 'BRONZE':
      return theme.colors.textWhite;
    case 'SILVER':
      return theme.colors.textWhite;
    case 'GOLD':
      return theme.colors.textWhite;
    case 'PLATINUM':
      return theme.colors.textWhite;
    default:
      return theme.colors.textWhite;
  }
};

export const getTierColor = (tier = 'bronze') => {
  switch (tier.toUpperCase()) {
    case 'BRONZE':
      return theme.colors.textPrimary;
    case 'SILVER':
      return theme.colors.textPrimary;
    case 'GOLD':
      return theme.colors.textPrimary;
    case 'PLATINUM':
      return theme.colors.textPrimary;
    default:
      return theme.colors.textWhite;
  }
};
