import { Platform } from 'react-native';
import {
  NotificationApi,
  RegisterDeviceRequest
} from 'mastercard_loyalty_sandbox_api';
import PushNotification, { Importance } from 'react-native-push-notification';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { store } from '@stores/index';
import * as actions from '@stores/actions';
import { client } from './apiClient';
import AppTracker from './initMixPanel';
import RefreshAuthToken from './refreshAuthToken';

const AndroidConfig = (title, message, channelId) => ({
  channelId,
  showWhen: true,
  autoCancel: true,
  largeIcon: '',
  smallIcon: '',
  bigText: message,
  vibrate: true,
  vibration: 300,
  priority: 'high',
  visibility: 'private',
  ignoreInForeground: false,
  shortcutId: 'shortcut-id',
  onlyAlertOnce: false,
  actions: ['Open', 'No'],
  invokeApp: true,
  title,
  message,
  userInfo: {},
  playSound: true,
  soundName: 'apns.mp3',
  number: 10,
  repeatType: 'day'
});

const iOSConfig = (title, message) => ({
  category: '',
  subtitle: title,
  title,
  message,
  userInfo: {},
  playSound: true,
  soundName: 'apns.mp3',
  number: 10,
  repeatType: 'day'
});

const HandleNotification = (data) => data;

export const UpdateUserDeviceToken = async (deviceToken) => {
  try {
    const appTracker = new AppTracker();
    if (!deviceToken) {
      throw new Error(`device token not found: Got ${deviceToken}`);
    }
    const authState = store.getState().authentication;
    const { accessToken, refreshToken, expiresAt } = authState.session;
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const api = new NotificationApi(client);
    const platform = Platform.OS;
    api.registerUserNotificationDevice(
      RegisterDeviceRequest.constructFromObject({
        token: deviceToken,
        platform: platform.toLocaleUpperCase()
      }),
      (error, data, response) => {
        if (response && response.statusCode < 205) {
          // all good, device token registered
          return;
        }
        appTracker.logMiscellaneousEvent(
          'PN Device token registration',
          `device token registration failed with ${response.statusCode}`
        );
      }
    );
  } catch (error) {
    // console.log('token error', error);
  }
};

export const PushNotificationConfig = () => {
  PushNotification.channelExists('LoyaltySandBoxUsers', (exists) => {
    if (!exists) {
      PushNotification.createChannel({
        channelId: 'LoyaltySandBoxUsers',
        channelName: 'LoyaltySandBoxUsers',
        channelDescription: 'Loyalty SandBox App customer base',
        importance: Importance.HIGH,
        vibrate: true,
        soundName: 'apns.mp3'
      });
    }
  });
  PushNotification.configure({
    onRegister: async (data) => {
      if (data.token) {
        await AsyncStorage.setItem('deviceToken', data.token);
        store.dispatch(actions.storeDeviceToken(data.token));
      }
    },
    onNotification: (notification) => HandleNotification(notification),
    onAction: (notification) => notification,

    onRegistrationError: (err) => err,

    permissions: {
      alert: true,
      badge: true,
      sound: true
    },
    popInitialNotification: true,
    requestPermissions: true
  });
};

export const LocalNotify = (
  title,
  message,
  channelId = 'LoyaltySandBoxUsers'
) => {
  const platformConfig =
    Platform.OS === 'android'
      ? AndroidConfig(title, message, channelId)
      : iOSConfig(title, message);
  PushNotification.localNotification(platformConfig);
};

export const ScheduledNotify = (
  title,
  message,
  channelId = 'LoyaltySandBoxUsers'
) => {
  const platformConfig =
    Platform.OS === 'android'
      ? AndroidConfig(title, message, channelId)
      : iOSConfig(title, message);
  platformConfig.date = new Date(Date.now() + 10 * 1000);
  platformConfig.allowWhileIdle = false;
  if (Platform.OS === 'android') platformConfig.repeatTime = 1;
  PushNotification.localNotificationSchedule(platformConfig);
};
