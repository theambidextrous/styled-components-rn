import { Platform } from 'react-native';
import FingerprintScanner from 'react-native-fingerprint-scanner';

export const isBiometricDevice = (isBiometricDeviceState) => {
  FingerprintScanner.isSensorAvailable()
    .then((biometryType) => {
      isBiometricDeviceState(
        biometryType,
        true,
        `${biometryType} feature is available on your device`
      );
    })
    .catch((error) => {
      isBiometricDeviceState(null, false, error.message);
    });
};

export const enableBiometrics = (biometryType, enableBiometricsState) => {
  let hasFingerUnlock = false;
  let hasFaceUnlock = false;
  try {
    switch (biometryType) {
      case 'Touch ID':
        hasFingerUnlock = true;
        break;
      case 'Face ID':
        hasFaceUnlock = true;
        break;
      case 'Biometrics':
        hasFingerUnlock = true;
        break;
      default:
        break;
    }
    enableBiometricsState(
      hasFingerUnlock,
      hasFaceUnlock,
      true,
      `${biometryType} feature has been activated`
    );
  } catch (error) {
    enableBiometricsState(hasFingerUnlock, hasFaceUnlock, false, error.message);
  }
};

export const authenticateBiometrics = (BiometricsState) => {
  if (Platform.OS === 'android') {
    FingerprintScanner.authenticate({ title: 'Log in with Biometrics' })
      .then(() => {
        BiometricsState(true, 'Biometrics access granted');
      })
      .catch((error) => {
        BiometricsState(false, error.message);
      });
  } else if (Platform.OS === 'ios') {
    FingerprintScanner.authenticate({
      description: 'Scan your finger/face on the device scanner to continue'
    })
      .then(() => {
        BiometricsState(true, 'Biometrics access granted');
      })
      .catch((error) => {
        BiometricsState(false, error.message);
      });
  } else {
    BiometricsState(false, 'Device not allowed');
  }
};
