import { Platform } from 'react-native';

/** dummy artworks */
const bgOne = require('@assets/images/others/card.bg.png');
const bgTwo = require('@assets/images/others/card.bg.png');
const bgThree = require('@assets/images/others/card.bg.png');

const bgOneSm = require('@assets/images/others/card_background_1_sm.png');
const bgTwoSm = require('@assets/images/others/card_background_2_sm.png');
const bgThreeSm = require('@assets/images/others/card_background_3_sm.png');

const BackgroundSelector = (entry, type = '') => {
  if ([1, 4, 7, 10].includes(entry)) {
    return type ? bgOneSm : bgOne;
  }
  if ([2, 5, 8, 11].includes(entry)) {
    return type ? bgTwoSm : bgTwo;
  }
  return type ? bgThreeSm : bgThree;
};

const money = (num) => `$${(Math.round(num * 0.01 * 100) / 100).toFixed(2)}`;

const FormatLocalProxyForAndroid = (uri) => {
  if (Platform.OS === 'android') {
    const newUri = uri.replace('localhost', '10.0.2.2');
    newUri.replace('127.0.0.1', '10.0.2.2');
    return newUri;
  }
  return uri;
};
const CardIsExpired = (expiry) => {
  const expiryDate = new Date(expiry);
  const unixStamp = Math.floor(new Date(expiryDate).getTime() / 1000);
  const timeNow = Math.floor(Date.now() / 1000);
  return timeNow > unixStamp;
};
const SalepriceMock = (price) => String(price);

const LocalhostToHttp = (url) => {
  if (String(url).includes('127.0.0.1') || String(url).includes('localhost')) {
    return `http:${url.split(':')[1]}`; /** change to http if localhost */
  }
  return url;
};

const IsInWishlist = (id, wishlist) => {
  let isIn = false;
  wishlist.forEach((item) => {
    if (String(item.id) === String(id)) {
      isIn = true;
    }
  });
  return isIn;
};
const ProductListFormatter = (arrayList) =>
  arrayList.map((val, idx) => ({
    key: idx,
    id: val.id,
    sku: val.sku,
    name: val.name.split('&')[0],
    price: String(val.price),
    salePrice: val.sale_price
      ? String(val.sale_price)
      : SalepriceMock(val.price),
    image: FormatLocalProxyForAndroid(
      LocalhostToHttp(ExtractImageFromAttribute(val.attributes))
    ),
    category:
      Array.isArray(val.categories) && val.categories.length > 0
        ? val.categories[0].name
        : 'All',
    sizes: ExtractAttribute('Size', val.attributes),
    colors: ExtractAttribute('Color', val.attributes)
  }));

const OffersListFormatter = (arrayList) =>
  arrayList.map((val, idx) => ({
    key: Number(idx + 1),
    id: val.id,
    type: val.type,
    status: val.status,
    active: val.active,
    activationType: val.activationType,
    offerId: val.id,
    source: val.src,
    sourceId: val.srcId,
    title: val.localizations[0].headline,
    subtitle: val.localizations[0].descriptionShort,
    slogan: val.localizations[0].marketingSlogan,
    artwork: ExtractOfferMedia('Offer_300x250', val.localizations),
    logo: ExtractOfferMedia('Logo_Square_85x85', val.localizations),
    media: ExtractOfferMedia(undefined, val.localizations, 'SM')
  }));

const ExtractOfferMedia = (attribute, data, type = 'PCLO') => {
  const defaultMedia = 'https://via.placeholder.com/700';
  if (data[0] === undefined) {
    return defaultMedia;
  }
  const mediaData = data[0].media;
  if (type !== 'PCLO') {
    return mediaData[0]
      ? `https:${mediaData[0].src.split(':')[1]}`
      : defaultMedia;
  }
  let response;
  mediaData.forEach((item) => {
    if (item.class === attribute) response = item.src;
  });
  return response;
};

const ExtractAttribute = (attribute, data) => {
  let response = [];
  data.forEach((item) => {
    if (item.name.toLowerCase() === attribute.toLowerCase()) {
      response = item.options;
    }
  });
  return response;
};

const ExtractImageFromAttribute = (data) => {
  let response = [];
  data.forEach((item) => {
    if (item.name.toLowerCase() === 'image') {
      response = item.options;
    }
  });
  if (Array.isArray(response) && response.length > 0) {
    return response[0];
  }
  return 'https://via.placeholder.com/160';
};

const CategoryListFormatter = (arrayList) =>
  arrayList.map((val, idx) => ({
    key: idx,
    id: val.id,
    name: val.name,
    image: val.image
      ? FormatLocalProxyForAndroid(LocalhostToHttp(val.image.src))
      : 'https://via.placeholder.com/96',
    count: val.count
  }));

export const getInitials = (name) => {
  const initials = name
    .split(' ')
    .map((n) => n.charAt(0))
    .join('')
    .toUpperCase();
  return initials;
};
const SessionMOffersListFormatter = (arrayList) =>
  arrayList.map((val, idx) => ({
    key: idx,
    id: val.id,
    offerId: val.id,
    source: val.src,
    active: val.active,
    sourceId: val.srcId,
    headline: val.localizations[0].headline,
    descriptionShort: val.localizations[0].descriptionShort,
    artwork: val.localizations[0].media[0].src
  }));

export {
  money,
  ProductListFormatter,
  CategoryListFormatter,
  FormatLocalProxyForAndroid,
  OffersListFormatter,
  IsInWishlist,
  SessionMOffersListFormatter,
  CardIsExpired,
  BackgroundSelector
};
