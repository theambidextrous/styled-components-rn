// Inspired by react-native-elements: https://github.com/react-native-elements/react-native-elements/blob/next/src/helpers/normalizeText.js
import { moderateScale } from 'react-native-size-matters';

export default function normalize(number: number, factor = 1) {
  return moderateScale(number, factor);
}
