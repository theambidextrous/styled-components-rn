import * as actions from '@stores/actions';
import { UserApi } from 'mastercard_loyalty_sandbox_api';
import { store } from '@stores/index';
import { client, extractError } from './apiClient';

const fetchUserProfile = (authToken) => {
  client.defaultHeaders = {
    authorization: `Bearer ${authToken}`
  };
  const apiInstance = new UserApi(client);
  apiInstance.getUserProfile((error, data, response) => {
    if (response && response.statusCode < 205) {
      const {
        nextTierName,
        nextTierRemainingPoints,
        tierName,
        tierPoints,
        tierTotalPoints,
        spendablePoints,
        pcloCobrandConversionFactor,
        pointsConversionFactor,
        pcloPointsConversionFactor,
        coBrandPointsConversionFactor
      } = response.body;
      store.dispatch(
        actions.setUserTier(
          tierName,
          tierPoints,
          nextTierName,
          nextTierRemainingPoints,
          tierTotalPoints,
          spendablePoints,
          pcloCobrandConversionFactor,
          pointsConversionFactor,
          pcloPointsConversionFactor,
          coBrandPointsConversionFactor
        )
      );
    } else {
      const errorData = extractError(error);
      throw errorData.Details;
    }
  });
};

export default fetchUserProfile;
