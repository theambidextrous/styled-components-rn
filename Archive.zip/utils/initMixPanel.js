import { Mixpanel } from 'mixpanel-react-native';
import DeviceInfo from 'react-native-device-info';
import { MIX_PANEL_TOKEN, MIX_PANEL_TOKEN_MTF, MIX_PANEL_ENV } from '@env';
import { Platform } from 'react-native';

const mixpanel = new Mixpanel(
  MIX_PANEL_ENV === 'mtf' ? MIX_PANEL_TOKEN_MTF : MIX_PANEL_TOKEN
);
mixpanel.init();

class AppTracker {
  /** onboarding */
  logNewUser(email) {
    mixpanel.track('New User', {
      user: email,
      device: DeviceInfo.getDeviceId(),
      os: Platform.OS
    });
  }

  logSignedUpFailure(error, user) {
    mixpanel.track('Sign Up Failed', {
      Error: error,
      user,
      device: DeviceInfo.getDeviceId(),
      os: Platform.OS
    });
  }

  logSignInFailure(error, user) {
    mixpanel.track('Forgot Password Failed', {
      Error: error,
      user,
      device: DeviceInfo.getDeviceId(),
      os: Platform.OS
    });
  }

  logForgotPasswordFailure(error, user) {
    mixpanel.track('Sign In Failed', {
      Error: error,
      user,
      device: DeviceInfo.getDeviceId(),
      os: Platform.OS
    });
  }

  logMiscellaneousEvent(event, error, user = 'hidden') {
    mixpanel.track(event, {
      Error: error,
      user,
      device: DeviceInfo.getDeviceId(),
      os: Platform.OS
    });
  }

  /** woo-commerce */
  logWooCommerceFailure(event, error, user = 'hidden') {
    mixpanel.track(event, {
      Error: error,
      user,
      device: DeviceInfo.getDeviceId(),
      os: Platform.OS
    });
  }

  /** offers */
  logOffersFailure(event, error, user = 'hidden') {
    mixpanel.track(event, {
      Error: error,
      user,
      device: DeviceInfo.getDeviceId(),
      os: Platform.OS
    });
  }

  /** accounts - cards */
  logCardsFailure(event, error, user = 'hidden') {
    mixpanel.track(event, {
      Error: error,
      user,
      device: DeviceInfo.getDeviceId(),
      os: Platform.OS
    });
  }
}

export default AppTracker;
