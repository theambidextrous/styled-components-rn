import * as actions from '@stores/actions';
import { ProductsApi } from 'mastercard_loyalty_sandbox_api';
import { store } from '@stores/index';
import { client, extractError, WOOCOMERCE_TIMEOUT } from './apiClient';
import { ProductListFormatter } from './format';

const PullGearProduct = (applicationId, accessToken) => {
  client.timeout = WOOCOMERCE_TIMEOUT;
  client.defaultHeaders = {
    authorization: `Bearer ${accessToken}`
  };
  const api = new ProductsApi(client);
  api.getNewArrivals(applicationId, {}, (error, data, response) => {
    if (response !== undefined && Number(response.statusCode) < 205) {
      const productsPayload = response.body.products;
      const cleanedUp = ProductListFormatter(productsPayload);
      const GearItem = cleanedUp.length > 0 ? cleanedUp[0] : {};
      store.dispatch(actions.storeThirdPartyProduct(GearItem));
    } else {
      /** error */
      const errorData = extractError(error);
      throw errorData.Details;
    }
  });
};

export default PullGearProduct;
