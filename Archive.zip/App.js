import MainNavigation from '@navigation/mainNavigation';
import { persistedStore, store } from '@stores/index';
import { LoadingIndicator, ThemeManager } from '@components';
import React from 'react';
import { LogBox } from 'react-native';
import { Provider } from 'react-redux';
import { enableScreens } from 'react-native-screens';
import { PersistGate } from 'redux-persist/es/integration/react';
import FlashMessage from 'react-native-flash-message';
import SplashScreen from 'react-native-splash-screen';
import { PushNotificationConfig, applyGlobalTextStyle } from '@utils';

import 'react-native-gesture-handler';

enableScreens();

PushNotificationConfig();
applyGlobalTextStyle();

const App = () => {
  React.useEffect(() => {
    SplashScreen.hide();
    LogBox.ignoreAllLogs(); // will remove this after demo to avoid james getting  errors
  }, []);
  return (
    <>
      <Provider store={store}>
        <PersistGate persistor={persistedStore} loading={<LoadingIndicator />}>
          <ThemeManager>
            <MainNavigation />
          </ThemeManager>
        </PersistGate>
      </Provider>
      <FlashMessage position="bottom" />
    </>
  );
};
export default App;
