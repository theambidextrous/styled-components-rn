import { combineReducers } from 'redux';
import OnBoardingReducer from '@stores/reducers/OnBoarding';
import AuthenticationReducer from '@stores/reducers/Authentication';
import CartReducer from './Cart';
import ShopReducer from './Shop';
import WishlistReducer from './Wishlist';
import PointsReducer from './Points';
import CardsReducer from './Cards';
import PreferenceReducer from './Preference';
import PushNotificationReducer from './PushNotification';
import DemoUserReducer from './DemoUser';
import ThirdPartyReducer from './ThirdParty';
import MultistoreReducer from './Multistore';
// insert another reducers here to be combined

const reducers = combineReducers({
  onBoarding: OnBoardingReducer,
  authentication: AuthenticationReducer,
  cart: CartReducer,
  shop: ShopReducer,
  wishlist: WishlistReducer,
  points: PointsReducer,
  cards: CardsReducer,
  preference: PreferenceReducer,
  notification: PushNotificationReducer,
  demoUser: DemoUserReducer,
  thirdParty: ThirdPartyReducer,
  multiStore: MultistoreReducer
});

export default reducers;
