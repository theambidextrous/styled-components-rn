import * as actionTypes from '@stores/actionTypes';

const initialState = {
  thirdPartyProduct: {},
  isThirdParty: false,
  checkoutSource: '3rd Party Shop'
};

const ThirdPartyReducer = (thirdPartyState = initialState, action) => {
  switch (action.type) {
    case actionTypes.STORE_THIRD_PARTY_PRODUCT:
      return {
        ...thirdPartyState,
        thirdPartyProduct: action.payload.product
      };

    case actionTypes.SET_IS_THIRD_PARTY:
      return {
        ...thirdPartyState,
        isThirdParty: action.payload.status
      };

    default:
      return thirdPartyState;
  }
};
export default ThirdPartyReducer;
