import * as actionTypes from '@stores/actionTypes';

const theme = {
  appConfig: {
    colors: {
      primary: '#FF5F00'
    }
  }
};

const initialState = {
  shopName: '',
  applicationId: '',
  themeConfig: { ...theme },
  woocommerceCategory: '',
  themeImages: [],
  thirdPartyShopId: '',
  thirdPartyShopName: '',
  thirdPartyThemeImages: []
};

const MultistoreReducer = (multiStoreState = initialState, action) => {
  switch (action.type) {
    case actionTypes.SAVE_MULTISTORE_APP_ID:
      return {
        ...multiStoreState,
        shopName: action.payload.shop.shopName,
        applicationId: action.payload.shop.applicationId,
        woocommerceCategory: action.payload.shop.woocommerceCategory
      };

    case actionTypes.SAVE_MULTISTORE_APP_THEME:
      return {
        ...multiStoreState,
        themeConfig: {
          ...multiStoreState.themeConfig,
          ...action.payload.themeConfig
        }
      };

    case actionTypes.SAVE_MULTISTORE_THEME_IMAGES:
      return {
        ...multiStoreState,
        themeImages: action.payload.themeImages
      };

    case actionTypes.SAVE_MULTISTORE_THIRD_PART_ID:
      return {
        ...multiStoreState,
        thirdPartyShopId: action.payload.thirdPartyShopId,
        thirdPartyShopName: action.payload.thirdPartyShopName,
        thirdPartyThemeImages: action.payload.thirdPartyThemeImages
      };

    default:
      return multiStoreState;
  }
};
export default MultistoreReducer;
