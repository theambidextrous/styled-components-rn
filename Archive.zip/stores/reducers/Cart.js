import * as actionTypes from '@stores/actionTypes';

const initialState = {
  items: {}
};

const CartReducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.ADD_TO_CART: {
      const addedProduct = action.product;
      let updatedOrNewCartItem;

      if (state.items[addedProduct.id]) {
        const quantity = addedProduct.quantity;
        const color = addedProduct.color;
        const size = addedProduct.size;
        updatedOrNewCartItem = {
          ...state.items[addedProduct.id],
          quantity,
          color,
          size
        };
      } else {
        updatedOrNewCartItem = { ...addedProduct };
      }
      return {
        ...state,
        items: { ...state.items, [addedProduct.id]: updatedOrNewCartItem }
      };
    }

    case actionTypes.REMOVE_FROM_CART: {
      const selectedCartItem = state.items[action.pid];
      const updatedCartItems = { ...state.items };
      if (!selectedCartItem) {
        return { ...state, updatedCartItems };
      }
      delete updatedCartItems[action.pid];
      return {
        ...state,
        items: updatedCartItems
      };
    }

    case actionTypes.CLEAR_CART:
      return initialState;

    default:
      return state;
  }
};

export default CartReducer;
