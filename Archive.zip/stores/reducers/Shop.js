import * as actionTypes from '@stores/actionTypes';

const initialShopState = {
  product: {},
  category: {}
};

const ShopReducer = (shopState = initialShopState, action) => {
  switch (action.type) {
    case actionTypes.OPENED_PRODUCT:
      return {
        ...shopState,
        product: action.payload.product
      };

    case actionTypes.OPENED_CATEGORY:
      return {
        ...shopState,
        category: action.payload.category
      };
    default:
      return shopState;
  }
};

export default ShopReducer;
