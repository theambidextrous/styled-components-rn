import * as actionTypes from '@stores/actionTypes';

const initialState = {
  redemptionFrequency: 'OFF',
  hasSeenOffer: false,
  adminPass: 1110,
  hasAuthenticated: false,
  featurePreference: {}
};

const PreferenceReducer = (prefState = initialState, action) => {
  switch (action.type) {
    case actionTypes.SET_USER_PWR_PREF:
      return {
        ...prefState,
        redemptionFrequency: action.payload.pref
      };

    case actionTypes.SET_GENERAL_FEATURE_PREF:
      return {
        ...prefState,
        featurePreference: action.payload.pref
      };

    case actionTypes.SET_COBRAND_OFFER_PREF:
      return {
        ...prefState,
        hasSeenOffer: action.payload.status
      };

    case actionTypes.SET_DEMO_ADMIN_AUTHENTICATED:
      return {
        ...prefState,
        hasAuthenticated: action.payload.status
      };

    case actionTypes.SET_DEMO_ADMIN_PASS:
      return {
        ...prefState,
        adminPass: 1110
      };

    case actionTypes.CLEAR_PREF_STORE:
      return initialState;

    default:
      return prefState;
  }
};
export default PreferenceReducer;
