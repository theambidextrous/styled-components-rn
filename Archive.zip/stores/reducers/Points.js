import * as actionTypes from '@stores/actionTypes';

const initialState = {
  tierName: '',
  tierPoints: 0,
  nextTierName: '',
  nextTierRemainingPoints: 0,
  tierTotalPoints: 0,
  spendablePoints: 0,
  pcloCobrandConversionFactor: 0,
  pointsConversionFactor: 0,
  pcloPointsConversionFactor: 0,
  coBrandPointsConversionFactor: 0
};
const PointsReducer = (pointsState = initialState, action) => {
  switch (action.type) {
    case actionTypes.SET_USER_TIER:
      return {
        ...pointsState,
        tierName: action.payload.tierName,
        tierPoints: action.payload.tierPoints,
        nextTierName: action.payload.nextTierName,
        nextTierRemainingPoints: action.payload.nextTierRemainingPoints,
        tierTotalPoints: action.payload.tierTotalPoints,
        spendablePoints: action.payload.spendablePoints,
        pcloCobrandConversionFactor: action.payload.pcloCobrandConversionFactor,
        pointsConversionFactor: action.payload.pointsConversionFactor,
        pcloPointsConversionFactor: action.payload.pcloPointsConversionFactor,
        coBrandPointsConversionFactor:
          action.payload.coBrandPointsConversionFactor
      };

    case actionTypes.ADD_USER_POINTS:
      return {
        ...pointsState,
        tierPoints: pointsState.tierPoints + action.payload.points
      };

    case actionTypes.DEDUCT_USER_POINTS:
      return {
        ...pointsState,
        tierPoints: pointsState.tierPoints - action.payload.points
      };

    case actionTypes.CLEAR_POINTS_STORE:
      return initialState;

    default:
      return pointsState;
  }
};
export default PointsReducer;
