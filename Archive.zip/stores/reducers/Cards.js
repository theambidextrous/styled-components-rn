import * as actionTypes from '@stores/actionTypes';

const initialState = {
  count: 0,
  cards: [],
  openCard: {}
};
const GetMaxId = (cards) => {
  if (cards.length === 0) {
    return 1;
  }
  return Math.max.apply(
    Math,
    cards.map((card) => Number(card.id + 1))
  );
};
const CardsReducer = (cardsState = initialState, action) => {
  switch (action.type) {
    case actionTypes.ADD_USER_CARD:
      return {
        ...cardsState,
        count: cardsState.count + 1,
        cards: [
          // ...cardsState.cards,
          {
            id: GetMaxId(cardsState.cards),
            mrsId: action.payload.mrsId,
            name: action.payload.name,
            pan: action.payload.pan,
            mask: action.payload.pan,
            validUntil: action.payload.validUntil,
            balance: action.payload.balance,
            isCoBrand: action.payload.isCoBrand,
            isDefault: action.payload.isDefault
          }
        ]
      };

    case actionTypes.REMOVE_USER_CARD:
      return {
        ...cardsState,
        count: cardsState.count > 0 ? cardsState.count - 1 : 0,
        cards: cardsState.cards.filter((card) => card.id !== action.payload.id)
      };

    case actionTypes.UPDATE_USER_CARD_MRSID:
      return {
        ...cardsState,
        cards: cardsState.cards.map((card) => {
          if (card.mask !== action.payload.mask) {
            return card;
          }
          return { ...card, mrsId: action.payload.mrsId };
        })
      };

    case actionTypes.OPENED_USER_CARD:
      return {
        ...cardsState,
        openCard: action.payload.card
      };

    case actionTypes.CLEAR_CARDS_STORE:
      return initialState;

    default:
      return cardsState;
  }
};
export default CardsReducer;
