import * as actionTypes from '@stores/actionTypes';

const initialState = {
  users: [],
  session: {}
};

const DemoUserReducer = (demoUserState = initialState, action) => {
  switch (action.type) {
    case actionTypes.STORE_DEMO_USERS:
      return {
        ...demoUserState,
        users: action.payload.users
      };

    case actionTypes.STORE_SUPERUSER_SESSION:
      return {
        ...demoUserState,
        session: action.payload.session
      };

    case actionTypes.CLEAR_DEMO_USERS:
      return initialState;

    default:
      return demoUserState;
  }
};
export default DemoUserReducer;
