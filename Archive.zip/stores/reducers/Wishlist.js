import * as actionTypes from '@stores/actionTypes';

const initialWishlistState = {
  count: 0,
  items: [],
  points: 0
};

const WishlistReducer = (wishlistState = initialWishlistState, action) => {
  switch (action.type) {
    case actionTypes.ADD_TO_WISHLIST:
      return {
        ...wishlistState,
        count: wishlistState.count + 1,
        items: [...wishlistState.items, action.payload.item]
      };

    case actionTypes.REMOVE_FROM_WISHLIST:
      return {
        ...wishlistState,
        count: wishlistState.count > 0 ? wishlistState.count - 1 : 0,
        items: wishlistState.items.filter(
          (item) => item.id !== action.payload.id
        )
      };
    case actionTypes.SET_WISHLIST_POINTS:
      return {
        ...wishlistState,
        points: action.payload.points
      };

    case actionTypes.CLEAR_WISHLIST:
      return initialWishlistState;

    default:
      return wishlistState;
  }
};

export default WishlistReducer;
