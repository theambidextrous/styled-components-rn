import * as actionTypes from '@stores/actionTypes';

const initialState = {
  token: null
};

const PushNotificationReducer = (
  pushNotificationState = initialState,
  action
) => {
  switch (action.type) {
    case actionTypes.STORE_DEVICE_TOKEN:
      return {
        ...pushNotificationState,
        token: action.payload.token
      };

    case actionTypes.CLEAR_DEVICE_TOKEN:
      return initialState;

    default:
      return pushNotificationState;
  }
};
export default PushNotificationReducer;
