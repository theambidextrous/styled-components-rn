import * as actionTypes from '@stores/actionTypes';

export const setUserTier = (
  tierName,
  tierPoints,
  nextTierName,
  nextTierRemainingPoints,
  tierTotalPoints,
  spendablePoints,
  pcloCobrandConversionFactor,
  pointsConversionFactor,
  pcloPointsConversionFactor,
  coBrandPointsConversionFactor
) => ({
  type: actionTypes.SET_USER_TIER,
  payload: {
    tierName,
    tierPoints,
    nextTierName,
    nextTierRemainingPoints,
    tierTotalPoints,
    spendablePoints,
    pcloCobrandConversionFactor,
    pointsConversionFactor,
    pcloPointsConversionFactor,
    coBrandPointsConversionFactor
  }
});

export const addUserPoints = (points) => ({
  type: actionTypes.ADD_USER_POINTS,
  payload: {
    points
  }
});

export const deductUserPoints = (points) => ({
  type: actionTypes.DEDUCT_USER_POINTS,
  payload: {
    points
  }
});

export const clearPointsStore = () => ({
  type: actionTypes.CLEAR_POINTS_STORE,
  payload: {}
});
