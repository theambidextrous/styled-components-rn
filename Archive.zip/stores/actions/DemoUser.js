import * as actionTypes from '@stores/actionTypes';

export const storeDemoUsers = (users) => ({
  type: actionTypes.STORE_DEMO_USERS,
  payload: { users }
});

export const storeSuperUserSession = (session) => ({
  type: actionTypes.STORE_SUPERUSER_SESSION,
  payload: { session }
});

export const clearDemoUsers = () => ({
  type: actionTypes.CLEAR_DEMO_USERS,
  payload: {}
});
