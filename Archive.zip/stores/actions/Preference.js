import * as actionTypes from '@stores/actionTypes';

export const setUserPwrPreference = (pref) => ({
  type: actionTypes.SET_USER_PWR_PREF,
  payload: {
    pref
  }
});

export const setGeneralFeaturePreference = (pref) => ({
  type: actionTypes.SET_GENERAL_FEATURE_PREF,
  payload: {
    pref
  }
});

export const setUserCobrandOfferPreference = (status) => ({
  type: actionTypes.SET_COBRAND_OFFER_PREF,
  payload: {
    status
  }
});

export const setDemoAdminAuthenticated = (status) => ({
  type: actionTypes.SET_DEMO_ADMIN_AUTHENTICATED,
  payload: {
    status
  }
});

export const setDemoAdminPassword = () => ({
  type: actionTypes.SET_DEMO_ADMIN_PASS,
  payload: {}
});

export const clearPreferenceStore = () => ({
  type: actionTypes.CLEAR_PREF_STORE,
  payload: {}
});
