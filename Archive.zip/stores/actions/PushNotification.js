import * as actionTypes from '@stores/actionTypes';

export const storeDeviceToken = (token) => ({
  type: actionTypes.STORE_DEVICE_TOKEN,
  payload: { token }
});

export const clearDeviceToken = () => ({
  type: actionTypes.CLEAR_DEVICE_TOKEN,
  payload: {}
});
