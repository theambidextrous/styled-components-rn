import * as actionTypes from '@stores/actionTypes';

/** shop --> persist product to avoid calling api again */
export const openedProduct = (product) => ({
  type: actionTypes.OPENED_PRODUCT,
  payload: {
    product
  }
});
/** Shop --> persist category {id,name}  */
export const openedCategory = (category) => ({
  type: actionTypes.OPENED_CATEGORY,
  payload: {
    category
  }
});
