import * as actionTypes from '@stores/actionTypes';

export const appLoaded = (status) => ({
  type: actionTypes.APP_LOADED,
  payload: {
    status
  }
});
export const tutorialSkipped = (status) => ({
  type: actionTypes.TUTORIAL_SKIPPED,
  payload: {
    status
  }
});
