import * as actionTypes from '@stores/actionTypes';

export const saveMultiStoreAppId = (shop) => ({
  type: actionTypes.SAVE_MULTISTORE_APP_ID,
  payload: {
    shop
  }
});

export const saveMultiStoreAppTheme = (themeConfig) => ({
  type: actionTypes.SAVE_MULTISTORE_APP_THEME,
  payload: {
    themeConfig
  }
});

export const saveMultiStoreThirdPartyId = (
  thirdPartyShopId,
  thirdPartyShopName,
  thirdPartyThemeImages
) => ({
  type: actionTypes.SAVE_MULTISTORE_THIRD_PART_ID,
  payload: {
    thirdPartyShopId,
    thirdPartyShopName,
    thirdPartyThemeImages
  }
});

export const saveMultiStoreThemeImages = (themeImages) => ({
  type: actionTypes.SAVE_MULTISTORE_THEME_IMAGES,
  payload: {
    themeImages
  }
});
