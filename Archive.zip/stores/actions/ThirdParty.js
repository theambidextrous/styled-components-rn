import * as actionTypes from '@stores/actionTypes';

export const storeThirdPartyProduct = (product) => ({
  type: actionTypes.STORE_THIRD_PARTY_PRODUCT,
  payload: { product }
});

export const setIsThirdParty = (status) => ({
  type: actionTypes.SET_IS_THIRD_PARTY,
  payload: { status }
});
