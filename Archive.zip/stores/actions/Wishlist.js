import * as actionTypes from '@stores/actionTypes';

export const addToWishlist = (item) => ({
  type: actionTypes.ADD_TO_WISHLIST,
  payload: {
    item
  }
});
export const removeFromWishlist = (id) => ({
  type: actionTypes.REMOVE_FROM_WISHLIST,
  payload: {
    id
  }
});
export const setWishlistPoints = (points) => ({
  type: actionTypes.REMOVE_FROM_WISHLIST,
  payload: {
    points
  }
});

export const clearWishlist = () => ({
  type: actionTypes.CLEAR_WISHLIST
});
