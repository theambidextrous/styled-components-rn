import * as actionTypes from '@stores/actionTypes';

export const addToCart = (product) => ({
  type: actionTypes.ADD_TO_CART,
  product
});

export const removeFromCart = (productId) => ({
  type: actionTypes.REMOVE_FROM_CART,
  pid: productId
});

export const clearCart = () => ({
  type: actionTypes.CLEAR_CART
});
