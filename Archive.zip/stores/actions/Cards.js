import * as actionTypes from '@stores/actionTypes';

export const addUserCard = (card) => ({
  type: actionTypes.ADD_USER_CARD,
  payload: {
    name: card.name,
    pan: card.pan,
    mrsId: card.mrsId,
    validUntil: card.validUntil,
    balance: card.balance,
    isCoBrand: card.isCoBrand,
    isDefault: card.isDefault
  }
});

export const removeUserCard = (id) => ({
  type: actionTypes.REMOVE_USER_CARD,
  payload: {
    id
  }
});

export const updateUserCardMrsId = (mrsId, mask) => ({
  type: actionTypes.UPDATE_USER_CARD_MRSID,
  payload: {
    mrsId,
    mask
  }
});

export const openedUserCard = (card) => ({
  type: actionTypes.OPENED_USER_CARD,
  payload: {
    card
  }
});

export const clearCardsStore = () => ({
  type: actionTypes.CLEAR_CARDS_STORE,
  payload: {}
});
