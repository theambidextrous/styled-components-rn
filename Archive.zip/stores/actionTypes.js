/** Onboarding */
export const APP_LOADED = 'appLoaded';
export const TUTORIAL_SKIPPED = 'tutorialSkipped';

/** auth */
export const USER_REGISTERED = 'userRegistered';
export const USER_SIGNED_IN = 'userSignedIn';
export const USER_TOKEN_REFRESHED = 'userTokenRefreshed';
export const ENABLED_BIOMETRICS = 'enabledBiometrics';
export const CANCELLED_BIOMETRICS = 'cancelledBiometricsRequest';
export const CLEAR_USER_STORE = 'clearUserStore';

// Check out experience
export const ADD_TO_CART = 'ADD_TO_CART';
export const REMOVE_FROM_CART = 'REMOVE_FROM_CART';
export const CLEAR_CART = 'CLEAR_CART';

/** shop --> persist product to avoid calling api again */
export const OPENED_PRODUCT = 'openedProduct';
export const OPENED_CATEGORY = 'openedCategory';

/** Wishlist */
export const ADD_TO_WISHLIST = 'addToWishlist';
export const REMOVE_FROM_WISHLIST = 'removeFromWishlist';
export const SET_WISHLIST_POINTS = 'setWishlistPoints';
export const CLEAR_WISHLIST = 'clearWishlist';

// User points
export const SET_USER_TIER = 'setUserTier';
export const ADD_USER_POINTS = 'addUserPoints';
export const DEDUCT_USER_POINTS = 'deductUserPoints';
export const CLEAR_POINTS_STORE = 'clearPointsStore';

/** user Cards */
export const ADD_USER_CARD = 'addUserCard';
export const REMOVE_USER_CARD = 'removeUserCard';
export const OPENED_USER_CARD = 'openedUserCard';
export const UPDATE_USER_CARD_MRSID = 'updateUserCardMrsId';
export const CLEAR_CARDS_STORE = 'clearCardsStore';

/** Preferences */
export const SET_USER_PWR_PREF = 'setUserPwrPreference';
export const CLEAR_PREF_STORE = 'clearPreferenceStore';
export const SET_COBRAND_OFFER_PREF = 'setUserCobrandOfferPreference';
export const SET_DEMO_ADMIN_AUTHENTICATED = 'setDemoAdminAuthenticated';
export const SET_DEMO_ADMIN_PASS = 'setDemoAdminPassword';
export const SET_GENERAL_FEATURE_PREF = 'setGeneralFeaturePreference';

/** Push notification */
export const STORE_DEVICE_TOKEN = 'storeDeviceToken';
export const CLEAR_DEVICE_TOKEN = 'clearDeviceToken';

/** Demo users */
export const STORE_DEMO_USERS = 'storeDemoUsers';
export const STORE_SUPERUSER_SESSION = 'storeSuperUserSession';
export const CLEAR_DEMO_USERS = 'clearDemoUsers';

/** the other shop = ThirdParty */
export const STORE_THIRD_PARTY_PRODUCT = 'storeThirdPartyProduct';
export const SET_IS_THIRD_PARTY = 'setIsThirdParty';

/** store multistore appID */
export const SAVE_MULTISTORE_APP_ID = 'saveMultiStoreAppId';
export const SAVE_MULTISTORE_APP_THEME = 'saveMultiStoreAppTheme';
export const SAVE_MULTISTORE_THEME_IMAGES = 'saveMultiStoreThemeImages';
export const SAVE_MULTISTORE_THIRD_PART_ID = 'saveMultiStoreThirdPartyId';
