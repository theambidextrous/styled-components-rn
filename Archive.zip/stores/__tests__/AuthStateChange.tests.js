import * as actions from '@stores/actions/Authentication';
import * as ActionTypes from '@stores/actionTypes';
import AuthenticationReducer from '@stores/reducers/Authentication';

describe('Action creators unit tests', () => {
  test('should return loaded register action', () => {
    const sampleSignUpResponse = {
      acceptedTerms: true,
      city: 'Nairobi',
      countryCode: 'KEN',
      email: 'gffdddff.email@nttd.net',
      firstName: 'dddddddd',
      lastName: 'Cumberbatch',
      offersPreference: 'WEEKLY'
    };
    const actionRegisterUser = actions.userRegistered(
      sampleSignUpResponse,
      true
    );
    expect(actionRegisterUser).toEqual({
      type: ActionTypes.USER_REGISTERED,
      payload: {
        user: {
          acceptedTerms: true,
          city: 'Nairobi',
          countryCode: 'KEN',
          email: 'gffdddff.email@nttd.net',
          firstName: 'dddddddd',
          lastName: 'Cumberbatch',
          offersPreference: 'WEEKLY'
        },
        status: true
      }
    });
  });
  test('should return loaded login action', () => {
    const sampleLoginResResponse = {
      accessToken: 'Eyrts',
      tokenType: 'Bearer',
      expiresIn: 3600,
      refreshToken: 'Eyfft'
    };
    const actionLoginUser = actions.userSignedIn(sampleLoginResResponse, true);
    expect(actionLoginUser).toEqual({
      type: ActionTypes.USER_SIGNED_IN,
      payload: {
        session: {
          accessToken: 'Eyrts',
          tokenType: 'Bearer',
          expiresIn: 3600,
          refreshToken: 'Eyfft'
        },
        status: true
      }
    });
  });
  test('should return loaded biometric enable  state', () => {
    const hasFace = false;
    const hasFinger = true;
    const actionEnableBiometrics = actions.enabledBiometrics(
      hasFace,
      hasFinger
    );
    expect(actionEnableBiometrics).toEqual({
      type: ActionTypes.ENABLED_BIOMETRICS,
      payload: {
        hasFace: false,
        hasFinger: true
      }
    });
  });
  test('should return unloaded/cancelled biometric_enabled state', () => {
    const actionCancelBiometrics = actions.cancelledBiometricsRequest(true);
    expect(actionCancelBiometrics).toEqual({
      type: ActionTypes.CANCELLED_BIOMETRICS,
      payload: {
        status: true
      }
    });
  });
});

describe('state handlers unit tests', () => {
  test('should return the initial auth state', () => {
    expect(AuthenticationReducer(undefined, {})).toEqual({
      user: {},
      isRegistered: false,
      isLoggedIn: false,
      session: {},
      hasFaceUnlock: false,
      hasFingerUnlock: false,
      cancelledBiometricsRequest: false,
      biometricsAuthData: {}
    });
  });
  test('should return updated sign up state - containing received data', () => {
    const initialSampleState = {
      user: {},
      isRegistered: false,
      isLoggedIn: false,
      session: {},
      hasFaceUnlock: false,
      hasFingerUnlock: false,
      biometricsAuthData: {}
    };
    const sampleAction = {
      type: ActionTypes.USER_REGISTERED,
      payload: {
        user: {
          firstName: 'dddddddd',
          lastName: 'Cumberbatch',
          email: 'gffdddff.email@nttd.net',
          postalCode: 50200,
          streetAddress: '56 Gitanga Rd',
          countryCode: 'KEN',
          offersPreference: 'WEEKLY',
          notificationChannels: ['IN_APP_NOTIFICATIONS', 'EMAIL'],
          acceptedTerms: true
        },
        status: true
      }
    };
    const newSampleState = AuthenticationReducer(
      initialSampleState,
      sampleAction
    );
    expect(newSampleState).toEqual({
      user: {
        firstName: 'dddddddd',
        lastName: 'Cumberbatch',
        email: 'gffdddff.email@nttd.net',
        postalCode: 50200,
        streetAddress: '56 Gitanga Rd',
        countryCode: 'KEN',
        offersPreference: 'WEEKLY',
        notificationChannels: ['IN_APP_NOTIFICATIONS', 'EMAIL'],
        acceptedTerms: true
      },
      isRegistered: true,
      isLoggedIn: false,
      session: {},
      hasFaceUnlock: false,
      hasFingerUnlock: false,
      biometricsAuthData: {}
    });
  });

  test('should return updated login state - containing session data', () => {
    const initialSampleState = {
      user: {
        firstName: 'fname',
        lastName: 'lname'
      },
      isRegistered: true,
      isLoggedIn: false,
      session: {},
      hasFaceUnlock: false,
      hasFingerUnlock: false,
      biometricsAuthData: {}
    };
    const sampleAction = {
      type: ActionTypes.USER_SIGNED_IN,
      payload: {
        session: {
          accessToken: '12345',
          tokenType: 'A',
          expiresIn: 10
        },
        status: true
      }
    };
    const newSampleState = AuthenticationReducer(
      initialSampleState,
      sampleAction
    );
    expect(newSampleState).toEqual({
      user: {
        firstName: 'fname',
        lastName: 'lname'
      },
      isRegistered: true,
      isLoggedIn: true,
      session: {
        accessToken: '12345',
        tokenType: 'A',
        expiresIn: 10
      },
      hasFaceUnlock: false,
      hasFingerUnlock: false,
      biometricsAuthData: {}
    });
  });
});
