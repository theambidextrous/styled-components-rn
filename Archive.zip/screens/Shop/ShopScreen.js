import React, { useState, useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import { useDispatch, useSelector } from 'react-redux';

// Mastercard API
import { ProductsApi } from 'mastercard_loyalty_sandbox_api';

// Actions
import * as actions from '@stores/actions';

// Utils
import {
  client,
  extractError,
  theme,
  CategoryListFormatter,
  getStatusBar,
  WOOCOMERCE_TIMEOUT
} from '@utils/index';

// Components
import {
  CustomStatusBar,
  PageBodyFiltersHolder,
  CategoryDetailsView,
  CategoryGridView,
  Text,
  CategoriesSkeleton,
  LoaderSkeleton
} from '@components';

const ShopScreen = ({ navigation }) => {
  const appState = useSelector((state) => state);
  const currentShop = appState.multiStore;
  const { applicationId } = currentShop;
  const { tierName } = appState.points;
  const dispatcher = useDispatch();
  const [viewState, SetViewState] = useState({
    key: 0,
    cols: 2,
    details: true
  });
  const [allCategories, SetCategories] = useState({
    error: '',
    items: [],
    count: 0,
    isLoading: true
  });
  const ActiveStateHandler = (key) => {
    let details = true;
    let cols = 1;
    if (key > 0) {
      details = false;
    }
    if (key === 1) {
      cols = 2;
    }
    SetViewState({
      key,
      cols,
      details
    });
  };
  const OnCategoryPressed = (item) => {
    dispatcher(actions.openedCategory(item));
    navigation.navigate('Category', { category: item });
  };

  const GetAllCategories = (page, limit) => {
    try {
      const offset = page === 1 ? 0 : page * limit;
      client.defaultHeaders = { 'App-Id': applicationId };
      client.timeout = WOOCOMERCE_TIMEOUT;
      const api = new ProductsApi(client);
      api.getProductCategoryList(
        { page, limit, offset, order: 'asc', orderBy: 'name' },
        (error, data, response) => {
          // console.log('error', error);
          if (response !== undefined && Number(response.statusCode) < 205) {
            const categoriesPayload = response.body.categories;
            const ItemList = CategoryListFormatter(categoriesPayload);
            const count = ItemList.reduce((previousValue, currentValue) => ({
              count: Number(previousValue.count) + Number(currentValue.count)
            }));
            SetCategories({
              ...allCategories,
              items: ItemList,
              count: count.count,
              isLoading: false
            });
          } else {
            /** error */
            const errorData = extractError(error);
            SetCategories({
              ...allCategories,
              error: errorData.Details,
              isLoading: false
            });
          }
        }
      );
    } catch (error) {
      SetCategories({
        ...allCategories,
        error: 'could not fetch data, try again later',
        isLoading: false
      });
    }
  };

  useEffect(() => {
    GetAllCategories(1, 10);
    return () => {};
  }, []);
  return (
    <>
      <CustomStatusBar isLightContent={getStatusBar(tierName)} />
      <StyledSafeAreaView>
        <Container showsVerticalScrollIndicator={false}>
          <HorizontalPadding>
            <Text as="H1">Categories</Text>
            {allCategories.isLoading ? (
              <LoaderSkeleton />
            ) : (
              <Text as="P3" style={{ color: theme.colors.textSecondary }}>
                {`${allCategories.count} Products`}
              </Text>
            )}
          </HorizontalPadding>
          <PageBodyFiltersHolder
            ActiveStateHandler={ActiveStateHandler}
            active={viewState.key}
          />
          <View style={JsxStyle.FlatListHolder}>
            {allCategories.isLoading && <CategoriesSkeleton />}
            {viewState.details ? (
              allCategories.items.map((item, key) => (
                <CategoryDetailsView
                  key={key}
                  item={item}
                  OnCategoryPressed={OnCategoryPressed}
                />
              ))
            ) : (
              <MultiColumnHolderView>
                {allCategories.items.map((item, key) => (
                  <CategoryGridView
                    key={key}
                    item={item}
                    cols={viewState.cols}
                    OnCategoryPressed={OnCategoryPressed}
                  />
                ))}
              </MultiColumnHolderView>
            )}
          </View>
        </Container>
      </StyledSafeAreaView>
    </>
  );
};

const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;

const HorizontalPadding = styled.View`
  padding: 0 20px;
`;

const Container = styled.ScrollView`
  flex: 9;
  margin-top: 20px;
  width: 100%;
  height: 100%;
`;
const MultiColumnHolderView = styled.View`
  margin-top: 10px;
  flex-direction: row;
  justify-content: flex-start;
  flex: 1;
  flex-wrap: wrap;
`;

ShopScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};
const JsxStyle = StyleSheet.create({
  FlatListHolder: {
    marginHorizontal: 15,
    marginVertical: 10,
    paddingBottom: 50
  }
});

export default ShopScreen;
