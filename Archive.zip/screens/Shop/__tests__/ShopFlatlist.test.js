import React from 'react';
import { Provider } from 'react-redux';
import { store } from '@stores';
import { render, waitFor } from '@testing-library/react-native';
import { ProductFlatList } from '@components';

describe('Product list', () => {
  const OnProductPressed = () => null;
  const fetchMore = () => null;
  const products = {
    error: null,
    items: [
      {
        key: 0,
        id: 123,
        name: 'abc',
        price: String(20),
        salePrice: String(18),
        image: 'https://via.placeholder.com/160',
        category: 'others'
      },
      {
        key: 1,
        id: 124,
        name: 'txy',
        price: String(30),
        salePrice: String(26),
        image: 'https://via.placeholder.com/160',
        category: 'clothing'
      }
    ],
    isLoading: false
  };
  test('renders a list of products : Details view', async () => {
    const viewState = {
      key: 0,
      cols: 0,
      details: true,
      tracker: 1
    };
    const { queryByTestId, getByText } = render(
      <Provider store={store}>
        <ProductFlatList
          products={products}
          viewState={viewState}
          OnProductPressed={OnProductPressed}
          fetchMore={fetchMore}
        />
      </Provider>
    );
    /** list not rendered yet */
    expect(queryByTestId('product-entry-0')).toBeNull();

    await waitFor(() => queryByTestId('product-entry-0'));
    /** price rendered with dollar symbol */
    expect(getByText('$20')).toBeTruthy();
    /** Sale price rendered with dollar symbol */
    expect(getByText('$18')).toBeTruthy();
    /** name rendered */
    expect(getByText('txy')).toBeTruthy();
    /** category name rendered */
    expect(getByText('clothing')).toBeTruthy();
  });
  test('renders a list of products : Grid view : 2 columns', async () => {
    const viewState = {
      key: 1,
      cols: 2,
      details: false,
      tracker: 2
    };
    const { queryByTestId, getByText } = render(
      <Provider store={store}>
        <ProductFlatList
          products={products}
          viewState={viewState}
          OnProductPressed={OnProductPressed}
          fetchMore={fetchMore}
        />
      </Provider>
    );
    /** list not rendered yet */
    expect(queryByTestId('product-entry-0')).toBeNull();

    await waitFor(() => queryByTestId('product-entry-0'));
    /** price rendered with dollar symbol */
    expect(getByText('$20')).toBeTruthy();
    /** Sale price rendered with dollar symbol */
    expect(getByText('$18')).toBeTruthy();
    /** name rendered */
    expect(getByText('txy')).toBeTruthy();
    /** category name rendered */
    expect(getByText('clothing')).toBeTruthy();
  });
  test('renders a list of products : Grid view : 1 column', async () => {
    const viewState = {
      key: 2,
      cols: 1,
      details: false,
      tracker: 3
    };
    const { queryByTestId, getByText } = render(
      <Provider store={store}>
        <ProductFlatList
          products={products}
          viewState={viewState}
          OnProductPressed={OnProductPressed}
          fetchMore={fetchMore}
        />
      </Provider>
    );
    /** list not rendered yet */
    expect(queryByTestId('product-entry-0')).toBeNull();

    await waitFor(() => queryByTestId('product-entry-0'));
    /** price rendered with dollar symbol */
    expect(getByText('$20')).toBeTruthy();
    /** Sale price rendered with dollar symbol */
    expect(getByText('$18')).toBeTruthy();
    /** name rendered */
    expect(getByText('txy')).toBeTruthy();
    /** category name rendered */
    expect(getByText('clothing')).toBeTruthy();
  });
});
