/* eslint-disable no-confusing-arrow */
import React, { useState } from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ifIphoneX } from 'react-native-iphone-x-helper';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  theme,
  FormatLocalProxyForAndroid,
  triggerSuccessHaptic,
  triggerWarningHaptic,
  getStatusBar,
  getTierBadge
} from '@utils';

import {
  ShopPriceComponent,
  ShopActionsText,
  PrimaryButton,
  CustomStatusBar,
  TriggerLocalNotification,
  Text,
  MemberShipIcon
} from '@components';
import * as actions from '@stores/actions';

const SingleProductScreen = () => {
  const persistedState = useSelector((state) => state);
  const { isThirdParty } = persistedState.thirdParty;
  const userTier = persistedState.points;
  const {
    tierName,
    coBrandPointsConversionFactor,
    pointsConversionFactor,
    pcloPointsConversionFactor
  } = userTier;
  const product = persistedState.shop.product;
  const [cartEntry, SetCartEntryState] = useState({
    id: product.id,
    name: product.name,
    price: product.salePrice,
    category: product.category,
    image: product.image,
    quantity: 1,
    size: null,
    color: null,
    sizes: product.sizes,
    colors: product.colors
  });

  const dispatch = useDispatch();

  const OnSizeChange = (size) => {
    SetCartEntryState({ ...cartEntry, size });
  };

  const OnColorChange = (color) => {
    SetCartEntryState({ ...cartEntry, color });
  };

  const OnQtyReduce = () => {
    SetCartEntryState({
      ...cartEntry,
      quantity: cartEntry.quantity > 1 ? cartEntry.quantity - 1 : 0
    });
  };

  const OnQtyIncrease = () => {
    SetCartEntryState({
      ...cartEntry,
      quantity: cartEntry.quantity < 10 ? cartEntry.quantity + 1 : 10
    });
  };

  const ComputeBannerPoints = () => {
    const bagTotals = product.salePrice;
    const normal = pointsConversionFactor * bagTotals;
    const cobrand = coBrandPointsConversionFactor * bagTotals - normal;
    const thirdParty = isThirdParty
      ? pcloPointsConversionFactor * bagTotals
      : 0;
    return [normal + thirdParty, cobrand];
  };

  const addToCart = () => {
    dispatch(actions.setIsThirdParty(false));
    let message;
    const type = 'info';
    const icon = 'info';
    if (product.sizes.length > 0 && cartEntry.size === null) {
      message = 'Please select a size';
      TriggerLocalNotification({ message, type, icon });
      triggerWarningHaptic();
      return;
    }
    if (product.colors.length > 0 && cartEntry.color === null) {
      message = 'Please select a color';
      TriggerLocalNotification({ message, type, icon });
      triggerWarningHaptic();
      return;
    }

    if (cartEntry.quantity < 1) {
      message = 'Please select quantity';
      TriggerLocalNotification({ message, type, icon });
      triggerWarningHaptic();
      return;
    }
    dispatch(actions.addToCart(cartEntry));
    message = 'Added to bag';
    TriggerLocalNotification({ message, type: 'success', icon: 'success' });
    triggerSuccessHaptic();
  };

  return (
    <>
      <CustomStatusBar isLightContent={getStatusBar(tierName)} />
      <>
        <Container showsVerticalScrollIndicator={false}>
          <PointsBanner>
            <BannerWrapper>
              <MemberShipIcon source={getTierBadge(tierName)} />
            </BannerWrapper>
            <BannerTextWrapper>
              {/* normal points */}
              <BenefitsRow>
                <LabelsTextWrapper>
                  <TierTitle>{`${tierName} Benefit:`}</TierTitle>
                </LabelsTextWrapper>
                <ValuesTextWrapper>
                  <ShopActionsText
                    style={{
                      fontFamily: 'Montserrat-Bold',
                      textAlign: 'right'
                    }}
                    text={`${ComputeBannerPoints()[0]} points`}
                    size={13}
                    lineHeight={15}
                    weight={800}
                    transform="none"
                    color={theme.colors.textWhite}
                  />
                </ValuesTextWrapper>
              </BenefitsRow>
              {/* cobrand points */}
              <BenefitsRow>
                <LabelsTextWrapper>
                  <TierTitle>Co-brand benefit:</TierTitle>
                </LabelsTextWrapper>
                <ValuesTextWrapper>
                  <ShopActionsText
                    style={{ fontFamily: 'Montserrat', textAlign: 'right' }}
                    text={`${ComputeBannerPoints()[1]} points`}
                    size={13}
                    lineHeight={15}
                    weight={800}
                    transform="none"
                    color={theme.colors.textWhite}
                  />
                </ValuesTextWrapper>
              </BenefitsRow>
            </BannerTextWrapper>
          </PointsBanner>
          <View style={JsxStyle.FlatListHolder}>
            <RowView style={{ alignItems: 'center' }}>
              <SingleFlexView>
                <ShopActionsText
                  text={product.name}
                  size={14}
                  lineHeight={20}
                  weight={500}
                  transform="none"
                  color={theme.colors.textPrimary}
                  style={{ fontFamily: 'MarkOffcPro', fontWeight: 'bold' }}
                />
                <ShopActionsText
                  text={product.category}
                  size={12}
                  lineHeight={18}
                  weight={400}
                  transform="none"
                  color={theme.colors.textPrimary}
                />
              </SingleFlexView>
              <SingleFlexLeftItems>
                <ShopPriceComponent
                  price={product.price}
                  salePrice={product.salePrice}
                  direction="column"
                  style={{ fontFamily: 'MarkOffcPro-Bold' }}
                />
              </SingleFlexLeftItems>
            </RowView>
            <ViewSpacer />
            <RowView>
              <ProductImage
                resizeMode="contain"
                source={{ uri: FormatLocalProxyForAndroid(product.image) }}
              />
            </RowView>
            <ViewSpacer />
            {Array.isArray(product.sizes) && product.sizes.length > 0 && (
              <>
                <RowView>
                  <View>
                    <ShopActionsText
                      text="Size"
                      size={15}
                      lineHeight={22}
                      weight={500}
                      transform="none"
                      color={theme.colors.textPrimary}
                      style={{ fontFamily: 'MarkOffcPro-Bold' }}
                    />
                    <AttributeHolder>
                      {product.sizes.map((item, index) => (
                        <TouchableOpacity
                          key={index}
                          onPress={() => OnSizeChange(item)}
                        >
                          <SizeBox selected={cartEntry.size === item}>
                            <ShopActionsText
                              text={item}
                              size={16}
                              lineHeight={22}
                              weight={500}
                              transform="none"
                              style={{
                                fontFamily: 'MarkOffcPro-Bold',
                                alignItems: 'center'
                              }}
                              color={
                                cartEntry.size === item
                                  ? theme.colors.textWhite
                                  : theme.colors.textPrimary
                              }
                            />
                          </SizeBox>
                        </TouchableOpacity>
                      ))}
                    </AttributeHolder>
                  </View>
                </RowView>
                <ViewSpacer />
              </>
            )}
            {Array.isArray(product.colors) && product.colors.length > 0 && (
              <RowView>
                <View>
                  <ShopActionsText
                    text="Color"
                    size={14}
                    lineHeight={22}
                    weight={500}
                    transform="none"
                    color={theme.colors.textPrimary}
                    style={{ fontFamily: 'MarkOffcPro-Bold' }}
                  />
                  <AttributeHolder>
                    {product.colors.map((item, index) => (
                      <TouchableOpacity
                        key={index}
                        onPress={() => OnColorChange(item)}
                      >
                        <ColorBox
                          bgColor={item.toLowerCase()}
                          selected={cartEntry.color === item}
                        />
                      </TouchableOpacity>
                    ))}
                  </AttributeHolder>
                </View>
              </RowView>
            )}
            <ViewSpacer />
            <RowView>
              <View>
                <ShopActionsText
                  text="Quantity"
                  size={15}
                  lineHeight={22}
                  weight={500}
                  transform="none"
                  style={{ fontFamily: 'MarkOffcPro-Bold' }}
                  color={theme.colors.textPrimary}
                />
                {/* Qty component */}
                <View style={JsxStyle.QtyHolder}>
                  <View>
                    <QuantityButtonBox onPress={OnQtyReduce}>
                      <MIcon
                        color={theme.colors.textPrimary}
                        name="minus-circle"
                        size={20}
                      />
                    </QuantityButtonBox>
                  </View>
                  <View>
                    <QuantityInputBox>
                      <Text>{cartEntry.quantity}</Text>
                    </QuantityInputBox>
                  </View>
                  <View>
                    <QuantityButtonBox onPress={OnQtyIncrease}>
                      <MIcon
                        color={theme.colors.textPrimary}
                        name="plus-circle"
                        size={20}
                      />
                    </QuantityButtonBox>
                  </View>
                </View>
              </View>
            </RowView>
            {/* Add to cart  */}
            <ViewSpacer />
          </View>
        </Container>
        <BtnContainer
          style={{
            ...ifIphoneX(
              {
                paddingBottom: 26
              },
              {
                paddingBottom: 16
              }
            )
          }}
        >
          <PrimaryButton
            title="Add to bag"
            onPress={() => addToCart()}
            loading={false}
          />
        </BtnContainer>
      </>
    </>
  );
};
const Container = styled.ScrollView`
  background-color: ${theme.colors.textWhite};
  padding-top: 10px;
`;

const RowView = styled.View`
  flex-direction: row;
`;

const SingleFlexView = styled.View`
  flex: 1;
`;

const SingleFlexLeftItems = styled.View`
  margin-left: auto;
`;

const ViewSpacer = styled.View`
  height: 20px;
`;

const ProductImage = styled.Image`
  width: 100%;
  border-radius: 6px;
  /* background-color: ${theme.colors.backgroundColor}; */
  height: 226px;
`;

const SizeBox = styled.View`
  flex: 1;
  min-width: 55px;
  min-height: 44px;
  /* background-color: ${theme.colors.backgroundColor}; */
  border-radius: 4px;
  justify-content: center;
  align-items: center;
  margin-right: 10px;
  margin-bottom: 10px;
  padding: 10px;
  /* border-width: ${(props) => (props.selected ? 2 : 0)}px; */
  background-color: ${(props) =>
    props.selected ? theme.colors.black : theme.colors.backgroundColor};
`;

const AttributeHolder = styled.View`
  flex-direction: row;
  flex-wrap: wrap;
  margin-top: 7px;
`;

const ColorBox = styled.View`
  width: 55px;
  height: 44px;
  background-color: ${(props) => props.bgColor};
  border-radius: 6px;
  justify-content: center;
  align-items: center;
  padding: 10px;
  margin-right: 10px;
  margin-bottom: 10px;
  border-width: ${(props) => (props.selected ? 2 : 1)}px;
  border-color: ${(props) =>
    props.selected ? theme.colors.black : theme.colors.border};
`;

const QuantityButtonBox = styled.TouchableOpacity`
  min-width: 50px;
  min-height: 50px;
  background-color: ${theme.colors.backgroundColor};
  border-radius: 4px;
  justify-content: center;
  align-items: center;
  margin-right: 10px;
  margin-bottom: 10px;
`;

const QuantityInputBox = styled.View`
  min-width: 50px;
  min-height: 50px;
  background-color: ${theme.colors.textWhite};
  border-radius: 4px;
  justify-content: center;
  align-items: center;
  margin-right: 10px;
  margin-bottom: 10px;
`;

const BtnContainer = styled.View`
  padding: 20px 33px 26px 33px;
  justify-content: flex-end;
`;

const BannerWrapper = styled.View`
  flex: 1;
  align-items: flex-start;
  justify-content: center;
`;
const BannerTextWrapper = styled.View`
  flex: 5;
  justify-content: center;
`;
const LabelsTextWrapper = styled.View`
  flex: 3;
  padding-right: 4px;
`;
const ValuesTextWrapper = styled.View`
  flex-direction: row;
`;
const BenefitsRow = styled.View`
  flex: 1;
  flex-direction: row;
  margin-top: 5px;
`;
const TierTitle = styled.Text`
  font-size: 14px;
  font-weight: 700;
  line-height: 18px;
  margin-bottom: 5px;
  font-family: 'Montserrat';
  color: ${theme.colors.textWhite};
`;
const PointsBanner = styled.View`
  flex-direction: row;
  background-color: ${(props) =>
    props.theme.colors.primary || theme.colors.primary};
  padding: 10px 16px;
  margin: 0 16px;
  border-radius: 4px;
  margin-bottom: 10px;
`;

SingleProductScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

const JsxStyle = StyleSheet.create({
  FlatListHolder: {
    flex: 1,
    marginHorizontal: 15,
    marginVertical: 10,
    paddingBottom: 50
  },
  QtyHolder: {
    marginBottom: 10,
    flexDirection: 'row',
    marginTop: 10
  },
  BottomStickyView: {
    marginHorizontal: 30,
    height: 100,
    justifyContent: 'center'
  }
});

export default SingleProductScreen;
