import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import { useDispatch, useSelector } from 'react-redux';
import * as actions from '@stores/actions';
import { theme, getStatusBar } from '@utils';
import {
  CustomStatusBar,
  PageBodyFiltersHolder,
  Text,
  ProductFlatList,
  LoaderSkeleton
} from '@components';
import LoadingIndicator from '@components/LoadingIndicator';
import useStreamProducts from './Hooks/StreamProducts';

const CategoryDetailsScreen = ({ navigation }) => {
  const dispatcher = useDispatch();
  const persistedState = useSelector((state) => state);
  const currentShop = persistedState.multiStore;
  const { applicationId } = currentShop;

  const { tierName } = persistedState.points;
  const category = persistedState.shop.category;
  const categoryId = category.id;
  const [products, fetchMore] = useStreamProducts(categoryId, applicationId);
  const [viewState, SetViewState] = useState({
    key: 0,
    cols: 0,
    details: true,
    tracker: 1
  });
  const ActiveStateHandler = (key) => {
    if (key === 0) {
      SetViewState({
        ...viewState,
        tracker: viewState.tracker + 1,
        details: true,
        cols: 0,
        key
      });
    } else if (key === 1) {
      SetViewState({
        ...viewState,
        tracker: viewState.tracker + 1,
        cols: 2,
        details: false,
        key
      });
    } else if (key === 2) {
      SetViewState({
        ...viewState,
        tracker: viewState.tracker + 1,
        cols: 1,
        details: false,
        key
      });
    }
  };
  const OnProductPressed = (item) => {
    dispatcher(actions.openedProduct(item));
    navigation.navigate('Checkout', { product: item });
  };

  const HeaderComponent = () => (
    <>
      <HorizontalPadding>
        <Text as="H1">{category.name}</Text>
        {products.isLoading ? (
          <LoaderSkeleton />
        ) : (
          <Text style={{ color: theme.colors.textSecondary }} as="P3">
            {`${products.items.length} Products`}
          </Text>
        )}
      </HorizontalPadding>
      <PageBodyFiltersHolder
        ActiveStateHandler={ActiveStateHandler}
        active={viewState.key}
      />
    </>
  );

  const FooterComponent = () => products.isLoading && <LoadingIndicator />;
  return (
    <>
      <CustomStatusBar isLightContent={getStatusBar(tierName)} />
      <StyledSafeAreaView>
        <Container>
          <View style={JsxStyle.FlatListHolder}>
            <ProductFlatList
              products={products}
              ListHeaderComponent={HeaderComponent}
              ListFooterComponent={FooterComponent}
              viewState={viewState}
              OnProductPressed={OnProductPressed}
              fetchMore={products.endHasReached ? () => undefined : fetchMore}
            />
          </View>
        </Container>
      </StyledSafeAreaView>
    </>
  );
};

const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;
const HorizontalPadding = styled.View`
  padding: 20px 20px 0px 20px;
`;
const Container = styled.View`
  /* flex: 9; */
  width: 100%;
  height: 100%;
`;

CategoryDetailsScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};
const JsxStyle = StyleSheet.create({
  FlatListHolder: {}
});

export default CategoryDetailsScreen;
