import { useState, useEffect, useCallback } from 'react';
import { ProductsApi } from 'mastercard_loyalty_sandbox_api';
import { client, ProductListFormatter, WOOCOMERCE_TIMEOUT } from '@utils';

export default function useStreamProducts(categoryId, applicationId) {
  const [currentPage, setPage] = useState(1);
  const [shouldFetch, setShouldFetch] = useState(true);
  const [products, setProducts] = useState({
    error: null,
    items: [],
    isLoading: true,
    endHasReached: false
  });
  const fetchMore = useCallback(() => setShouldFetch(true), []);

  useEffect(() => {
    if (!shouldFetch) {
      return;
    }
    const GetProductsByCategory = (category, page, limit) => {
      setProducts({
        ...products,
        isLoading: true
      });
      const offset = page === 1 ? 0 : page * limit;
      client.defaultHeaders = { 'App-Id': applicationId };
      client.timeout = WOOCOMERCE_TIMEOUT;
      const api = new ProductsApi(client);
      api.getProductList(
        {
          page,
          limit,
          offset,
          order: 'desc',
          category
        },
        (error, data, response) => {
          setShouldFetch(false);
          if (Number(response && response.statusCode) < 205) {
            if (
              Array.isArray(response.body.products) &&
              response.body.products.length > 0
            ) {
              const productsPayload = response.body.products;
              // console.log('productsPayload', productsPayload);
              const newProducts = ProductListFormatter(productsPayload);
              setProducts({
                ...products,
                isLoading: false,
                items: [...products.items, ...newProducts],
                endHasReached: limit > newProducts.length
              });
            } else {
              setProducts({
                ...products,
                isLoading: false,
                items: [...products.items],
                endHasReached: true
              });
            }
          } else {
            /** error */
            setProducts({
              ...products,
              isLoading: false,
              items: [...products.items]
            });
          }
          setPage(currentPage + 1);
        }
      );
    };
    GetProductsByCategory(categoryId, currentPage, 10);
  }, [currentPage, shouldFetch]);
  return [products, fetchMore];
}
