import { useState, useEffect, useCallback } from 'react';
import { ProductsApi } from 'mastercard_loyalty_sandbox_api';
import { client, WOOCOMERCE_TIMEOUT } from '@utils';

export default function useStreamCategories() {
  const [currentPage, setPage] = useState(1);
  const [shouldFetch, setShouldFetch] = useState(true);
  const [categories, setCategories] = useState([]);
  const fetchMore = useCallback(() => setShouldFetch(true), []);

  useEffect(() => {
    if (!shouldFetch) {
      return;
    }
    const GetCategories = (page, perPage) => {
      const offset = page === 1 ? 0 : page * perPage;
      client.defaultHeaders = {};
      client.timeout = WOOCOMERCE_TIMEOUT;
      const api = new ProductsApi(client);
      api.getProductCategoryList(
        {
          page,
          perPage,
          offset,
          order: 'desc',
          orderBy: 'date'
        },
        (error, data, response) => {
          setShouldFetch(false);
          if (Number(response && response.statusCode) < 205) {
            if (Array.isArray(response.body)) {
              const newCategories = response.body;
              setCategories((oldCategories) => [
                ...oldCategories,
                ...newCategories
              ]);
            } else {
              setCategories((oldCategories) => [...oldCategories]);
            }
          } else {
            /** error */
            setCategories((oldCategories) => [...oldCategories]);
          }
          setPage(currentPage + 1);
        }
      );
    };
    GetCategories(currentPage, 10);
  }, [currentPage, shouldFetch]);
  return [categories, fetchMore];
}
