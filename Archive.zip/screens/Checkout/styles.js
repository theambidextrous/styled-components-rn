/* eslint-disable no-confusing-arrow */
import React from 'react';
import styled from 'styled-components/native';
import { theme } from '@utils';

const successImage = require('@assets/images/others/success.png');

export const StyledScrollView = styled.ScrollView`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;

export const StyledView = styled.View`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;

export const HorizontalPadding = styled.View`
  padding: 20px;
`;

export const EmptyStateContainer = styled.View`
  flex: 1;
  align-items: center;
  margin-top: 88px;
`;

export const EmptyStateImage = styled.View`
  width: 50px;
  height: 50px;
  background-color: ${(props) =>
    props.theme.colors.primary || props.theme.primary};
  border-radius: 50px;
  align-items: center;
  justify-content: center;
  margin-bottom: 16px;
`;

export const EmptyStateSpacing = styled.View`
  margin-bottom: 12px;
  align-items: center;
`;

export const PaymentWrapper = styled.View`
  padding-top: 40px;
`;
export const PaymentRow = styled.View`
  flex-direction: row;
  justify-content: space-between;
`;

const ModalImage = styled.Image`
  height: 70px;
  width: 70px;
  align-self: center;
  margin: 23px 0;
`;

export const StyledModalSubTitle = styled.Text`
  font-family: 'Montreal';
  font-size: 18px;
  line-height: 21px;
  text-align: center;
  color: ${theme.colors.textDarkGrey};
  margin-bottom: 23px;
`;

export const StyledModalTitle = styled.Text`
  font-family: 'MontrealSerialBold';
  font-size: 30px;
  line-height: 36px;
  text-align: center;
  color: ${theme.colors.modalTextBlack};
  margin-bottom: 15px;
`;
export const ColorBox = styled.TouchableOpacity`
  width: 55px;
  height: 44px;
  background-color: ${(props) => props.bgColor};
  border-radius: 6px;
  justify-content: center;
  align-items: flex-start;
  padding: 10px;
  margin-right: 10px;
  margin-bottom: 10px;
  border-width: ${(props) => (props.selected ? 1 : 1)}px;
  border-color: ${(props) =>
    props.selected ? theme.colors.primary : theme.colors.border};
`;

export const SizeBox = styled.TouchableOpacity`
  min-width: 55px;
  min-height: 44px;
  background-color: ${theme.colors.backgroundColor};
  border-radius: 4px;
  align-items: flex-start;
  margin-right: 10px;
  margin-bottom: 10px;
  padding: 10px;
  border-width: ${(props) => (props.selected ? 2 : 0)}px;
  border-color: ${(props) =>
    props.selected ? theme.colors.primary : theme.colors.none};
`;

export const AttributeHolder = styled.View`
  flex: 1;
  flex-direction: row;
  padding: 12px;
  flex-wrap: wrap;
`;
export const ButtonContainer = styled.View`
  justify-content: flex-end;
  padding: 12px 0;
`;

export const ModalHeaderContainer = styled.View`
  align-items: center;
  padding: 12px 0;
`;

export const OfferContainer = styled.View``;

export const Gap = styled.View`
  padding: 6px 0;
  background-color: ${theme.colors.backgroundColor};
`;

export const ModalDetails = () => (
  <>
    <ModalImage source={successImage} />
    <StyledModalTitle>Order Placed</StyledModalTitle>
    <StyledModalSubTitle>
      Your items are on the way and should arrive shortly
    </StyledModalSubTitle>
  </>
);
