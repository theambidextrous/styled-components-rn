import React, { useState } from 'react';
import { Switch, StyleSheet, Platform, Alert } from 'react-native';
import { OffersApi, PreferencesRequest } from 'mastercard_loyalty_sandbox_api';
import * as actions from '@stores/actions';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { useTheme } from 'styled-components';
import { useSelector, useDispatch } from 'react-redux';
import { CheckoutRow, CreditCard, LoadingIndicator } from '@components/index';
import {
  cartTotal,
  theme,
  AppTracker,
  RefreshAuthToken,
  extractError,
  client
} from '@utils/index';

const CheckoutPreferenceScreen = ({ route, navigation }) => {
  /**  tracker */
  const apptracker = new AppTracker();
  // theme
  const shopTheme = useTheme();
  const dispatch = useDispatch();
  const discountsData = route.params.discountsPayload;
  const selectedCard = route.params.card;
  const discountedAmount = discountsData.reduce(
    (prev, { amount }) => prev + amount,
    0
  );
  const appState = useSelector((state) => state);
  const userState = appState.authentication;
  const { accessToken, refreshToken, expiresAt } = userState.session;
  const { isThirdParty } = appState.thirdParty;
  const cartState = appState.cart;
  const { items } = cartState;
  const billAmount = cartTotal(items);
  const currentCard = selectedCard;
  const { pan, name, expiryMonth, expiryYear } = currentCard;
  const renderableCard = {
    mask: pan,
    name,
    validUntil: `${expiryMonth}/${expiryYear.slice(-2)}`
  };
  const defaultRedemptionFrequency = currentCard.redemptionFrequency;
  /** preference */
  const [preference, SetPreference] = useState(defaultRedemptionFrequency);
  const [switchIsDisabled, SetDisabled] = useState(false);
  const [loading, SetLoading] = useState(false);

  const SwitchTheme = {
    false: theme.colors.grey,
    true: shopTheme.colors.primary || theme.colors.primary
  };

  const UpdatePreference = async (Pref) => {
    SetDisabled(true); /** disabled switch */
    SetLoading(true);
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const api = new OffersApi(client);
    const preferenceRequest = PreferencesRequest.constructFromObject({
      accountId: currentCard.value,
      redemptionFrequency: Pref
    });
    api.setPreferences(
      preferenceRequest,
      { authorization: `Bearer ${newTkn.accessToken}` },
      (error, data, response) => {
        if (response && response.statusCode < 205) {
          const { redemptionFrequency } = response.body;
          dispatch(actions.setUserPwrPreference(redemptionFrequency));
          SetDisabled(false);
          SetPreference(redemptionFrequency);
          SetLoading(false);
        } else {
          const errorData = extractError(error);
          apptracker.logCardsFailure('Card preference failure', {
            errorCode: response.statusCode,
            errorMessage: errorData.Details
          });
          SetLoading(false);
          SetDisabled(false);
          Alert.alert('Oops, something went wrong', errorData.Details);
        }
      }
    );
  };

  const SwitchPreferenceAll = () => {
    const nextState = preference === 'OFF' ? 'MULT' : 'OFF';
    UpdatePreference(nextState);
    SetPreference(nextState);
  };
  const SwitchPreferenceNext = () => {
    const nextState = preference === 'MULT' ? 'SNGL' : 'MULT';
    UpdatePreference(nextState);
    SetPreference(nextState);
  };

  return (
    <>
      <StyledScrollView>
        <Wrapper>
          <HeaderSection>
            <PwrPageTitle>Turn On Preferences</PwrPageTitle>
            <PwrPageGap />
            <PwrPageSubTitle>
              Turn
              <PwrPageSubTitleHeavy> pay with rewards </PwrPageSubTitleHeavy>
              preferences on to pay with your accumulated points
            </PwrPageSubTitle>
            <PwrPageGap />
            <CardWrapper>
              <CreditCard
                card={renderableCard}
                isCoBrand={currentCard.isCobrand}
                OnCardPressed={() => null}
                pointsBalance={0}
              />
            </CardWrapper>
          </HeaderSection>
          <CardAPreferenceSection>
            <PrefSwitchWrapper>
              <PrefSwitchColumn flex={3}>
                <SectionRow>
                  <PwrSwitchLabel>Turn On Pay with rewards</PwrSwitchLabel>
                  {loading && (
                    <PreloadWrapper>
                      <LoadingIndicator />
                    </PreloadWrapper>
                  )}
                </SectionRow>
              </PrefSwitchColumn>
              <PrefSwitchColumn flex={1} pullRight>
                <Switch
                  disabled={switchIsDisabled}
                  trackColor={SwitchTheme}
                  thumbColor={SwitchTheme.false}
                  onValueChange={SwitchPreferenceAll}
                  value={preference !== 'OFF'}
                  style={Jsx.switchTransform}
                />
              </PrefSwitchColumn>
            </PrefSwitchWrapper>
            {preference !== 'OFF' && (
              <PrefSwitchWrapper>
                <PrefSwitchColumn flex={3}>
                  <PwrSwitchLabel>Only use for this purchase</PwrSwitchLabel>
                </PrefSwitchColumn>
                <PrefSwitchColumn flex={1} pullRight>
                  <Switch
                    disabled={switchIsDisabled}
                    trackColor={SwitchTheme}
                    thumbColor={SwitchTheme.false}
                    onValueChange={SwitchPreferenceNext}
                    value={preference === 'SNGL'}
                    style={Jsx.switchTransform}
                  />
                </PrefSwitchColumn>
              </PrefSwitchWrapper>
            )}
          </CardAPreferenceSection>
        </Wrapper>
      </StyledScrollView>
      <CheckoutRow
        onPress={() =>
          navigation.push('Confirmation', {
            card: selectedCard,
            discountsPayload: discountsData
          })
        }
        btnText="Confirmation"
        disabled={loading}
        discountedAmount={discountedAmount}
        totalAmount={billAmount}
        isDark={isThirdParty}
      />
    </>
  );
};

const StyledScrollView = styled.ScrollView`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
  background-color: ${theme.colors.backgroundColor};
`;
const Wrapper = styled.View`
  flex: 1;
  background-color: ${theme.colors.backgroundColor};
`;
const Jsx = StyleSheet.create({
  switchTransform: {
    transform: [
      { scaleX: Platform.OS === 'ios' ? 0.9 : 1.1 },
      { scaleY: Platform.OS === 'ios' ? 0.9 : 1.1 }
    ]
  }
});
const HeaderSection = styled.View`
  background-color: ${theme.colors.backgroundLight};
  padding: 24px 20px 12px 20px;
`;
const CardAPreferenceSection = styled.View`
  background-color: ${theme.colors.backgroundLight};
  padding: 12px 20px;
  border-bottom-width: 1px;
  border-bottom-color: ${theme.colors.lightGrey};
  align-items: center;
`;

const PrefSwitchWrapper = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: 2px 0px;
`;

const PrefSwitchColumn = styled.View`
  flex: ${(props) => props.flex};
  align-items: ${(props) => (props.pullRight ? 'flex-end' : 'flex-start')};
`;

const CardWrapper = styled.View`
  width: 100%;
`;

const PreloadWrapper = styled.View`
  position: absolute;
  left: 55%;
`;
const SectionRow = styled.View`
  flex-direction: row;
  align-items: center;
`;

const PwrSwitchLabel = styled.Text`
  font-family: Montserrat-SemiBold;
  text-align: left;
  letter-spacing: 0.2px;
  text-transform: uppercase;
  font-size: 13px;
  line-height: 15px;
`;

const PwrPageTitle = styled.Text`
  font-family: Montserrat-SemiBold;
  text-align: left;
  letter-spacing: 0.2px;
  font-size: 22px;
  line-height: 28px;
  font-weight: 700;
`;

const PwrPageSubTitle = styled.Text`
  font-family: Montserrat-SemiBold;
  text-align: left;
  letter-spacing: 0.2px;
  font-size: 13px;
  line-height: 15px;
  font-weight: 400;
  color: ${theme.colors.textPrimary};
`;
const PwrPageSubTitleHeavy = styled.Text`
  font-family: Montserrat-SemiBold;
  text-align: left;
  letter-spacing: 0.2px;
  font-size: 13px;
  line-height: 15px;
  font-weight: 700;
  color: ${theme.colors.textPrimary};
`;
const PwrPageGap = styled.Text`
  height: 10px;
`;

CheckoutPreferenceScreen.propTypes = {
  navigation: PropTypes.object.isRequired,
  route: PropTypes.object.isRequired
};

export default CheckoutPreferenceScreen;
