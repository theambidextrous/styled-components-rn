import React, { useState } from 'react';
import { Alert, TouchableOpacity } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { UserApi, AddAccountRequest } from 'mastercard_loyalty_sandbox_api';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import * as Animatable from 'react-native-animatable';
import { Formik } from 'formik';
import * as actions from '@stores/actions';
import * as yup from 'yup';
import { useTheme } from 'styled-components';
import RadioGroup from 'react-native-radio-buttons-group';
import { useSelector, useDispatch } from 'react-redux';
import {
  Text,
  CheckoutRow,
  LoadingIndicator,
  RadioCardLabel,
  PrimaryButton,
  EmptyState
} from '@components/index';
import {
  cartTotal,
  theme,
  client,
  RefreshAuthToken,
  extractError,
  CardIsExpired,
  AppTracker
} from '@utils/index';
import AddCardForm from '../CoBrandCards/AddCardForm';

const validationSchema = yup.object().shape({
  pan: yup.string().required().label('Card Number').min(12).max(19),
  name: yup.string().required().label('Cardholder Name').min(5).max(50),
  expiryMonth: yup.string().required().label('Expiry Month').min(2).max(2),
  expiryYear: yup.string().required().label('Expiry year').min(4).max(4)
});

const PaymentScreen = ({ route, navigation }) => {
  /**  tracker */
  const apptracker = new AppTracker();

  // theme
  const shopTheme = useTheme();

  const dispatch = useDispatch();
  const discountsData = route.params.discountData;
  const discountedAmount = discountsData.reduce(
    (prev, { amount }) => prev + amount,
    0
  );
  const appState = useSelector((state) => state);
  const userState = appState.authentication;
  const { accessToken, refreshToken, expiresAt } = userState.session;
  const { isThirdParty } = appState.thirdParty;
  const {
    firstName,
    // tierName,
    lastName
    // coBrandPointsConversionFactor,
    // pointsConversionFactor,
    // pcloPointsConversionFactor
  } = userState.user;

  const cartState = appState.cart;
  const { items } = cartState;
  const { cards } = appState.cards;
  const [payOptions, SetPayOption] = useState([]);
  const [isLoading, SetIsLoading] = useState(false);
  const [isCardLoading, SetIsCardLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [animation, setAnimation] = useState('slideInRight');

  // const ComputeBannerPoints = () => {
  //   const bagTotals = cartTotal(items);
  //   const normal = pointsConversionFactor * bagTotals;
  //   const cobrand = coBrandPointsConversionFactor * bagTotals - normal;
  //   const thirdParty = isThirdParty
  //     ? pcloPointsConversionFactor * bagTotals
  //     : 0;
  //   return [normal + thirdParty, cobrand];
  // };

  const IsNewCard = (crd) => {
    if (cards.filter((old) => old.mrsId === crd.id).length === 0) {
      return true;
    }
    return false;
  };

  const HandlePullCards = async () => {
    SetIsLoading(true);
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const api = new UserApi(client);
    api.listAccounts({ offset: 0, limit: 20 }, (error, data, response) => {
      if (response && response.statusCode < 205) {
        const { accounts } = response.body;
        // console.log('accounts', accounts);
        const cardSelection = accounts.map((crd, index) => {
          const name = `${crd.firstName} ${crd.lastName}`;
          const cardId = index + 1;
          return {
            id: cardId,
            redemptionFrequency: crd.redemptionFrequency,
            expiryMonth: crd.expiryMonth,
            expiryYear: crd.expiryYear,
            value: crd.id,
            selected: crd.isDefault,
            isCobrand: crd.isCoBrand,
            pan: crd.accountNumber,
            name,
            label: (
              <RadioCardLabel
                id={cardId}
                name={name}
                pan={crd.accountNumber}
                isCobrand={crd.isCoBrand}
              />
            ),
            color: shopTheme.colors.primary || theme.colors.primary,
            containerStyle: {
              width: 300,
              height: 80
            }
          };
        });
        SetPayOption(cardSelection);
        accounts.forEach((crd) => {
          const cardObject = {
            name: `${crd.firstName} ${crd.lastName}`,
            pan: crd.accountNumber,
            mask: crd.accountNumber,
            mrsId: crd.id,
            validUntil: `${crd.expiryMonth}/${crd.expiryYear.slice(-2)}`,
            balance: '$0.00'
          };
          if (IsNewCard(crd)) {
            dispatch(actions.addUserCard(cardObject));
          }
        });
        SetIsLoading(false);
      } else {
        const errorData = extractError(error);
        apptracker.logCardsFailure('List cards at payment failure', {
          errorCode: response !== undefined ? response.statusCode : 'none',
          errorMessage: errorData.Details
        });
        SetIsLoading(false);
        Alert.alert('Oops, something went wrong', errorData.Details, [
          {
            text: 'Ok'
          }
        ]);
      }
    });
  };

  const HandleAddCard = async (requestBody, formik) => {
    const expDateYear = `${requestBody.expiryYear}-${requestBody.expiryMonth}-01`;
    if (CardIsExpired(expDateYear)) {
      Alert.alert('card error', 'This card is already expired.');
      return;
    }
    SetIsCardLoading(true);
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const api = new UserApi(client);
    const reqBody = {
      accountNumber: requestBody.pan,
      expiryMonth: requestBody.expiryMonth,
      expiryYear: requestBody.expiryYear
    };
    try {
      api.addAccount(
        AddAccountRequest.constructFromObject(reqBody),
        async (error, data, response) => {
          // console.log('response', response.body);
          if (response && response.statusCode < 205) {
            SetIsCardLoading(false);
            formik.resetForm();
            setShowModal(false);
            setAnimation('fadeOut');
            HandlePullCards();
          } else if (response.statusCode === 500) {
            SetIsCardLoading(false);
            Alert.alert(
              'Oops, something went wrong',
              'Service unavailable. Try again later',
              [
                {
                  text: 'Ok',
                  onPress: () => null
                }
              ]
            );
          } else {
            const errorData = extractError(error);
            apptracker.logCardsFailure('Add card at payment failure', {
              errorCode: response.statusCode,
              errorMessage: errorData.Details
            });
            SetIsCardLoading(false);
            Alert.alert('Oops, something went wrong', errorData.Details);
          }
        }
      );
    } catch (error) {
      SetIsLoading(false);
      Alert.alert('Oops, something went wrong', 'Request timed out');
    }
  };

  const SetModalOn = () => {
    setAnimation('fadeIn');
    setShowModal(true);
  };
  const onPressPaymentRadio = (payOptionArray) => {
    SetPayOption(payOptionArray);
  };
  const billAmount = cartTotal(items);

  useFocusEffect(
    React.useCallback(() => {
      HandlePullCards();
      return () => null;
    }, [])
  );

  return (
    <>
      <StyledScrollView>
        <Wrapper>
          <WrapperHeader>
            <WrapperHeaderLeft>
              <Text as="H1">{showModal ? 'Add a Card' : 'Choose a Card'}</Text>
            </WrapperHeaderLeft>
            <WrapperHeaderRight>
              {!showModal && (
                <TouchableOpacity onPress={SetModalOn}>
                  <MIcon
                    name="plus-circle"
                    color={shopTheme.colors.primary || theme.colors.primary}
                    size={42}
                  />
                </TouchableOpacity>
              )}
            </WrapperHeaderRight>
          </WrapperHeader>
          <WrapperFoot>
            <PaymentWrapper>
              {!showModal && (
                <>
                  {payOptions.length > 0 && (
                    <RadioGroup
                      radioButtons={payOptions}
                      onPress={onPressPaymentRadio}
                    />
                  )}
                  {payOptions.length === 0 && isLoading && <LoadingIndicator />}
                  {payOptions.length === 0 && isLoading === false && (
                    <>
                      <EmptyState
                        title="No cards added"
                        subTitle="Tap the '+' button to add a new card"
                      />
                    </>
                  )}
                </>
              )}
              {/* Modal */}
              {showModal && (
                <Animatable.View
                  style={{ flex: 1, width: '100%', paddingBottom: 40 }}
                  animation={animation}
                >
                  <Formik
                    initialValues={{
                      pan: '',
                      name: `${firstName}, ${lastName}`,
                      expiryMonth: '',
                      expiryYear: ''
                    }}
                    validationSchema={validationSchema}
                    onSubmit={(values, formik) => HandleAddCard(values, formik)}
                  >
                    {(formikProps) => (
                      <>
                        <AddCardForm formikProps={formikProps} layout="row" />
                        <PrimaryButton
                          title="Add Card"
                          onPress={formikProps.handleSubmit}
                          loading={isCardLoading}
                          disabled={isCardLoading}
                        />
                        <CancelButton
                          onPress={() => {
                            setShowModal(false);
                            setAnimation('slideOutRight');
                          }}
                        >
                          <CancelCardText>Cancel</CancelCardText>
                        </CancelButton>
                      </>
                    )}
                  </Formik>
                </Animatable.View>
              )}
            </PaymentWrapper>
          </WrapperFoot>
        </Wrapper>
      </StyledScrollView>
      <CheckoutRow
        onPress={() => {
          let selectedCard = {};
          if (payOptions.length > 0) {
            selectedCard = payOptions.find(
              (selected) => selected.selected === true
            );
          }
          if (Object.keys(selectedCard).length !== 0) {
            const selectedCardPref = selectedCard.redemptionFrequency;
            if (selectedCardPref === 'OFF') {
              navigation.push('PayWithPoints', {
                card: selectedCard,
                discountsPayload: discountsData
              });
            } else {
              navigation.push('Confirmation', {
                card: selectedCard,
                discountsPayload: discountsData
              });
            }
          } else {
            Alert.alert('Select payment', 'Select a card to proceed');
          }
        }}
        btnText="Continue"
        disabled={showModal}
        discountedAmount={discountedAmount}
        totalAmount={billAmount}
        isDark={isThirdParty}
      />
    </>
  );
};

// const BannerWrapper = styled.View`
//   flex: 1;
//   align-items: flex-start;
//   justify-content: center;
// `;
// const BannerTextWrapper = styled.View`
//   flex: 5;
//   justify-content: center;
// `;
// const LabelsTextWrapper = styled.View`
//   flex: 3;
//   padding-right: 4px;
// `;
// const ValuesTextWrapper = styled.View`
//   flex: 2;
// `;
// const BenefitsRow = styled.View`
//   flex: 1;
//   flex-direction: row;
//   margin-top: 5px;
// `;
// const TierTitle = styled.Text`
//   font-size: 14px;
//   font-weight: 700;
//   line-height: 18px;
//   margin-bottom: 5px;
//   font-family: 'Montserrat';
//   color: ${theme.colors.textWhite};
// `;
// const PointsBanner = styled.View`
//   flex-direction: row;
//   background-color: ${(props) =>
//     props.isDark ? theme.colors.black : theme.colors.primary};
//   padding: 10px 16px;
//   margin: 0 16px;
//   border-radius: 4px;
//   margin-bottom: 10px;
// `;

// const DividerView = styled.View`
//   height: 15px;
// `;

const CancelButton = styled.TouchableOpacity`
  border: solid;
  border-width: 1px;
  border-color: ${theme.colors.textPrimary};
  padding: 10px;
  border-radius: 20px;
  margin-top: 15px;
  z-index: 1;
`;
const CancelCardText = styled.Text`
  font-family: MarkOffcPro;
  font-weight: 700;
  line-height: 22px;
  font-size: 18px;
  color: ${theme.colors.textPrimary};
  text-align: center;
`;

const StyledScrollView = styled.ScrollView`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
  background-color: ${theme.colors.backgroundColor};
`;
const Wrapper = styled.View`
  flex: 1;
  background-color: ${theme.colors.backgroundColor};
`;
const WrapperHeader = styled.View`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
  flex-direction: row;
  padding: 20px;
`;
const WrapperHeaderLeft = styled.View`
  flex: 4;
  justify-content: center;
  align-items: flex-start;
`;

const WrapperHeaderRight = styled.View`
  flex: 1;
  justify-content: center;
  align-items: flex-end;
`;
const WrapperFoot = styled.View`
  flex: 5;
  background-color: ${theme.colors.backgroundColor};
`;
const PaymentWrapper = styled.View`
  padding: 20px;
  align-items: center;
  background-color: ${theme.colors.backgroundLight};
  margin-left: 20px;
  margin-right: 20px;
  margin-top: 40px;
  border-radius: 7px;
  flex: 1;
`;

PaymentScreen.propTypes = {
  navigation: PropTypes.object.isRequired,
  route: PropTypes.object.isRequired
};

export default PaymentScreen;
