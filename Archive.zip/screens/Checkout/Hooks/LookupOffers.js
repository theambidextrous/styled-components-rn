import {
  client,
  RefreshAuthToken,
  SessionMOffersListFormatter,
  extractError,
  AppTracker,
  DEFAULT_TIMEOUT
} from '@utils/index';
import { CreateOrderRequest, OrdersApi } from 'mastercard_loyalty_sandbox_api';
import { useCallback, useEffect, useState } from 'react';
import { useSelector } from 'react-redux';

export default function useStreamOffers() {
  /**  tracker */
  const apptracker = new AppTracker();

  const { accessToken, refreshToken, expiresAt } = useSelector(
    (state) => state.authentication.session
  );
  const [shouldFetch, setShouldFetch] = useState(true);
  const [offers, setOffers] = useState({
    error: null,
    items: [],
    isLoading: true
  });
  const cartItems = useSelector((state) => {
    const transformedCartItems = [];
    Object.keys(state.cart.items).forEach((key) => {
      transformedCartItems.push({
        productId: key,
        productTitle: state.cart.items[key].name,
        productPrice: state.cart.items[key].price,
        productImage: state.cart.items[key].image,
        productCategory: state.cart.items[key].category,
        productQuantity: state.cart.items[key].quantity,
        productSize: state.cart.items[key].size,
        productColor: state.cart.items[key].color
      });
    });

    // Ensure we always sort the same way the as the state
    return transformedCartItems.sort((a, b) =>
      (a.productId > b.productId ? 1 : -1)); // prettier-ignore
  });

  // get shipping and billing details from the authenticated user
  const userState = useSelector((state) => state.authentication.user);
  const {
    email,
    city,
    firstName,
    lastName,
    phoneNumber,
    streetAddress,
    countryCode,
    postalCode,
    state
  } = userState;

  const listItems = cartItems.map((item) => ({
    productId: item.productId,
    quantity: item.productQuantity,
    variationId: 0
  }));
  const payLoad = {
    paymentMethod: 'bacs',
    paymentMethodTitle: 'Direct Bank Transfer',
    setPaid: false,
    billing: {
      firstName,
      lastName,
      address1: streetAddress,
      city,
      state,
      postCode: postalCode,
      country: countryCode,
      email,
      phoneNumber
    },
    shipping: {
      firstName,
      lastName,
      address1: streetAddress,
      city,
      state,
      postCode: postalCode,
      country: countryCode
    },
    lineItems: listItems,
    shippingLines: [
      {
        methodId: 'flat_rate',
        methodTitle: 'Flat Rate',
        total: 0
      }
    ]
  };

  const fetchMore = useCallback(() => setShouldFetch(true), []);

  useEffect(() => {
    if (!shouldFetch) {
      return;
    }
    const GetUserOffers = async () => {
      setOffers({
        ...offers,
        isLoading: true
      });
      const refreshedData = await RefreshAuthToken(
        accessToken,
        refreshToken,
        expiresAt
      );
      client.defaultHeaders = {
        authorization: `Bearer ${refreshedData.accessToken}`
      };
      client.timeout = DEFAULT_TIMEOUT;
      const apiInstance = new OrdersApi(client);
      apiInstance.lookupOffers(
        CreateOrderRequest.constructFromObject(payLoad),
        (error, data, response) => {
          console.log('errorerror', error);
          if (Number(response && response.statusCode) < 205) {
            if (
              Array.isArray(response.body.offers) &&
              response.body.offers.length > 0
            ) {
              // console.log('response.body.offers', response.body.offers);
              const offersPayload = response.body.offers;
              const newOffers = SessionMOffersListFormatter(offersPayload);

              setOffers({
                ...offers,
                isLoading: false,
                items: [...newOffers]
              });
            } else {
              setOffers({
                isLoading: false
              });
            }
          } else {
            const errorData = extractError(error);
            apptracker.logOffersFailure(
              'Load SKU offers failure',
              errorData.Details
            );
            setOffers({
              isLoading: false
            });
            throw errorData.Details;
          }
        }
      );
    };
    GetUserOffers();
  }, []);
  return [offers, fetchMore];
}
