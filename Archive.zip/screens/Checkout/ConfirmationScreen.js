import React, { useState } from 'react';
import { Alert } from 'react-native';
import PropTypes from 'prop-types';
import { useSelector, useDispatch } from 'react-redux';
import { OrdersApi, CreateOrderRequest } from 'mastercard_loyalty_sandbox_api';
import {
  ConfirmationProductCard,
  Text,
  ConfirmationDetailsRow,
  CheckoutRow,
  Divider,
  ModalPopUp,
  PrimaryButton,
  Loader
} from '@components';
import {
  client,
  extractError,
  cartTotal,
  RefreshAuthToken,
  refreshUserProfile,
  triggerSuccessHaptic,
  triggerImpactLightHaptic,
  theme,
  AppTracker,
  WOOCOMERCE_TIMEOUT
} from '@utils/index';
import * as actions from '@stores/actions';

import {
  StyledScrollView,
  HorizontalPadding,
  ModalDetails,
  StyledModalSubTitle,
  Gap
} from './styles';

const ConfirmationScreen = ({ route, navigation }) => {
  const dispatch = useDispatch();

  /**  tracker */
  const apptracker = new AppTracker();

  const currentCard = route.params.card;
  const queryParams = route.params.discountsPayload;
  const discountsData = queryParams || [];
  const discountedAmount = discountsData.reduce(
    (prev, { amount }) => prev + amount,
    0
  );

  const paymentAccountId = currentCard.value;
  const appState = useSelector((state) => state);
  const currentShop = appState.multiStore;
  const { applicationId } = currentShop;

  const cartState = appState.cart;
  const [preloader, SetPreloader] = useState(false);

  const [confirmationState, SetConfirmationState] = useState({
    visible: false,
    isLoading: false
  });

  const { items } = cartState;
  const cartItems = useSelector((state) => {
    const transformedCartItems = [];
    Object.keys(state.cart.items).forEach((key) => {
      transformedCartItems.push({
        productId: key,
        productTitle: state.cart.items[key].name,
        productPrice: state.cart.items[key].price,
        productImage: state.cart.items[key].image,
        productCategory: state.cart.items[key].category,
        productQuantity: state.cart.items[key].quantity,
        productSize: state.cart.items[key].size,
        productColor: state.cart.items[key].color
      });
    });

    // Ensure we always sort the same way the as the state
    return transformedCartItems.sort((a, b) =>
      (a.productId > b.productId ? 1 : -1)); // prettier-ignore
  });

  // get shipping and billing details from the authenticated user
  const userState = useSelector((state) => state);
  const savedUserState = userState.authentication;
  const { isThirdParty, checkoutSource } = userState.thirdParty;
  const { accessToken, refreshToken, expiresAt } = savedUserState.session;
  const {
    email,
    city,
    firstName,
    lastName,
    phoneNumber,
    streetAddress,
    countryCode,
    postalCode,
    state,
    tierName
  } = savedUserState.user;

  const listItems = cartItems.map((item) => ({
    productId: item.productId,
    quantity: item.productQuantity,
    variationId: 0
  }));
  const payLoad = {
    tierName,
    paymentMethod: 'bacs',
    paymentMethodTitle: 'Direct Bank Transfer',
    setPaid: false,
    billing: {
      accountId: paymentAccountId,
      firstName,
      lastName,
      address1: streetAddress,
      city,
      state,
      postCode: postalCode,
      country: countryCode,
      email,
      phoneNumber
    },
    shipping: {
      firstName,
      lastName,
      address1: streetAddress,
      city,
      state,
      postCode: postalCode,
      country: countryCode
    },
    lineItems: listItems,
    shippingLines: [
      {
        methodId: 'flat_rate',
        methodTitle: 'Flat Rate',
        total: 0
      }
    ],
    discounts: discountsData,
    source: isThirdParty ? checkoutSource : null
  };

  const createOrder = async () => {
    SetPreloader(true);
    SetConfirmationState({
      ...confirmationState,
      isLoading: true
    });
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`,
      'App-Id': applicationId
    };
    client.timeout = WOOCOMERCE_TIMEOUT;
    const apiInstance = new OrdersApi(client);
    apiInstance.createOrder(
      CreateOrderRequest.constructFromObject(payLoad),
      {},
      (error, data, response) => {
        SetPreloader(false);
        console.log('order response', response);
        if (response !== undefined && response.statusCode === 200) {
          if (isThirdParty) {
            dispatch(actions.setIsThirdParty(false));
          }
          setTimeout(() => {
            refreshUserProfile(newTkn.accessToken);
          }, 3000);
          triggerSuccessHaptic();
          SetConfirmationState({
            ...confirmationState,
            visible: true,
            isLoading: false
          });
        } else {
          // some error occurred
          SetPreloader(false);
          const errorData = extractError(error);
          apptracker.logWooCommerceFailure(
            'Place order failure',
            String(error),
            'hidden'
          );
          SetConfirmationState({
            ...confirmationState,
            isLoading: false,
            visible: false
          });
          Alert.alert('Oops, something went wrong', errorData.Details);
        }
      }
    );
  };

  const clearCart = () => {
    dispatch(actions.clearCart());
    navigation.popToTop();
    navigation.navigate('UserWelcome');
    SetConfirmationState({
      ...confirmationState,
      visible: false
    });
  };

  const totalCartItems = cartItems.length;

  return (
    <>
      <Loader loading={preloader} description="Placing order..." />
      <ModalPopUp visible={confirmationState.visible}>
        <ModalDetails />
        <StyledModalSubTitle />
        <PrimaryButton title="Done" onPress={clearCart} />
      </ModalPopUp>
      <StyledScrollView>
        <HorizontalPadding>
          <Text as="H1">Confirmation</Text>
          <Text as="P3" style={{ color: theme.colors.textSecondary }}>
            {`${totalCartItems} Product Items`}
          </Text>
        </HorizontalPadding>
        <Divider />
        {cartItems.map((item) => (
          <ConfirmationProductCard
            key={item.productId}
            title={item.productTitle}
            category={item.productCategory}
            price={item.productPrice}
            quantity={item.productQuantity}
            color={item.productColor}
            size={item.productSize}
            image={item.productImage}
          />
        ))}
        <Divider />
        <Gap />
        <ConfirmationDetailsRow
          header="Shipping address:"
          subHeader="Purchase 2000 Purchase Street Purchase, NY 10577 U.S.A."
        />
        <ConfirmationDetailsRow
          header="Payment method:"
          isFullLength
          subHeader={`${currentCard.name}: ${currentCard.pan}`}
        />
      </StyledScrollView>
      <CheckoutRow
        btnText="Place Order"
        disabled={preloader}
        onPress={() => {
          triggerImpactLightHaptic();
          createOrder();
        }}
        discountedAmount={discountedAmount}
        totalAmount={cartTotal(items)}
        isDark={isThirdParty}
      />
    </>
  );
};

ConfirmationScreen.propTypes = {
  navigation: PropTypes.object.isRequired,
  route: PropTypes.objectOf(PropTypes.any).isRequired
};
export default ConfirmationScreen;
