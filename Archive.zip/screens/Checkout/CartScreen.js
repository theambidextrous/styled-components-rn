import React, { useState } from 'react';
import styled from 'styled-components';
import PropTypes from 'prop-types';
import { ActivityIndicator, FlatList, ScrollView, Alert } from 'react-native';
import { OffersApi, RedeemOfferRequest } from 'mastercard_loyalty_sandbox_api';
import { useSelector, useDispatch } from 'react-redux';
import Icon from 'react-native-vector-icons/Feather';
import * as actions from '@stores/actions';
import {
  BottomSheet,
  CheckoutRow,
  CartProductCard,
  Divider,
  OfferBanner,
  PrimaryButton,
  Text,
  MemberShipIcon,
  ShopActionsText
} from '@components/index';
import {
  theme,
  cartTotal,
  client,
  RefreshAuthToken,
  extractError,
  getTierBadge,
  AppTracker
} from '@utils/index';

import useStreamOffers from './Hooks/LookupOffers';
import {
  AttributeHolder,
  ButtonContainer,
  ColorBox,
  EmptyStateContainer,
  EmptyStateImage,
  EmptyStateSpacing,
  HorizontalPadding,
  ModalHeaderContainer,
  OfferContainer,
  SizeBox,
  StyledView
} from './styles';

const defaultLogo = require('@assets/images/logo/gear_shop_logo.png');

const CartScreen = ({ navigation }) => {
  /**  tracker */
  const apptracker = new AppTracker();
  const dispatch = useDispatch();

  const appState = useSelector((state) => state);
  const currentShop = appState.multiStore;

  const { thirdPartyThemeImages, thirdPartyShopName } = currentShop;
  const thirdPadrtyLogo = thirdPartyThemeImages.find(
    (img) => img.name === 'darkLogo'
  );

  const cartState = appState.cart;
  const { isThirdParty } = appState.thirdParty;
  const userState = appState.authentication;
  const userTier = appState.points;
  const {
    email,
    city,
    firstName,
    lastName,
    phoneNumber,
    streetAddress,
    countryCode,
    postalCode,
    state
  } = userState.user;

  const {
    tierName,
    coBrandPointsConversionFactor,
    pointsConversionFactor,
    pcloPointsConversionFactor,
    pcloCobrandConversionFactor
  } = userTier;

  const { accessToken, refreshToken, expiresAt } = userState.session;

  const [offers, fetchMore] = useStreamOffers();
  const [discounts, SetDiscount] = useState({ isLoading: false, items: [] });
  const [discountedAmount, SetDiscountAmount] = useState(0);
  const { items } = cartState;
  const cartItems = useSelector((newState) => {
    const transformedCartItems = [];
    Object.keys(newState.cart.items).forEach((key) => {
      transformedCartItems.push({
        productId: key,
        productTitle: newState.cart.items[key].name,
        productCategory: newState.cart.items[key].category,
        productPrice: newState.cart.items[key].price,
        productImage: newState.cart.items[key].image,
        productQuantity: newState.cart.items[key].quantity,
        productSize: newState.cart.items[key].size,
        productColor: newState.cart.items[key].color
      });
    });
    // Ensure we always sort the same way the as the state
    return transformedCartItems.sort((a, b) =>
      (a.productId > b.productId ? 1 : -1)); // prettier-ignore
  });
  const [modalState, setModalState] = useState({
    visible: false,
    content: ''
  });
  const [sizes, setSizes] = useState([]);
  const [colors, setColors] = useState([]);
  const [quantityItem, setQuantity] = useState([]);
  const [itemUpdate, setItemUpdate] = useState({
    id: null
  });

  const totalCartItems = cartItems.length;
  const isEmpty = totalCartItems === 0;
  const itemSizes = (itemId) => {
    const productItem = items[itemId];
    const { color, size, quantity } = productItem;
    setItemUpdate({
      ...itemUpdate,
      id: itemId,
      color,
      size,
      quantity
    });
    setSizes(productItem.sizes);
    setModalState({
      ...modalState,
      visible: true,
      content: 'sizes'
    });
  };

  const itemColors = (itemId) => {
    const productItem = items[itemId];
    const { color, size, quantity } = productItem;
    setItemUpdate({
      ...itemUpdate,
      id: itemId,
      color,
      size,
      quantity
    });
    setColors(productItem.colors);
    setModalState({
      ...modalState,
      visible: true,
      content: 'colors'
    });
  };
  const itemQuantity = (itemId) => {
    const productItem = items[itemId];
    const arrResult = Array.from({ length: 10 }, (_, i) => i + 1);
    setItemUpdate({
      ...itemUpdate,
      id: itemId,
      color: productItem.color,
      size: productItem.size,
      quantity: productItem.quantity
    });
    setQuantity(arrResult);
    setModalState({
      ...modalState,
      visible: true,
      content: 'quantity'
    });
  };

  const onSizeChange = (size) => {
    setItemUpdate({ ...itemUpdate, size });
  };

  const onColorChange = (color) => {
    setItemUpdate({ ...itemUpdate, color });
  };

  const onQuantityChange = (quantity) => {
    setItemUpdate({ ...itemUpdate, quantity });
  };

  const ComputeBannerPoints = () => {
    const bagTotals = cartTotal(items);
    if (!isThirdParty) {
      const normal = pointsConversionFactor * bagTotals;
      const cobrand = coBrandPointsConversionFactor * bagTotals - normal;
      return [normal, cobrand];
    }
    const thirdPartyNormal = pcloPointsConversionFactor * bagTotals;
    const thirdPartyCobrand =
      pcloCobrandConversionFactor * bagTotals - thirdPartyNormal;
    return [thirdPartyNormal, thirdPartyCobrand];
  };

  const OnRedeemOffer = async (offer) => {
    try {
      const { offerId, source, sourceId } = offer;
      const newTkn = await RefreshAuthToken(
        accessToken,
        refreshToken,
        expiresAt
      );
      client.defaultHeaders = {
        authorization: `Bearer ${newTkn.accessToken}`
      };
      const api = new OffersApi(client);
      const listItems = cartItems.map((item) => ({
        productId: item.productId,
        quantity: item.productQuantity,
        variationId: 0
      }));
      const orderRequestData = {
        paymentMethod: 'bacs',
        paymentMethodTitle: 'Direct Bank Transfer',
        setPaid: false,
        billing: {
          accountId: null,
          firstName,
          lastName,
          address1: streetAddress,
          city,
          state,
          postCode: postalCode,
          country: countryCode,
          email,
          phoneNumber
        },
        shipping: {
          firstName,
          lastName,
          address1: streetAddress,
          city,
          state,
          postCode: postalCode,
          country: countryCode
        },
        lineItems: listItems,
        shippingLines: [
          {
            methodId: 'flat_rate',
            methodTitle: 'Flat Rate',
            total: 0
          }
        ]
      };
      const cleanId = offerId;
      const formData = {
        offerId: cleanId,
        source,
        sourceId: sourceId === null ? cleanId : sourceId,
        orderRequest: orderRequestData
      };
      api.activateOffer(
        RedeemOfferRequest.constructFromObject(formData),
        (error, data, response) => {
          // console.log('response', response.body);
          if (response && response.statusCode < 205) {
            const lockOfferResponse = response.body;
            Alert.alert(
              'Offer redeemed',
              'Offer has been successfully redeemed. Your order will be discounted if placed within 15 minutes'
            );
            SetDiscount({
              ...discounts,
              items: [...discounts.items, lockOfferResponse]
            });
            SetDiscountAmount(discountedAmount + lockOfferResponse.amount);
          } else {
            const errorData = extractError(error);
            apptracker.logOffersFailure(
              'Activate SKU offer failure',
              errorData.Details
            );
            Alert.alert('Something went wrong', errorData.Details);
            throw errorData.Details;
          }
        }
      );
    } catch (error) {
      apptracker.logOffersFailure('Activate SKU offer failure', String(error));
      // console.warn(error);
    }
  };

  const renderModalContent = () => {
    if (modalState.content === 'sizes') {
      return (
        <>
          <ModalHeaderContainer>
            <Text as="H3">Select Size</Text>
          </ModalHeaderContainer>
          <ScrollView>
            {sizes?.map((item, i) => (
              <SizeBox
                key={i}
                onPress={() => onSizeChange(item)}
                selected={itemUpdate.size === item}
              >
                <Text>{item}</Text>
              </SizeBox>
            ))}
          </ScrollView>
        </>
      );
    }
    if (modalState.content === 'colors') {
      return (
        <>
          <ModalHeaderContainer>
            <Text as="H3">Select Color</Text>
          </ModalHeaderContainer>
          <AttributeHolder>
            {colors?.map((item, i) => (
              <ColorBox
                key={i}
                onPress={() => onColorChange(item)}
                bgColor={item.toLowerCase()}
                selected={itemUpdate.color === item}
              />
            ))}
          </AttributeHolder>
        </>
      );
    }
    return (
      <>
        <ModalHeaderContainer>
          <Text as="H3">Select Quantity</Text>
        </ModalHeaderContainer>
        <ScrollView>
          {quantityItem?.map((item, i) => (
            <SizeBox
              key={i}
              onPress={() => onQuantityChange(item)}
              selected={itemUpdate.quantity === item}
            >
              <Text>{item}</Text>
            </SizeBox>
          ))}
        </ScrollView>
      </>
    );
  };

  const updateCartItem = () => {
    setModalState({
      ...modalState,
      visible: false
    });
    dispatch(actions.addToCart(itemUpdate));
  };

  if (isEmpty) {
    return (
      <EmptyStateContainer>
        <EmptyStateImage>
          <Icon
            name="shopping-bag"
            size={24}
            style={{
              color: theme.colors.textWhite
            }}
          />
        </EmptyStateImage>
        <EmptyStateSpacing>
          <Text as="H3">Your bag is empty!</Text>
          <Text as="P3">Add items you want to shop</Text>
        </EmptyStateSpacing>
        <PrimaryButton onPress={() => navigation.navigate('UserWelcome')}>
          Continue Shopping
        </PrimaryButton>
      </EmptyStateContainer>
    );
  }

  const HeaderComponent = () => (
    <>
      <HorizontalPadding>
        <PointsBanner isDark={isThirdParty} isColumn={isThirdParty}>
          <BannerWrapper>
            <MemberShipIcon
              resizeMode="contain"
              style={isThirdParty ? { width: 120 } : {}}
              source={
                isThirdParty
                  ? thirdPadrtyLogo === undefined
                    ? defaultLogo
                    : { uri: `data:image/jpeg;base64,${thirdPadrtyLogo.image}` }
                  : getTierBadge(tierName)
              }
            />
          </BannerWrapper>
          <BannerTextWrapper>
            {/* normal points */}
            <BenefitsRow>
              <LabelsTextWrapper>
                {isThirdParty ? (
                  <TierTitle>{`${thirdPartyShopName} Shop Points`}</TierTitle>
                ) : (
                  <TierTitle>{`${tierName} Benefit:`}</TierTitle>
                )}
              </LabelsTextWrapper>
              <ValuesTextWrapper>
                <ShopActionsText
                  style={{ fontFamily: 'Montserrat', textAlign: 'right' }}
                  text={`${ComputeBannerPoints()[0]} points`}
                  size={13}
                  lineHeight={15}
                  weight={800}
                  transform="none"
                  color={theme.colors.textWhite}
                />
              </ValuesTextWrapper>
            </BenefitsRow>
            {/* cobrand points */}
            <BenefitsRow>
              <LabelsTextWrapper>
                <TierTitle>Co-brand benefit:</TierTitle>
              </LabelsTextWrapper>
              <ValuesTextWrapper>
                <ShopActionsText
                  style={{ fontFamily: 'Montserrat', textAlign: 'right' }}
                  text={`${ComputeBannerPoints()[1]} points`}
                  size={13}
                  lineHeight={15}
                  weight={800}
                  transform="none"
                  color={theme.colors.textWhite}
                />
              </ValuesTextWrapper>
            </BenefitsRow>
          </BannerTextWrapper>
        </PointsBanner>
        <Text as="P3">{`You have ${totalCartItems} items in your bag`}</Text>
      </HorizontalPadding>
      <Divider />
    </>
  );
  return (
    <>
      <StyledView>
        <FlatList
          nestedScrollEnabled
          data={cartItems}
          keyExtractor={(item) => item.productId}
          ListHeaderComponent={HeaderComponent}
          renderItem={(itemData) => {
            const { item } = itemData;
            return (
              <CartProductCard
                title={item.productTitle}
                category={item.productCategory}
                price={item.productPrice}
                image={item.productImage}
                quantity={item.productQuantity}
                color={item.productColor}
                size={item.productSize}
                onSizePress={() => itemSizes(item.productId)}
                onColorPress={() => itemColors(item.productId)}
                onQuantityPress={() => itemQuantity(item.productId)}
                onRemove={() => {
                  dispatch(actions.setIsThirdParty(false));
                  dispatch(actions.removeFromCart(item.productId));
                }}
              />
            );
          }}
        />
        {!isThirdParty && offers.isLoading ? (
          <>
            <LoadingWrapper>
              <ActivityIndicator size="small" color={theme.colors.black} />
              <Text style={loadingStyles} as="P4">
                LOADING OFFERS...
              </Text>
            </LoadingWrapper>
          </>
        ) : (
          <>
            <OfferContainer>
              <FlatList
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{
                  paddingVertical: 10,
                  paddingHorizontal: 10
                }}
                nestedScrollEnabled
                data={isThirdParty ? [] : offers.items}
                keyExtractor={(item, index) => String(index)}
                fetchMore={fetchMore}
                renderItem={(itemData) => {
                  const { item } = itemData;
                  return (
                    <OfferBanner
                      isDark={isThirdParty}
                      offer={item}
                      onPressHandler={OnRedeemOffer}
                    />
                  );
                }}
              />
            </OfferContainer>
          </>
        )}
      </StyledView>
      <CheckoutRow
        onPress={() =>
          navigation.push('Payment', {
            discountData: discounts.items,
            discountedAmount
          })
        }
        btnText="Proceed to Checkout"
        disabled={offers.isLoading}
        discountedAmount={discountedAmount}
        totalAmount={cartTotal(items)}
        isDark={isThirdParty}
      />
      <BottomSheet visible={modalState.visible}>
        {renderModalContent()}
        <ButtonContainer>
          <PrimaryButton onPress={() => updateCartItem()}>Select</PrimaryButton>
        </ButtonContainer>
      </BottomSheet>
    </>
  );
};

const BannerWrapper = styled.View`
  flex: 1;
  align-items: flex-start;
  justify-content: center;
`;
const BannerTextWrapper = styled.View`
  flex: 5;
  justify-content: center;
`;
const LabelsTextWrapper = styled.View`
  flex: 3;
  padding-right: 4px;
`;
const ValuesTextWrapper = styled.View`
  flex-direction: row;
`;
const BenefitsRow = styled.View`
  flex: 1;
  flex-direction: row;
  margin-top: 5px;
`;
const TierTitle = styled.Text`
  font-size: 14px;
  font-weight: 700;
  line-height: 18px;
  margin-bottom: 5px;
  font-family: 'Montserrat';
  color: ${theme.colors.textWhite};
`;
const LoadingWrapper = styled.View`
  justify-content: center;
  align-items: center;
  flex-direction: row;
  padding: 20px 0;
`;

const loadingStyles = {
  fontSize: 10,
  marginLeft: 6,
  fontFamily: 'Montserrat-SemiBold'
};
const PointsBanner = styled.View`
  flex-direction: ${(props) => (props.isColumn ? 'column' : 'row')};
  background-color: ${(props) =>
    props.isDark
      ? theme.colors.black
      : props.theme.colors.primary || theme.colors.primary};
  padding: 10px 16px;
  /* margin: 0 16px; */
  border-radius: 4px;
  margin-bottom: 10px;
`;
CartScreen.propTypes = {
  navigation: PropTypes.object.isRequired
};

export default CartScreen;
