const store1 = require('@assets/images/others/bronze.png');
const store2 = require('@assets/images/others/faceID.png');
const store3 = require('@assets/images/others/smile.png');
const store4 = require('@assets/images/others/success.png');
const store5 = require('@assets/images/others/generic_shop_icon.png');

export const SheetItems = [
  'Cancel',
  {
    shopName: 'Clothes Store',
    applicationId: 'clotheid',
    icon: store1,
    woocommerceCategory: 'woocommerceCategory'
  },
  {
    shopName: 'NextGaz',
    applicationId: 'gasstore',
    icon: store2,
    woocommerceCategory: 'woocommerceCategory'
  },
  {
    shopName: 'Nature Foods',
    applicationId: 'nf00023',
    icon: store3,
    woocommerceCategory: 'woocommerceCategory'
  },
  {
    shopName: 'Amoury Construction',
    applicationId: 'amcon00567',
    icon: store4,
    woocommerceCategory: 'woocommerceCategory'
  },
  {
    shopName: 'Mastercard Finance',
    applicationId: 'mcfin34500',
    icon: store5,
    woocommerceCategory: 'woocommerceCategory'
  }
];

export const someNextStuff = {};
