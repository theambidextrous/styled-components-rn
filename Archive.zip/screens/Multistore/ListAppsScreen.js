/** eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from 'react';
import { View, Alert, ActivityIndicator } from 'react-native';
import CustomStatusBar from '@components/CustomStatusBar';
import { ActionSheetCustom as ActionSheet } from '@alessiocancian/react-native-actionsheet';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import PropTypes from 'prop-types';
import * as actions from '@stores/actions';
import { useDispatch } from 'react-redux';
import { ShopsApi } from 'mastercard_loyalty_sandbox_api';
import { theme, DEFAULT_TIMEOUT, client, extractError } from '@utils/index';
import {
  StyledSafeAreaView,
  StyledView,
  CallToActionText,
  StyledImage,
  CallToActionContainer,
  CallToActionButtonText,
  SheetTitleText,
  AppListTitle,
  ActionSheetStyles,
  ActionSheetEntryRow,
  ActionSheetIcon,
  StyledImageBackgroundView,
  LoadingView,
  LoadingText
} from './styles';

const logo = require('@assets/images/logo/loyalty_sandbox.png');
const genericShopIcon = require('@assets/images/others/generic_shop_icon.png');

const ListAppsScreen = ({ navigation }) => {
  const dispatcher = useDispatch();
  const sheetRef = useRef(null);
  const [loading, setLoading] = useState(false);
  const [apps, SetApps] = useState({
    error: null,
    isLoading: false,
    items: []
  });
  const SetShowActionSheet = () => sheetRef.current && sheetRef.current.show();

  const HandleGetApplications = () => {
    client.defaultHeaders = {};
    client.timeout = DEFAULT_TIMEOUT;
    const api = new ShopsApi(client);
    api.listAllApplications((error, data, response) => {
      if (response !== undefined && Number(response.statusCode) < 205) {
        const shopsList = response.body;
        if (shopsList.length > 0) {
          shopsList.unshift('Cancel');
          SetApps({ ...apps, items: shopsList });
        } else {
          SetApps({ ...apps, isLoading: false });
        }
      } else {
        const errorData = extractError(error);
        SetApps({
          ...apps,
          error: errorData.Details,
          isLoading: false
        });
        Alert.alert('Error occured', errorData.Details);
      }
    });
  };

  const HandleGet3rdPartyShopName = (thirdPartyShopId) => {
    client.defaultHeaders = { 'App-Id': thirdPartyShopId };
    client.timeout = DEFAULT_TIMEOUT;
    const api = new ShopsApi(client);
    api.getApplicationTheme(thirdPartyShopId, (error, data, response) => {
      if (response !== undefined && Number(response.statusCode) < 205) {
        const { shopName, themeImages } = response.body;
        const theImages = themeImages === null ? [] : themeImages;
        dispatcher(
          actions.saveMultiStoreThirdPartyId(
            thirdPartyShopId,
            shopName,
            theImages
          )
        );
      } else {
        const errorData = extractError(error);
        throw errorData.Details;
      }
    });
  };

  const HandleGetApplicationTheme = (selectedShop) => {
    // console.log('selectedShop', selectedShop);
    try {
      const { applicationId } = selectedShop;
      setLoading(true);
      client.defaultHeaders = { appId: applicationId };
      client.timeout = DEFAULT_TIMEOUT;
      const api = new ShopsApi(client);
      api.getApplicationTheme(applicationId, (error, data, response) => {
        setLoading(false);
        if (response !== undefined && Number(response.statusCode) < 205) {
          const { themeConfig, thirdPartyShopId, themeImages } = response.body;
          const theImages = themeImages === null ? [] : themeImages;
          HandleGet3rdPartyShopName(
            thirdPartyShopId === null ? 'uuid' : thirdPartyShopId
          );
          dispatcher(actions.saveMultiStoreAppId(selectedShop));
          dispatcher(actions.saveMultiStoreAppTheme(JSON.parse(themeConfig)));
          dispatcher(actions.saveMultiStoreThemeImages(theImages));
          navigation.navigate('SignInScreen', {
            screen: 'SignInScreen'
          });
        } else {
          const errorData = extractError(error);
          Alert.alert('Error occured', errorData.Details);
        }
      });
    } catch (error) {
      setLoading(false);
      Alert.alert('Error occured', String(error));
    }
  };

  useEffect(async () => {
    HandleGetApplications();
    return () => {};
  }, []);

  const ActionSheetOptions = apps.items.map((entry) => {
    if (entry === 'Cancel') {
      return <CallToActionButtonText>{entry}</CallToActionButtonText>;
    }
    return (
      <View>
        <ActionSheetEntryRow>
          <ActionSheetIcon source={genericShopIcon} />
          <AppListTitle>{entry.shopName}</AppListTitle>
        </ActionSheetEntryRow>
      </View>
    );
  });

  return (
    <StyledImageBackgroundView>
      <StyledSafeAreaView>
        <CustomStatusBar isLightContent />
        <StyledView />
        <StyledView>
          <StyledImage resizeMode="stretch" source={logo} />
          <CallToActionText>
            Welcome to LoyaltySandBox. Choose a store to proceed
          </CallToActionText>
        </StyledView>
        <CallToActionContainer
          onPress={() => {
            if (apps.items.length > 1) {
              SetShowActionSheet();
            } else {
              Alert.alert(
                'No stores',
                'We currently do not have stores to show'
              );
            }
          }}
        >
          <CallToActionButtonText> Choose a store </CallToActionButtonText>
          <CallToActionButtonText>
            <MIcon
              name="chevron-down"
              size={25}
              color={theme.colors.textWhite}
            />
          </CallToActionButtonText>
        </CallToActionContainer>
        <ActionSheet
          ref={sheetRef}
          title={<SheetTitleText>Choose a store</SheetTitleText>}
          options={ActionSheetOptions}
          styles={ActionSheetStyles}
          cancelButtonIndex={0}
          destructiveButtonIndex={4}
          onPress={(index) => {
            const selectedShop = apps.items[index];
            if (selectedShop === 'Cancel') {
              return;
            }
            HandleGetApplicationTheme(selectedShop);
          }}
        />
        <LoadingView>
          {loading && (
            <>
              <ActivityIndicator size="small" color="#ffffff" />
              <LoadingText>Preparing your store ...</LoadingText>
            </>
          )}
        </LoadingView>
      </StyledSafeAreaView>
    </StyledImageBackgroundView>
  );
};

ListAppsScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

export default ListAppsScreen;
