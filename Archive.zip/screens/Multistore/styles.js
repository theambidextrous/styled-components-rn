import styled from 'styled-components/native';
import theme from '@utils/theme';

export const ActionSheetStyles = {
  titleBox: {
    backgroundColor: theme.colors.backgroundColor
  },
  titleText: {
    fontSize: 16,
    fontWeight: 700
  },
  cancelButtonBox: {
    backgroundColor: theme.colors.primary
  },
  cancelButtonText: {
    color: theme.colors.black
  },
  buttonBox: {
    backgroundColor: theme.colors.textWhite
  }
};
export const TextInputStyledObj = {
  fontFamily: 'MarkOffcPro',
  height: 50,
  backgroundColor: theme.colors.backgroundLight,
  fontSize: 15,
  lineHeight: 18
};

export const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
`;

export const StyledImageBackgroundView = styled.View`
  flex: 1;
  background-color: ${theme.colors.black};
`;

export const StyledView = styled.View`
  justify-content: center;
  margin-top: 40px;
  padding-left: 40px;
  padding-right: 40px;
  padding-top: 20px;
  padding-bottom: 20px;
`;

export const ActionSheetEntryRow = styled.View`
  flex: 1;
  flex-direction: row;
  justify-content: flex-start;
  width: 200px;
  align-items: center;
`;

export const ActionSheetIcon = styled.Image`
  width: 40px;
  height: 40px;
  margin: 5px;
`;

export const StyledImage = styled.Image`
  width: 210px;
  height: 57px;
  align-self: center;
  margin-top: 60px;
  margin-bottom: 40px;
`;

export const StyledBiometricsImage = styled.Image`
  width: 48px;
  height: 48px;
  align-self: center;
`;

export const CallToActionText = styled.Text`
  font-family: 'MarkOffcPro';
  font-size: 16px;
  line-height: 22px;
  margin: 15px 0;
  text-align: left;
  color: ${theme.colors.textWhite};
`;

export const SheetTitleText = styled.Text`
  font-family: 'MarkOffcPro';
  margin-bottom: 5px;
  font-size: 16px;
  font-weight: 700;
  line-height: 22px;
  text-align: left;
  color: ${theme.colors.black};
`;

export const AppListTitle = styled.Text`
  font-family: 'MarkOffcPro';
  font-size: 16px;
  line-height: 22px;
  text-align: left;
  color: ${theme.colors.black};
`;

export const AppListSubtitle = styled.Text`
  font-family: 'MarkOffcPro';
  font-size: 12px;
  line-height: 14px;
  text-align: left;
  color: ${theme.colors.black};
  padding-right: 40px;
  padding-left: 40px;
`;

export const BiometricContainer = styled.View`
  flex-direction: row;
  margin: 35px 0;
  align-items: center;
  justify-content: center;
`;

export const CallToActionContainer = styled.TouchableOpacity`
  flex-direction: row;
  justify-content: center;
  width: 230px;
  align-self: center;
  padding: 10px;
  border-color: ${theme.colors.textWhite};
  border-bottom-width: 1px;
  border-right-width: 1px;
  border-left-width: 0px;
  border-radius: 100px;
`;

export const CallToActionButtonText = styled.Text`
  font-family: 'MarkOffcPro-Bold';
  font-size: 16px;
  line-height: 24px;
  text-align: center;
  color: ${theme.colors.textWhite};
`;

export const CreateAccountText = styled.Text`
  font-family: 'MarkOffcPro-Bold';
  font-size: 13px;
  line-height: 15px;
  text-align: center;
  color: ${theme.colors.textWhite};
  text-decoration: underline;
  text-decoration-color: ${theme.colors.primary};
  text-decoration-style: solid;
`;

export const LoadingView = styled.View`
  margin-top: 32px;
  align-items: center;
`;

export const LoadingText = styled.Text`
  font-family: 'MarkOffcPro-Bold';
  margin-top: 8px;
  font-size: 13px;
  line-height: 15px;
  text-align: center;

  color: ${theme.colors.textWhite};
`;

export const ForgotPasswordButton = styled.TouchableOpacity``;
