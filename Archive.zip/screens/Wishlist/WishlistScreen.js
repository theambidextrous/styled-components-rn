import React, { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { DrawerActions } from '@react-navigation/native';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import { theme, getStatusBar } from '@utils';
import {
  CustomStatusBar,
  WishlistItemView,
  Text,
  EmptyState
} from '@components';

const WishlistScreen = ({ navigation }) => {
  const persistedState = useSelector((state) => state);
  const myWishlist = persistedState.wishlist;
  const { tierName } = persistedState.points;
  //   console.log('myWishlist', myWishlist);

  useEffect(() => {
    navigation.addListener('focus', () => {
      navigation.dispatch(DrawerActions.closeDrawer());
    });
    return null;
  }, [navigation]);

  return (
    <>
      <CustomStatusBar isLightContent={getStatusBar(tierName)} />
      <StyledSafeAreaView>
        <Container showsVerticalScrollIndicator={false}>
          <HorizontalPadding>
            <HeaderSection>
              <Text as="H1">Wishlist</Text>
              {myWishlist.items.length > 0 && (
                <Text as="P3" style={{ color: theme.colors.textSecondary }}>
                  {`${myWishlist.items.length} Product Items`}
                </Text>
              )}
            </HeaderSection>
            {myWishlist.items.length === 0 && (
              <EmptyStateContainer>
                <EmptyState
                  title="You don't have any items yet"
                  subTitle="Tap the heart on any product to save it to your wishlist"
                />
              </EmptyStateContainer>
            )}
            {myWishlist.items.map((item, key) => (
              <WishlistItemView key={key} item={item} />
            ))}
          </HorizontalPadding>
        </Container>
      </StyledSafeAreaView>
    </>
  );
};

const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;
const Container = styled.ScrollView`
  flex: 1;
  background-color: ${theme.colors.textWhite};
  padding-top: 20px;
  margin-bottom: 70px;
  width: 100%;
  height: 100%;
`;
const HorizontalPadding = styled.View`
  padding: 0 20px;
`;

const HeaderSection = styled.View`
  margin-bottom: 16px;
`;
const EmptyStateContainer = styled.View`
  justify-content: center;
  align-items: center;
`;

WishlistScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired,
    addListener: PropTypes.func.isRequired,
    dispatch: PropTypes.func.isRequired
  }).isRequired
};

export default WishlistScreen;
