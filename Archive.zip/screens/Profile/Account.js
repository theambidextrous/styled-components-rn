import React from 'react';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';

import { cartQuantity } from '@utils';
import { ProfileCard, Text, ProfileActionRow } from '@components';

import {
  StyledScrollView,
  StyledView,
  ProfileHeader,
  UserAvatar,
  Gap
} from './styles';

const avatar = require('@assets/images/others/avatar.png');

const ProfileAccount = ({ navigation }) => {
  const appState = useSelector((state) => state);
  const userState = appState.authentication;
  const {
    email,
    city,
    firstName,
    lastName,
    phoneNumber,
    streetAddress,
    countryCode,
    postalCode,
    state,
    tierName
  } = userState.user;
  const [wishlist, cart] = useSelector((s) => [s.wishlist, s.cart]);
  const { items } = cart;
  const totalCartItems = cartQuantity(items);
  return (
    <>
      <StyledScrollView>
        <StyledView>
          <ProfileHeader>
            <UserAvatar imageStyle={{ borderRadius: 70 }} source={avatar} />
            <Text as="H2" style={{ marginBottom: 12 }}>
              {`${firstName} ${lastName}`}
            </Text>
            <Text as="P3">{`${streetAddress} ${streetAddress}`}</Text>
            <Text as="P3">{`${state}, ${city} ${postalCode} ${countryCode}`}</Text>
          </ProfileHeader>
          <ProfileCard
            title="Full name"
            subTitle={`${firstName} ${lastName}`}
          />
          <ProfileCard title="Email" subTitle={email} />
          <ProfileCard title="Tier" subTitle={`${tierName}`} />
          <ProfileCard title="Phone number" subTitle={phoneNumber} />
          <Gap />
          <ProfileActionRow
            title="Features Preference"
            onCardPress={() =>
              navigation.navigate('UserAccountStack', {
                screen: 'FeaturePreference'
              })
            }
          />
          <ProfileActionRow
            title="Wishlist"
            subTitle={String(wishlist.items.length)}
            onCardPress={() => navigation.navigate('MyWishlist')}
          />
          <ProfileActionRow
            title="My bag"
            subTitle={String(totalCartItems)}
            onCardPress={() => navigation.navigate('Cart')}
          />
          <ProfileActionRow
            title="Send feedback"
            onCardPress={() =>
              navigation.navigate('UserAccountStack', { screen: 'Feedback' })
            }
          />
        </StyledView>
      </StyledScrollView>
    </>
  );
};

ProfileAccount.propTypes = {
  navigation: PropTypes.object.isRequired
};

export default ProfileAccount;
