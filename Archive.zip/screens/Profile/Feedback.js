import React, { useState } from 'react';
import { Platform, Alert } from 'react-native';
import styled from 'styled-components/native';
import { Formik } from 'formik';
import * as yup from 'yup';
import { useSelector } from 'react-redux';
import PropTypes from 'prop-types';

// Mastercard SDK
import { FeedbackRequest, FeedbackApi } from 'mastercard_loyalty_sandbox_api';

// Components
import { TextInputs, DropDown, PrimaryButton } from '@components';

// Utils
import {
  theme,
  AppTracker,
  client,
  RefreshAuthToken,
  extractError
} from '@utils/';

const categories = [
  {
    value: 'Feature Request',
    label: 'Feature Request'
  },
  {
    value: 'Report bug',
    label: 'Report bug'
  },
  {
    value: 'Other',
    label: 'Other'
  }
];
const validationSchema = yup.object().shape({
  title: yup.string().required('Please add a feedback title'),
  body: yup.string().required('Please tell us more'),
  category: yup.string().required('Please choose a category')
});

const FeedbackScreen = ({ navigation }) => {
  // tracker
  const apptracker = new AppTracker();
  // redux state
  const appState = useSelector((state) => state);
  const authState = appState.authentication;
  const { accessToken, refreshToken, expiresAt } = authState.session;

  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState(categories);
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(null);

  const postFeedback = async (values) => {
    setLoading(true);
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const api = new FeedbackApi(client);
    const feedbackRequest = FeedbackRequest.constructFromObject(values);
    api.userFeedback(feedbackRequest, (error, data, response) => {
      if (response && response.statusCode < 205) {
        setLoading(false);
        Alert.alert('Feedback sent 🎉', 'Thanks for your feedback!', [
          { text: 'OK', onPress: () => navigation.goBack() }
        ]);
      } else if (response.statusCode === 500) {
        setLoading(false);
        apptracker.logCardsFailure('Send feedback failure', {
          errorCode: response.statusCode,
          errorMessage: String(error)
        });
        Alert.alert('Something went wrong', 'Please try again later.');
      } else {
        setLoading(false);
        const errorData = extractError(error);
        apptracker.logCardsFailure('Send feedback failure', {
          errorCode: response.statusCode,
          errorMessage: errorData.Details
        });
        Alert.alert('Something went wrong', errorData.Details);
      }
    });
  };
  return (
    <StyledSafeAreaView>
      <Formik
        validationSchema={validationSchema}
        initialValues={{
          validateOnMount: true,
          title: '',
          body: '',
          category: ''
        }}
        onSubmit={(values) => postFeedback(values)}
      >
        {(formikProps) => (
          <>
            <StyledComponentView>
              <TextInputs
                label="Title"
                placeholder="Title"
                formikProps={formikProps}
                formikKey="title"
              />

              <TextInputs
                multiline={true}
                label="Body"
                placeholder="Tell us more ...."
                formikProps={formikProps}
                formikKey="body"
                numberOfLines={4}
                style={{
                  height: 150,
                  textAlignVertical: 'top',
                  borderRadius: 5
                }}
              />
              <DropDown
                placeholder="Choose category"
                open={open}
                value={value}
                items={items}
                setOpen={setOpen}
                formikProps={formikProps}
                formikKey="category"
                setValue={setValue}
                onChangeValue={(category) => {
                  formikProps.setFieldValue('category', category);
                }}
                setItems={setItems}
              />
            </StyledComponentView>
            <ButtonContainer>
              <PrimaryButton
                title="Submit feedback"
                onPress={formikProps.handleSubmit}
                loading={loading}
                disabled={loading}
              />
            </ButtonContainer>
          </>
        )}
      </Formik>
    </StyledSafeAreaView>
  );
};

const StyledComponentView = styled.View`
  flex: 1;
  padding: 20px;
  background-color: ${theme.colors.backgroundLight};
`;

const ButtonContainer = styled.View`
  padding: 20px 20px 20px 20px;
  background-color: ${theme.colors.backgroundColor};
  justify-content: flex-end;
  margin-bottom: ${Platform.OS === 'android' ? 10 : 0}px;
`;

const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.backgroundColor};
`;

FeedbackScreen.propTypes = {
  navigation: PropTypes.object.isRequired
};
export default FeedbackScreen;
