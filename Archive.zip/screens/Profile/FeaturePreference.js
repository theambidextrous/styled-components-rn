import React, { useState } from 'react';
import { Alert } from 'react-native';
import { ifIphoneX } from 'react-native-iphone-x-helper';
import styled from 'styled-components/native';
import { DemosApi } from 'mastercard_loyalty_sandbox_api';
import { Formik } from 'formik';
import * as yup from 'yup';
import { useSelector, useDispatch } from 'react-redux';
import * as actions from '@stores/actions';

import PropTypes from 'prop-types';
import { Checkbox, PrimaryButton } from '@components';
import {
  theme,
  client,
  extractError,
  RefreshAuthToken,
  DEFAULT_TIMEOUT
} from '@utils/index';

const validationSchema = yup.object().shape({
  CoBrand: yup.boolean().label('Co-brand cards')
});

const FeaturePreference = ({ navigation }) => {
  const dispatcher = useDispatch();
  const appState = useSelector((state) => state);
  const prefState = appState.preference;
  const { featurePreference } = prefState;
  const authState = appState.authentication;
  const { accessToken, refreshToken, expiresAt } = authState.session;

  const [formState, SetFormState] = useState({
    message: '',
    isLoading: false
  });

  const postPreferences = async (values) => {
    SetFormState({ ...formState, isLoading: true });
    const PrefObject = { 'Co-Brand': 'OFF' };
    if (values.CoBrand) {
      PrefObject['Co-Brand'] = 'ON';
    }
    try {
      const newTkn = await RefreshAuthToken(
        accessToken,
        refreshToken,
        expiresAt
      );
      client.timeout = DEFAULT_TIMEOUT;
      client.defaultHeaders = {
        authorization: `Bearer ${newTkn.accessToken}`
      };
      const api = new DemosApi(client);
      api.saveDemoPreferences(PrefObject, (error, data, response) => {
        SetFormState({ ...formState, isLoading: false });
        if (response !== undefined && Number(response.statusCode) < 205) {
          dispatcher(actions.setGeneralFeaturePreference(PrefObject));
          Alert.alert(
            'Preferences saved',
            'Your preferences have been updated successfully!',
            [{ text: 'Ok', onPress: () => navigation.goBack() }]
          );
        } else {
          /** error */
          const errorData = extractError(error);
          Alert.alert('Error updating preferences', errorData.Details);
        }
      });
    } catch (error) {
      SetFormState({ ...formState, isLoading: false });
      console.log('error', error);
      Alert.alert('Error updating preferences', String(error));
    }
  };
  return (
    <StyledSafeAreaView>
      <Formik
        validationSchema={validationSchema}
        initialValues={{
          validateOnMount: true,
          CoBrand: featurePreference['Co-Brand'] === 'ON'
        }}
        onSubmit={(values) => postPreferences(values)}
      >
        {(formikProps) => (
          <StyledScrollView>
            <SectionBox>
              <SectionHeader>
                <SectionHeaderText>Co-brand Cards</SectionHeaderText>
              </SectionHeader>
              <SectionBody>
                <Checkbox
                  disabled={false}
                  labelLeft={true}
                  title="Enable Co-brand"
                  label="Co-Brand Cards"
                  formikKey="CoBrand"
                  formikProps={formikProps}
                  error={formikProps.errors.CoBrand}
                />
              </SectionBody>
            </SectionBox>
            {/* <SectionBox>
              <SectionHeader>
                <SectionHeaderText>Offers</SectionHeaderText>
              </SectionHeader>
              <SectionBody>
                <Checkbox
                  value={true}
                  labelLeft={true}
                  disabled={true}
                  title="Show Instore Offers"
                  label="Instore Offers"
                  formikKey="Instore"
                  formikProps={formikProps}
                  error={formikProps.errors.coBrand}
                />
              </SectionBody>
              <SectionBody>
                <Checkbox
                  value={true}
                  labelLeft={true}
                  disabled={true}
                  title="Show Third Party Offers"
                  label="Third Party Offers"
                  formikKey="ThirdParty"
                  formikProps={formikProps}
                  error={formikProps.errors.coBrand}
                />
              </SectionBody>
            </SectionBox>
            <SectionBox>
              <SectionHeader>
                <SectionHeaderText>Rewards & Campaigns</SectionHeaderText>
              </SectionHeader>
              <SectionBody>
                <Checkbox
                  value={true}
                  labelLeft={true}
                  disabled={true}
                  title="Enable Rewards"
                  label="Rewards"
                  formikKey="Rewards"
                  formikProps={formikProps}
                  error={formikProps.errors.coBrand}
                />
              </SectionBody>
              <SectionBody>
                <Checkbox
                  value={true}
                  labelLeft={true}
                  disabled={true}
                  title="Show Campaigns"
                  label="Campaigns"
                  formikKey="Campaigns"
                  formikProps={formikProps}
                  error={formikProps.errors.coBrand}
                />
              </SectionBody>
            </SectionBox>
            <SectionBox>
              <SectionHeader>
                <SectionHeaderText>Surveys & Feedback</SectionHeaderText>
              </SectionHeader>
              <SectionBody>
                <Checkbox
                  value={true}
                  labelLeft={true}
                  disabled={true}
                  title="Enable Surveys"
                  label="Surveys"
                  formikKey="Surveys"
                  formikProps={formikProps}
                  error={formikProps.errors.coBrand}
                />
              </SectionBody>
              <SectionBody>
                <Checkbox
                  value={true}
                  labelLeft={true}
                  disabled={true}
                  title="Show Feedback Form"
                  label="Feedback Form"
                  formikKey="Feedback"
                  formikProps={formikProps}
                  error={formikProps.errors.coBrand}
                />
              </SectionBody>
            </SectionBox> */}
            <ButtonContainer
              style={{
                ...ifIphoneX(
                  {
                    marginBottom: 0
                  },
                  {
                    paddingBottom: 16
                  }
                )
              }}
            >
              <PrimaryButton
                title="Update preferences"
                onPress={formikProps.handleSubmit}
                loading={formState.isLoading}
                disabled={formState.isLoading}
              />
            </ButtonContainer>
          </StyledScrollView>
        )}
      </Formik>
    </StyledSafeAreaView>
  );
};

const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.backgroundColor};
`;
const StyledScrollView = styled.ScrollView`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;
const SectionBox = styled.View`
  flex: 1;
  padding: 20px;
`;
const SectionHeader = styled.View`
  align-items: flex-start;
  background-color: ${theme.colors.backgroundColor};
  padding-left: 20px;
  padding-right: 20px;
  padding-top: 10px;
  padding-bottom: 10px;
  border-radius: 15px;
`;
const SectionHeaderText = styled.Text`
  color: ${theme.colors.textPrimary};
  font-weight: 500;
  font-size: 16px;
  font-family: 'MarkOffcPro';
`;
const SectionBody = styled.View`
  align-items: flex-start;
  background-color: ${theme.colors.none};
  padding-left: 10px;
  padding-right: 20px;
  padding-top: 1px;
  padding-bottom: 1px;
`;
const ButtonContainer = styled.View`
  padding: 20px 30px;
`;

FeaturePreference.propTypes = {
  navigation: PropTypes.object.isRequired
};

export default FeaturePreference;
