import styled from 'styled-components/native';
import { theme, DEVICE_HEIGHT } from '@utils';

export const StyledScrollView = styled.ScrollView`
  flex: 1;
  background-color: ${theme.colors.backgroundColor};
`;

export const StyledView = styled.View`
  flex: 1;
  margin-bottom: 120px;
`;

export const ProfileHeader = styled.View`
  align-items: center;
  min-height: ${DEVICE_HEIGHT * 0.3}px;
  background-color: ${theme.colors.backgroundLight};
  padding: 30px 0;
  margin-bottom: 12px;
  /* padding: 100px 0; */
`;

export const ButtonContainer = styled.View`
  padding: 20px 30px;
`;

export const UserAvatar = styled.ImageBackground`
  width: 100px;
  height: 100px;
  margin-bottom: 8px;
`;

export const Gap = styled.View`
  padding: 5px 0;
`;

export const Divider = styled.View`
  border-bottom-width: 1px;
  border-bottom-color: ${theme.colors.border};
`;
