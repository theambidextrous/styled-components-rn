import WelcomeScreen from './WelcomeScreen';

export default WelcomeScreen;
