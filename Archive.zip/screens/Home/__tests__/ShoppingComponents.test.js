import * as React from 'react';
import renderer from 'react-test-renderer';
import { Provider } from 'react-redux';
import { store } from '@stores';
import EarnPointsRoute from '../TabRendererRoutes/EarnPointsRoute';
import RewardsRoute from '../TabRendererRoutes/CampaignsRoute';

describe('home snapshots', () => {
  it('RewardsRoute', () => {
    const tree = renderer
      .create(
        <Provider store={store}>
          <RewardsRoute />
        </Provider>
      )
      .toJSON();
    expect(tree).toMatchSnapshot();
  });
  test('EarnPointsRoute', () => {
    const tree = renderer.create(<EarnPointsRoute />).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
