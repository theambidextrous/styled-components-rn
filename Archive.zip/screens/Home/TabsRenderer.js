import React from 'react';
import { View } from 'react-native';
import { TabBar } from 'react-native-tab-view';
import { ShopActionsButton, ShopActionsButtonText } from '@components';
import { theme, DEVICE_WIDTH } from '@utils/index';

const renderTabBar = (props) => (
  <TabBar
    renderLabel={({ route, focused }) => (
      <View>
        {focused ? (
          <View style={{ bottom: 8 }}>
            <ShopActionsButton
              background={theme.colors.black}
              radius={17}
              height={34}
              width={DEVICE_WIDTH * 0.39}
              text={route.title}
              icon={null}
              color={theme.colors.textWhite}
              transform="capitalize"
              size={14}
              style={{ fontFamily: 'MarkOffcPro-Bold' }}
              weight={500}
              lineHeight={16}
              // hasShadow={true}
            />
          </View>
        ) : (
          <ShopActionsButtonText
            text={route.title}
            color={theme.colors.black}
            transform="capitalize"
            style={{ fontFamily: 'MarkOffcPro-Bold' }}
            size={14}
            weight={700}
            lineHeight={18}
          />
        )}
      </View>
    )}
    {...props}
    indicatorStyle={{ backgroundColor: theme.colors.none }}
    style={{
      backgroundColor: theme.colors.progressBarEmpty,
      borderColor: theme.colors.tabStrokeColor,
      elevation: 0,
      borderRadius: 30,
      paddingHorizontal: 20,
      paddingVertical: 6,
      justifyContent: 'center'
    }}
    pressColor={{ backgroundColor: theme.colors.none }}
    activeColor={{
      color: theme.colors.black
    }}
    labelStyle={{
      color: theme.colors.black,
      lineHeight: 14,
      marginTop: 1,
      fontSize: 12,
      fontFamily: 'MarkOffcPro',
      textTransform: 'capitalize',
      fontWeight: 'bold'
    }}
  />
);

export default renderTabBar;
