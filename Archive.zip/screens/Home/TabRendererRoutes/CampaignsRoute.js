import React, { useEffect, useState } from 'react';
import styled from 'styled-components/native';
import { FlatList } from 'react-native';
import { useSelector } from 'react-redux';
import { UserApi } from 'mastercard_loyalty_sandbox_api';
import { CampaignSkeleton, EmptyState } from '@components/index';
import { theme, RefreshAuthToken, DEFAULT_TIMEOUT, client } from '@utils/index';

const placeholderArtWork = require('@assets/images/others/advertbanner.png');

// const DummyData = [
//   {
//     id: '1',
//     title: 'Awesome campaign',
//     body: 'this is an wesome campaign for you.',
//     imageUrl: placeholderArtWork
//   },
//   {
//     id: '2',
//     title: 'New campaign',
//     body: 'this is a new campaign for you.',
//     imageUrl: placeholderArtWork
//   },
//   {
//     id: '3',
//     title: 'Pretty campaign',
//     body: 'this is a Pretty campaign for you.',
//     imageUrl: placeholderArtWork
//   }
// ];

const CampaignsRoute = () => {
  const persistedState = useSelector((state) => state);
  const authStoreState = persistedState.authentication;
  const { accessToken, refreshToken, expiresAt } = authStoreState.session;
  const currentShop = persistedState.multiStore;
  const { applicationId } = currentShop;

  const [myCampigns, SetCampigns] = useState({
    error: null,
    items: [],
    isLoading: false
  });

  const GetHomeCampigns = async () => {
    SetCampigns({ ...myCampigns, isLoading: true });
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    client.timeout = DEFAULT_TIMEOUT;
    const api = new UserApi(client);
    api.listCampaigns({ appId: applicationId }, (error, data, response) => {
      // console.log('campigns', response.body);
      if (response !== undefined && Number(response.statusCode) < 205) {
        const { campaigns } = response.body;
        SetCampigns({ ...myCampigns, items: campaigns, isLoading: false });
      } else {
        SetCampigns({ ...myCampigns, isLoading: false });
      }
    });
  };

  useEffect(() => {
    GetHomeCampigns();
    return () => {};
  }, []);

  return (
    <RouteContainer>
      <SingleFlexView>
        <OfferContainer>
          {myCampigns.isLoading ? (
            <CampaignSkeleton />
          ) : (
            <FlatList
              horizontal={false}
              ListFooterComponent={<CampaignFooterComponent />}
              ListEmptyComponent={
                <EmptyState
                  title="No campaigns found"
                  subTitle="You do not have any campaigns yet"
                />
              }
              showsHorizontalScrollIndicator={true}
              nestedScrollEnabled
              contentContainerStyle={{
                width: '100%'
              }}
              data={myCampigns.items}
              keyExtractor={(item, index) => String(index)}
              renderItem={({ item }) => (
                <CampaignButton>
                  <CampaignButtonInner>
                    <RouteTopImageBackground
                      imageStyle={{ borderRadius: 5 }}
                      resizeMode="cover"
                      style={{ flex: 1 }}
                      source={
                        item.imageUrl.length > 0
                          ? { uri: item.imageUrl }
                          : placeholderArtWork
                      }
                    />
                    <CampaignTextWrapper>
                      <CampignTitle numberOfLines={1}>
                        {item.title}
                      </CampignTitle>
                      <CampignSubTitle numberOfLines={2}>
                        {item.body}
                      </CampignSubTitle>
                    </CampaignTextWrapper>
                  </CampaignButtonInner>
                </CampaignButton>
              )}
            />
          )}
        </OfferContainer>
      </SingleFlexView>
    </RouteContainer>
  );
};

const OfferContainer = styled.View`
  flex: 1;
`;
const CampaignButton = styled.TouchableOpacity`
  width: 100%;
  height: 80px;
  background-color: ${theme.colors.backgroundColor};
  margin-bottom: 10px;
`;
const CampaignButtonInner = styled.View`
  flex: 1;
  flex-direction: row;
  padding: 10px;
`;
const CampaignTextWrapper = styled.View`
  flex: 3;
  justify-content: center;
  align-items: flex-start;
  padding: 10px;
`;

const CampaignFooterComponent = styled.View`
  height: 100px;
`;

const CampignTitle = styled.Text`
  font-family: 'MarkOffcPro';
  font-size: 18px;
  line-height: 21px;
  text-align: left;
  font-weight: 700;
  color: ${theme.colors.black};
`;

const CampignSubTitle = styled.Text`
  font-family: 'MarkOffcPro';
  font-size: 14px;
  line-height: 18px;
  text-align: left;
  font-weight: normal;
  color: ${theme.colors.black};
`;

const RouteContainer = styled.View`
  flex: 1;
  background-color: ${theme.colors.none};
  margin-top: 10px;
`;
const RouteTopImageBackground = styled.ImageBackground`
  width: 100%;
  height: auto;
`;

const SingleFlexView = styled.View`
  flex: 1;
  justify-content: center;
`;

export default CampaignsRoute;
