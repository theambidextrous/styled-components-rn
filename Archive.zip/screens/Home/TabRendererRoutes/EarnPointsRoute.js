import React from 'react';
import { View, StyleSheet } from 'react-native';
import styled from 'styled-components/native';
import { theme } from '@utils/index';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import { ShopActionsText } from '@components';
import { useSelector } from 'react-redux';
import { useTheme } from 'styled-components';

const ListData = [
  {
    icon: 'star',
    title: 'Earn Points',
    isPoints: true,
    subtitle: 'You earn 1 points for every $ you spend'
  },
  {
    icon: 'heart-outline',
    title: 'Create Wishlist',
    subtitle: 'Get 60 points when you add at least 3 items to your wishlist'
  }
];
const EarnPointsRoute = () => {
  const persistedState = useSelector((state) => state);
  const userState = persistedState.authentication;
  const shopTheme = useTheme();
  const { pointsConversionFactor } = userState.user;
  return (
    <View style={{ alignItems: 'center', marginVertical: 20 }}>
      <View>
        {ListData.map((val, key) => (
          <StyledEarnPointsListItem key={key} style={ViewShadows.shadow}>
            <ListItemLeftView>
              <EmptySquare>
                <MIcon
                  name={val.icon}
                  color={shopTheme.colors.primary || theme.colors.primary}
                  size={25}
                />
              </EmptySquare>
            </ListItemLeftView>
            <ListItemRightView>
              <ShopActionsText
                text={val.title}
                size={14}
                lineHeight={16}
                weight={500}
                transform="none"
                style={{ marginBottom: 2, fontFamily: 'MarkOffcPro-Bold' }}
                color={theme.colors.black}
              />
              <ShopActionsText
                text={
                  val.isPoints
                    ? `You earn ${pointsConversionFactor} points for every $ you spend`
                    : val.subtitle
                }
                size={11}
                lineHeight={15}
                weight={400}
                style={{ marginBottom: 2, fontFamily: 'MarkOffcPro' }}
                transform="none"
                color={theme.colors.black}
              />
            </ListItemRightView>
          </StyledEarnPointsListItem>
        ))}
      </View>
    </View>
  );
};
const ListItemLeftView = styled.View`
  width: 45px;
  margin-right: 10px;
`;
const ListItemRightView = styled.View`
  flex: 1;
`;
const EmptySquare = styled.View`
  width: 45px;
  height: 45px;
  border-width: 2px;
  border-color: ${(props) =>
    props.theme.colors.primary || theme.colors.primary};
  border-radius: 8px;
  justify-content: center;
  align-items: center;
`;
const StyledEarnPointsListItem = styled.View`
  background-color: ${theme.colors.textWhite};
  /* height: 68px; */
  width: 95%;
  border-radius: 8px;
  margin-bottom: 10px;
  border: 0.5px;
  border-color: ${theme.colors.progressBarEmpty};
  flex-direction: row;
  align-items: center;
  padding: 12px 16px;
`;
const ViewShadows = StyleSheet.create({
  shadow: {
    shadowColor: 'rgba(0,0,0,0.07)',
    shadowOffset: { height: 1, width: 1 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 8
  }
});

export default EarnPointsRoute;
