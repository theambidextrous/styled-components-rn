import React, { useEffect, useState, useCallback } from 'react';
import {
  Dimensions,
  Alert,
  View,
  StyleSheet,
  Platform,
  RefreshControl
} from 'react-native';
import styled from 'styled-components/native';
import { useScrollToTop } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { TabView, SceneMap } from 'react-native-tab-view';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import PropTypes from 'prop-types';
import { useSelector, useDispatch } from 'react-redux';
import { ProductsApi, UserApi, DemosApi } from 'mastercard_loyalty_sandbox_api';
import { useTheme } from 'styled-components';

import * as actions from '@stores/actions';
import {
  CustomStatusBar,
  LoadingIndicator,
  ShopActionsButton,
  ShopActionsText,
  NewArrivalItemRow,
  NewArrivalsSkeleton,
  UserTierCard,
  ModalPopUp,
  Text
} from '@components/';
import {
  theme,
  isBiometricDevice,
  enableBiometrics,
  client,
  extractError,
  ProductListFormatter,
  getTierHeaderBackground,
  RefreshAuthToken,
  UpdateUserDeviceToken,
  PullGearProduct,
  AppTracker,
  WOOCOMERCE_TIMEOUT,
  DEFAULT_TIMEOUT
} from '@utils/index';

import renderTabBar from './TabsRenderer';
import CampaignsRoute from './TabRendererRoutes/CampaignsRoute';
import EarnPointsRoute from './TabRendererRoutes/EarnPointsRoute';

const WelcomeScreen = ({ navigation }) => {
  const ref = React.useRef(null);

  /**  tracker */
  const apptracker = new AppTracker();

  useScrollToTop(ref);
  /** local states */
  const dispatcher = useDispatch();
  /** moved it up -- redux selector */
  const persistedState = useSelector((state) => state);
  const currentShop = persistedState.multiStore;
  const shopTheme = useTheme();
  const { applicationId, thirdPartyShopId } = currentShop;
  const [index, setIndex] = useState(0);
  const [routes] = useState([
    { key: 'campaigns', title: 'Campaigns' },
    { key: 'earnPoints', title: 'Earn Points' }
  ]);
  const [deviceBiometric, SetDeviceBiometric] = useState({
    biometryType: null,
    success: false,
    msg: ''
  });
  const [isLoading, SetLoading] = useState(false);
  const [isLoadingProfile, SetLoadingProfile] = useState(false);
  const [offerModal, SetOfferMOdal] = useState(false);
  const [newArrivals, SetNewArrivals] = useState({
    error: null,
    items: [],
    isLoading: false,
    currentShop
  });
  /** for refresh control */
  const [refreshing, SetRefreshing] = useState(false);

  const renderScene = SceneMap({
    campaigns: CampaignsRoute,
    earnPoints: EarnPointsRoute
  });

  const authStoreState = persistedState.authentication;
  const { accessToken, refreshToken, expiresAt, email } =
    authStoreState.session;
  const userTier = persistedState.points;
  const { hasSeenOffer } = persistedState.preference;

  const GetFeaturePreference = async () => {
    try {
      const newTkn = await RefreshAuthToken(
        accessToken,
        refreshToken,
        expiresAt
      );
      client.timeout = DEFAULT_TIMEOUT;
      client.defaultHeaders = {
        authorization: `Bearer ${newTkn.accessToken}`
      };
      const api = new DemosApi(client);
      api.getDemoPreferences((error, data, response) => {
        if (response !== undefined && Number(response.statusCode) < 205) {
          const newPreference = response.body;
          dispatcher(actions.setGeneralFeaturePreference(newPreference));
        } else {
          /** error */
          const errorData = extractError(error);
          Alert.alert('Error fetching preferences', errorData.Details);
        }
      });
    } catch (error) {
      console.log('error', error);
      Alert.alert('Error fetching preferences', String(error));
    }
  };

  const GetNewArrivals = async () => {
    try {
      SetNewArrivals({ ...newArrivals, isLoading: true });
      const newTkn = await RefreshAuthToken(
        accessToken,
        refreshToken,
        expiresAt
      );
      client.timeout = WOOCOMERCE_TIMEOUT;
      client.defaultHeaders = {
        authorization: `Bearer ${newTkn.accessToken}`
      };
      const api = new ProductsApi(client);
      api.getNewArrivals({ appId: applicationId }, (error, data, response) => {
        // console.log('response', response);
        if (response !== undefined && Number(response.statusCode) < 205) {
          const productsPayload = response.body.products;
          const cleanedUp = ProductListFormatter(productsPayload);
          SetNewArrivals({
            ...newArrivals,
            items: cleanedUp,
            isLoading: false
          });
        } else {
          /** error */
          const errorData = extractError(error);
          apptracker.logWooCommerceFailure(
            'Fetch new arrivals failure',
            errorData.Details,
            email
          );
          SetNewArrivals({
            ...newArrivals,
            error: errorData.Details,
            isLoading: false
          });
        }
      });
    } catch (error) {
      apptracker.logWooCommerceFailure(
        'Fetch new arrivals failure',
        String(error),
        email
      );
      SetNewArrivals({
        ...newArrivals,
        error: String(error),
        isLoading: false
      });
    }
  };

  // get user points
  const fetchUserProfile = async (isRefreshing = false) => {
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    client.timeout = DEFAULT_TIMEOUT;
    const apiInstance = new UserApi(client);
    apiInstance.getUserProfile((error, data, response) => {
      // console.log('timeout', client.timeout);
      // console.log('error', error);
      if (response && response.statusCode === 200) {
        const {
          nextTierName,
          nextTierRemainingPoints,
          tierName,
          tierPoints,
          tierTotalPoints,
          hasCobrandCard,
          spendablePoints,
          pcloCobrandConversionFactor,
          pointsConversionFactor,
          pcloPointsConversionFactor,
          coBrandPointsConversionFactor
        } = response.body;
        if (!isRefreshing) {
          if (!hasCobrandCard && !hasSeenOffer) {
            SetOfferMOdal(true);
          }
        }
        dispatcher(actions.userRegistered(response.body, true));
        dispatcher(
          actions.setUserTier(
            tierName,
            tierPoints,
            nextTierName,
            nextTierRemainingPoints,
            tierTotalPoints,
            spendablePoints,
            pcloCobrandConversionFactor,
            pointsConversionFactor,
            pcloPointsConversionFactor,
            coBrandPointsConversionFactor
          )
        );
        SetLoadingProfile(false);
      } else {
        const errorData = extractError(error);
        Alert.alert('Oops, something went wrong', errorData.Details);
      }
    });
  };

  const NavigateTo = (route, screen, item = {}) => {
    if (screen === 'ProductDetails') {
      dispatcher(actions.openedProduct(item));
    }
    navigation.navigate(route, { screen, params: item });
  };
  const OnProductPressed = (item) => {
    dispatcher(actions.openedProduct(item));
    navigation.navigate('Checkout', { screen: 'ProductDetails', params: item });
  };
  const isBiometricDeviceState = (biometryType, success, msg) => {
    SetDeviceBiometric({
      ...deviceBiometric,
      biometryType,
      success,
      msg
    });
  };
  const enableBiometricsState = (
    hasFingerUnlock,
    hasFaceUnlock,
    status,
    message
  ) => {
    if (hasFaceUnlock || hasFingerUnlock) {
      dispatcher(actions.enabledBiometrics(hasFaceUnlock, hasFingerUnlock));
      SetLoading(false);
      Alert.alert('Biometrics enabled', message);
    } else if (!status) {
      SetLoading(false);
      Alert.alert('Biometrics error', message);
    }
  };
  useEffect(async () => {
    try {
      PullGearProduct(thirdPartyShopId, accessToken);
    } catch (error) {
      // console.log('gear item error', error);
    }
    fetchUserProfile();
    GetNewArrivals();
    GetFeaturePreference();
    dispatcher(actions.setDemoAdminPassword());
    dispatcher(actions.setIsThirdParty(false));
    const deviceToken = await AsyncStorage.getItem('deviceToken');
    // console.log('deviceToken', deviceToken);
    UpdateUserDeviceToken(deviceToken);
    if (!authStoreState.cancelledBiometricsRequest) {
      isBiometricDevice(isBiometricDeviceState);
    }
    if (
      deviceBiometric.success === true &&
      authStoreState.hasFaceUnlock === false &&
      authStoreState.hasFingerUnlock === false
    ) {
      Alert.alert(
        'Biometrics access',
        `Would you like to enable ${deviceBiometric.biometryType} login?`,
        [
          {
            text: 'Enable',
            onPress: () => {
              SetLoading(true);
              enableBiometrics(
                deviceBiometric.biometryType,
                enableBiometricsState
              );
            },
            style: 'destructive'
          },
          {
            text: 'Cancel',
            onPress: () => dispatcher(actions.cancelledBiometricsRequest(true)),
            style: 'cancel'
          }
        ]
      );
    }
    return () => {};
  }, [deviceBiometric.success]);

  /** on refresh magic */
  const wait = (timeout) =>
    new Promise((resolve) => setTimeout(resolve, timeout));

  const onRefresh = useCallback(() => {
    SetRefreshing(true);
    fetchUserProfile(true);
    GetNewArrivals();
    wait(2000).then(() => SetRefreshing(false));
  }, []);

  // Show a loader on mount to set the usertier and set the theme appropriately
  if ((isLoadingProfile || isLoading) && !refreshing) {
    return (
      <View style={{ flex: 1, backgroundColor: '#FCFDFF' }}>
        <CustomStatusBar />
        <StyledSafeAreaView>
          <LoadingWrapper>
            <LoadingIndicator size="small" />
          </LoadingWrapper>
        </StyledSafeAreaView>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#FCFDFF' }}>
      <StyledImageBackground
        source={getTierHeaderBackground(userTier.tierName)}
        resizeMode="cover"
      />
      <CustomStatusBar isLightContent={userTier.tierName === 'Silver'} />
      {/* offer modal */}
      <ModalPopUp visible={offerModal}>
        <StyledModalTitle>Co-brand Card Offer</StyledModalTitle>
        <SingleRowView>
          <SingleFlexView>
            <MIcon
              name="gift"
              size={40}
              color={shopTheme.colors.primary || theme.colors.primary}
            />
          </SingleFlexView>
          <View style={{ flex: 4 }}>
            <StyledModalSubTitle>
              Apply for co-brand card and get 15% OFF on todays purchases as
              well as free shipping
            </StyledModalSubTitle>
          </View>
        </SingleRowView>
        <BorderLine />
        <SingleRowView>
          <SingleFlexView>
            <CancelButton
              isFilled={true}
              onPress={() => {
                SetOfferMOdal(false);
                dispatcher(actions.setUserCobrandOfferPreference(true));
                navigation.navigate('CobrandCards', {
                  screen: 'CoBrandCardBanner'
                });
              }}
            >
              <CancelCardText isFilled={true}>Apply</CancelCardText>
            </CancelButton>
          </SingleFlexView>
          <SingleFlexView>
            <CancelButton
              onPress={() => {
                SetOfferMOdal(false);
                dispatcher(actions.setUserCobrandOfferPreference(true));
              }}
            >
              <CancelCardText>Not now</CancelCardText>
            </CancelButton>
          </SingleFlexView>
        </SingleRowView>
      </ModalPopUp>
      {/* offer end */}
      <StyledSafeAreaView>
        <Container
          ref={ref}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              progressBackgroundColor={theme.colors.textWhite}
              tintColor={theme.colors.textWhite}
              style={{ backgroundColor: theme.colors.none }}
              refreshing={refreshing}
              onRefresh={onRefresh}
            />
          }
        >
          {/* Points */}
          <TierWrapper>
            <UserTierCard
              tierPoints={userTier.tierPoints || 0}
              totalTierPoints={userTier.tierTotalPoints}
              tierName={userTier.tierName}
              nextTier={userTier.nextTierName}
              nextTierRemainingPoints={userTier.nextTierRemainingPoints}
            />
          </TierWrapper>
          <RewardsSectionContainer style={JsxStyle.RewardsSectionContainer}>
            <TabView
              renderTabBar={renderTabBar}
              style={JsxStyle.TabView}
              navigationState={{ index, routes }}
              renderScene={renderScene}
              onIndexChange={setIndex}
              initialLayout={{ width: Dimensions.get('window').width }}
            />
          </RewardsSectionContainer>
          {/* New arrivals */}
          <ProductsContainer style={JsxStyle.ProductsContainer}>
            <TitleHolderView style={JsxStyle.TitleHolderView}>
              <FlexView flex={3}>
                <ShopActionsText
                  style={{ fontFamily: 'Montserrat' }}
                  text="New arrivals"
                  size={18}
                  lineHeight={22}
                  weight={700}
                  transform="none"
                  color={theme.colors.textPrimary}
                />
              </FlexView>
              <FlexView flex={1}>
                <ShopActionsButton
                  background={theme.colors.none}
                  radius={0}
                  height={32}
                  width={100}
                  text="Show all"
                  color={shopTheme.colors.primary || theme.colors.primary}
                  transform="none"
                  size={18}
                  weight={300}
                  lineHeight={24}
                  press={() => NavigateTo('Home', 'MainShop')}
                />
              </FlexView>
            </TitleHolderView>
            <View>
              {newArrivals.isLoading && (
                <>
                  <ArrivalsHolderView>
                    <NewArrivalsSkeleton />
                  </ArrivalsHolderView>
                </>
              )}
              {newArrivals.error !== null && (
                <EmptyStateWrapper>
                  <Text as="H5">{newArrivals.error}</Text>
                </EmptyStateWrapper>
              )}
            </View>
            <ArrivalsHolderView>
              {newArrivals.items.length > 0 ? (
                newArrivals.items.map((item, key) => (
                  <NewArrivalItemRow
                    key={key}
                    item={item}
                    OnProductPressed={OnProductPressed}
                  />
                ))
              ) : (
                <EmptyStateWrapper>
                  <Text as="H5">Couldn&apos;t find any products.</Text>
                </EmptyStateWrapper>
              )}
            </ArrivalsHolderView>
          </ProductsContainer>
        </Container>
      </StyledSafeAreaView>
    </View>
  );
};

const StyledImageBackground = styled.ImageBackground`
  position: absolute;
  width: 100%;
  top: 0;
  bottom: 0;
  height: 240px;
`;

const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
`;

const Container = styled.ScrollView`
  flex: 1;
  z-index: 100;
  margin-top: ${Platform.OS === 'ios'
    ? Dimensions.get('screen').height * 0.06
    : Dimensions.get('screen').height * 0.1125}px;
`;

const TierWrapper = styled.View`
  margin-top: 30px;
  padding: 0 20px;
`;

const FlexView = styled.View`
  flex: ${(props) => props.flex};
`;

const RewardsSectionContainer = styled.View`
  height: 260px;
  background-color: ${theme.colors.textWhite};
  margin-top: -8px;
`;
const ProductsContainer = styled.View`
  /* height: 200px; */
  background-color: ${theme.colors.textWhite};
  /* margin-top: 10px; */
  padding-bottom: ${Dimensions.get('screen').height * 0.075}px;
`;

const LoadingWrapper = styled.View`
  flex: 1;
  margin-top: 25px;
  justify-content: center;
  align-items: center;
`;
const TitleHolderView = styled.View`
  margin-top: 20px;
  margin-bottom: 20px;
  flex-direction: row;
  align-items: center;
`;
const ArrivalsHolderView = styled.View`
  flex-direction: row;
  justify-content: space-between;
  flex: 1;
  flex-wrap: wrap;
  padding: 0 20px;
`;

const StyledModalTitle = styled.Text`
  font-family: 'MontrealSerialBold';
  font-size: 22px;
  line-height: 26px;
  text-align: center;
  color: ${theme.colors.modalTextBlack};
  margin-bottom: 15px;
`;

const StyledModalSubTitle = styled.Text`
  font-family: 'Montreal';
  font-size: 18px;
  line-height: 21px;
  text-align: left;
  color: ${theme.colors.textSecondary};
  margin-bottom: 23px;
`;

const EmptyStateWrapper = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
  padding: 20px 0;
`;

const BorderLine = styled.View`
  border: 1px solid #f5f5f5;
`;
const CancelButton = styled.TouchableOpacity`
  border: solid;
  border-width: 1px;
  border-color: ${(props) =>
    props.isFilled ? props.theme.colors.primary : theme.colors.textPrimary};
  padding: 10px;
  border-radius: 20px;
  margin-top: 15px;
  z-index: 1;
  background-color: ${(props) =>
    props.isFilled ? props.theme.colors.primary : theme.colors.none};
  margin-right: 16px;
`;
const CancelCardText = styled.Text`
  font-family: MarkOffcPro;
  font-weight: 700;
  line-height: 22px;
  font-size: 18px;
  color: ${(props) =>
    props.isFilled ? theme.colors.textWhite : theme.colors.textPrimary};
  text-align: center;
`;

const SingleFlexView = styled.View`
  flex: 1;
`;
const SingleRowView = styled.View`
  flex-direction: row;
`;

WelcomeScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};
const JsxStyle = StyleSheet.create({
  ProductsContainer: {},
  TitleHolderView: {
    marginHorizontal: 20
  },
  TabView: {
    maxWidth: '100%',
    paddingHorizontal: 20,
    marginVertical: 20,
    minHeight: 310
  },
  RewardsSectionContainer: {},
  PointsSectionContainer: {
    minHeight: 150
  }
});

export default WelcomeScreen;
