import React, { useState, useEffect, useCallback } from 'react';
import styled from 'styled-components';
import {
  SafeAreaView,
  FlatList,
  StyleSheet,
  RefreshControl
} from 'react-native';
import { useSelector } from 'react-redux';
import { PointsTransactionsApi } from 'mastercard_loyalty_sandbox_api';

import {
  client,
  RefreshAuthToken,
  extractError,
  theme,
  dateFormat,
  removeDuplicates,
  getStatusBar
} from '@utils';

import {
  TriggerLocalNotification,
  PointsTransaction,
  PointsBanner,
  Text,
  NextTierCard,
  CustomStatusBar,
  LoadingIndicator
} from '@components';

const PointsScreen = () => {
  const appState = useSelector((state) => state);
  const authState = appState.authentication;
  const userTier = appState.points;
  const {
    tierName,
    tierPoints,
    spendablePoints,
    nextTierRemainingPoints,
    nextTierName
  } = userTier;

  const { accessToken, refreshToken, expiresAt } = authState.session;
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [transactions, setTransactions] = useState([]);
  const [offset, setOffset] = useState(0);
  const [isListEnd, setIsListEnd] = useState(false);

  useEffect(() => {
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    if (!loading && !isListEnd) {
      setLoading(true);
      const newTkn = await RefreshAuthToken(
        accessToken,
        refreshToken,
        expiresAt
      );
      client.defaultHeaders = {
        authorization: `Bearer ${newTkn.accessToken}`
      };
      const api = new PointsTransactionsApi(client);
      api.listPointsTransactions(
        {
          limit: 10,
          offset
        },
        (error, data, response) => {
          if (Number(response && response.statusCode) < 205) {
            if (Array.isArray(response.body.pointsTransactions)) {
              const transactionsPayload = response.body.pointsTransactions;
              const formattedTransactionsPayload =
                removeDuplicates(transactionsPayload);
              if (transactionsPayload.length !== 0) {
                setOffset(offset + 10);
                setTransactions([
                  ...transactions,
                  ...formattedTransactionsPayload
                ]);
                setLoading(false);
                setIsListEnd(false);
              } else {
                setTransactions([...transactions]);
                setIsListEnd(true);
                setLoading(false);
              }
            }
          } else {
            setTransactions([...transactions]);
            setLoading(false);
            const errorData = extractError(error);
            TriggerLocalNotification({
              message: errorData.Details,
              type: 'info',
              icon: 'warning'
            });
          }
        }
      );
    }
  };
  const HeaderComponent = () => (
    <>
      <PointsBanner
        tierName={tierName}
        tierPoints={tierPoints}
        spendablePoints={spendablePoints}
      />
      {tierName && tierName.toUpperCase() !== 'PLATINUM' && (
        <NextTierCard
          nextTier={nextTierName}
          nextTierRemainingPoints={nextTierRemainingPoints}
        />
      )}
      <Gap />
      <HeaderWrapper>
        <Text style={styles.titleText} as="H3">
          Transaction
        </Text>
        <Text style={styles.pointsText} as="H3">
          Points
        </Text>
      </HeaderWrapper>
    </>
  );

  const wait = (timeout) =>
    new Promise((resolve) => setTimeout(resolve, timeout));

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    fetchTransactions();
    wait(2000).then(() => setRefreshing(false));
  }, []);

  const FooterComponent = () => (loading ? <LoadingIndicator /> : null);

  return (
    <SafeAreaView style={{ backgroundColor: 'white', flex: 1 }}>
      <CustomStatusBar isLightContent={getStatusBar(tierName)} />
      <StyledView>
        <FlatList
          nestedScrollEnabled
          data={transactions}
          onEndReached={fetchTransactions}
          onEndReachedThreshold={0.2}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          ListHeaderComponent={HeaderComponent}
          ListFooterComponent={FooterComponent}
          contentContainerStyle={{ paddingBottom: 90 }}
          keyExtractor={(item) => item.id}
          renderItem={(itemData) => {
            const { item } = itemData;
            const dateWithYear = dateFormat(item.timeOfOccurrence);
            const dateArray = dateWithYear.split(',');
            const dateWithoutYear = `${dateArray[0]}, ${dateArray[2]} `;
            return (
              <PointsTransaction
                transactionName={item.accountName}
                transactionDate={dateWithoutYear}
                transactionPoints={item.amount}
              />
            );
          }}
        />
      </StyledView>
    </SafeAreaView>
  );
};
const StyledView = styled.View`
  flex: 1;
`;

const HeaderWrapper = styled.View`
  flex-direction: row;
  justify-content: space-between;
  padding: 20px 20px 10px 20px;
  align-items: center;
`;

const Gap = styled.View`
  padding: 5px 0;
  background-color: ${theme.colors.backgroundColor};
`;
const styles = StyleSheet.create({
  titleText: {
    color: theme.colors.textPrimary,
    fontSize: 18,
    fontFamily: 'MarkOffcPro-Black',
    textAlign: 'left'
  },
  pointsText: {
    color: theme.colors.primary,
    textAlign: 'right',
    fontSize: 18,
    fontFamily: 'MarkOffcPro'
  }
});

export default PointsScreen;
