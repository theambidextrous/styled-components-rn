import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { theme } from '@utils/';
import { CustomStatusBar } from '@components';

const AdminNextScreen = () => (
  <StyledSafeAreaView>
    <CustomStatusBar isLightContent />
  </StyledSafeAreaView>
);

const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.none};
`;

AdminNextScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

export default AdminNextScreen;
