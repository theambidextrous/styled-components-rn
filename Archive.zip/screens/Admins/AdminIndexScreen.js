import React, { useState } from 'react';
import { Text, Alert } from 'react-native';
import PropTypes from 'prop-types';
import { DemosApi, DemoUserLoginRequest } from 'mastercard_loyalty_sandbox_api';
import { useDispatch, useSelector } from 'react-redux';
import * as actions from '@stores/actions';
import styled from 'styled-components/native';
import { theme, RefreshAuthToken, client, extractError } from '@utils/index';
import {
  CustomStatusBar,
  PrimaryButton,
  ShopActionsText,
  LoadingIndicator
} from '@components/index';

const AdminIndexScreen = ({ navigation }) => {
  const findTokenExpiryFromNow = (expiration) => {
    const seconds = Math.floor(Date.now() / 1000);
    return Number(seconds) + Number(expiration);
  };

  const dispatcher = useDispatch();
  const [isLoading, SetLoading] = useState(false);
  const persistedState = useSelector((state) => state);
  const authStoreState = persistedState.authentication;
  const activeProfile = authStoreState.user;
  const superAdminState = persistedState.demoUser;
  // console.log(
  //   'superAdminState',
  //   superAdminState,
  //   'superAdminState token',
  //   superAdminState.session.accessToken
  // );
  const demoUsers = superAdminState.users;
  const superUserTokensData = superAdminState.session;
  const { accessToken, refreshToken, expiresAt } = superUserTokensData;
  // console.log('superAdminState', superUserTokensData);
  const { adminPass, hasAuthenticated } = persistedState.preference;

  const HandleGenerateUsers = async () => {
    SetLoading(true);
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const api = new DemosApi(client);
    api.generateDemoUsers((error, data, response) => {
      if (response && Number(response.statusCode) < 205) {
        dispatcher(actions.storeDemoUsers(response.body));
        SetLoading(false);
      } else {
        SetLoading(false);
        const errorData = extractError(error);
        Alert.alert('Something went wrong', errorData.Details);
      }
    });
  };
  const handleResetUsers = async () => {
    SetLoading(true);
    // try {
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const api = new DemosApi(client);
    api.resetDemoUsers((error, data, response) => {
      if (response && Number(response.statusCode) < 205) {
        Alert.alert(
          'Reset Successful',
          'Your reset request is now queued for processing. Please check again in a minute.'
        );
        SetLoading(false);
      } else {
        SetLoading(false);
        const errorData = extractError(error);
        Alert.alert('Something went wrong', errorData.Details);
      }
    });
    // } catch (error) {
    //   SetLoading(false);
    //   console.log('error ====>', error);
    // }
  };

  const HandleLoginAsUser = async (selectedUser) => {
    SetLoading(true);
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const { email } = selectedUser;
    const api = new DemosApi(client);
    api.demoUserLogin(
      DemoUserLoginRequest.constructFromObject({ email }),
      (error, data, response) => {
        if (response && Number(response.statusCode) < 205) {
          const authData = response.body;
          const sessionData = {
            accessToken: authData.accessToken,
            refreshToken: authData.refreshToken,
            expiresIn: authData.expiresIn,
            expiresAt: findTokenExpiryFromNow(authData.expiresIn),
            email,
            password: 'nopasswordfordemousers'
          };
          dispatcher(actions.clearUserStore());
          dispatcher(actions.clearCart());
          dispatcher(actions.clearWishlist());
          dispatcher(actions.clearPointsStore());
          dispatcher(actions.clearCardsStore());
          dispatcher(actions.clearPreferenceStore());
          dispatcher(actions.userSignedIn(sessionData, true));
          dispatcher(actions.setDemoAdminAuthenticated(true));
          SetLoading(false);
          navigation.navigate('Home');
        } else {
          SetLoading(false);
          const errorData = extractError(error);
          Alert.alert('Something went wrong', errorData.Details);
        }
      }
    );
  };

  const HandleAdminUserAuthenticate = (pin) => {
    if (pin.length === 4) {
      if (Number(pin) === Number(adminPass)) {
        dispatcher(actions.setDemoAdminAuthenticated(true));
        return;
      }
      Alert.alert('Invalid Pin', 'The PIN you entered is invalid, try again');
    }
  };

  const UsersMetaRow = ({ userMeta }) => {
    const userArray = userMeta.email.split('_');
    const isActiveProfile = activeProfile.email === userMeta.email;
    return (
      <UserRow isActive={isActiveProfile}>
        <UserNameCol>
          <Text numberOfLines={1}>
            {`${userMeta.firstName} - ${userArray[0]}`}
          </Text>
        </UserNameCol>
        <UserTierCol>
          <AdminButton
            disabled={isActiveProfile}
            onPress={() => HandleLoginAsUser(userMeta)}
          >
            {isActiveProfile ? (
              <AdminCardText>Active</AdminCardText>
            ) : (
              <AdminCardText>Login As</AdminCardText>
            )}
          </AdminButton>
        </UserTierCol>
      </UserRow>
    );
  };
  UsersMetaRow.propTypes = {
    userMeta: PropTypes.objectOf(PropTypes.any).isRequired
  };
  return (
    <StyledSafeAreaView>
      <CustomStatusBar isLightContent />
      <HeaderSection>
        <HeaderTextWrapper>
          <ShopActionsText
            text="Generate Demo users"
            size={18}
            lineHeight={22}
            weight={500}
            transform="none"
            color={theme.colors.textPrimary}
            style={{ fontWeight: '900', fontFamily: 'MarkOffcPro-Black' }}
          />
          {hasAuthenticated && (
            <>
              <Gap />
              <PrimaryButton
                style={{ width: 300 }}
                title="Generate"
                disabled={demoUsers.length > 0}
                onPress={HandleGenerateUsers}
              />
            </>
          )}
          {!hasAuthenticated && (
            <PinInputHolder>
              <PinInput
                label="4 digit PIN"
                placeholder="4 digit PIN"
                keyboardType="numeric"
                placeholderTextColor={theme.colors.textPrimary}
                maxLength={4}
                onChangeText={HandleAdminUserAuthenticate}
              />
            </PinInputHolder>
          )}
        </HeaderTextWrapper>
      </HeaderSection>
      {hasAuthenticated && (
        <>
          <Gap />
          <UsersSection>
            <HeaderTextWrapper>
              <ShopActionsText
                text="Demo Users"
                size={18}
                lineHeight={22}
                weight={500}
                transform="none"
                color={theme.colors.textPrimary}
                style={{
                  fontWeight: '900',
                  fontFamily: 'MarkOffcPro-Black'
                }}
              />
              <Gap />
              {demoUsers.map((entry, index) => (
                <UsersMetaRow key={String(index)} userMeta={entry} />
              ))}

              <Gap />

              {demoUsers.length === 0 && !isLoading && (
                <Text>No records found</Text>
              )}

              {isLoading && <LoadingIndicator />}
              {demoUsers.length > 0 && (
                <AdminButton style={{ width: 300 }} onPress={handleResetUsers}>
                  <AdminResetText>Reset All</AdminResetText>
                </AdminButton>
              )}
            </HeaderTextWrapper>
          </UsersSection>
        </>
      )}
    </StyledSafeAreaView>
  );
};

const PinInput = styled.TextInput`
  border-width: 1px;
  border-color: ${theme.colors.progressBarEmpty};
  width: 200px;
  border-radius: 20px;
  padding: 12px;
  text-align: center;
  letter-spacing: 4px;
`;
const PinInputHolder = styled.View`
  margin-top: 20px;
  margin-bottom: 20px;
`;
const Gap = styled.View`
  height: 6px;
`;
const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.none};
`;
const HeaderSection = styled.View`
  background-color: ${theme.colors.textWhite};
  border-radius: 20px;
  margin: 10px;
`;

const UsersSection = styled.ScrollView`
  background-color: ${theme.colors.textWhite};
  border-radius: 20px;
  margin: 10px;
`;

const HeaderTextWrapper = styled.View`
  justify-content: center;
  align-items: center;
  margin-top: 20px;
  margin-bottom: 20px;
`;
const UserRow = styled.View`
  flex-direction: row;
  margin-right: 20px;
  margin-left: 20px;
  border-top-width: 1px;
  border-top-color: ${theme.colors.progressBarEmpty};
  padding: 10px;
  border-radius: 10px;
  background-color: ${(props) =>
    props.isActive
      ? props.theme.colors.primary || theme.colors.primary
      : theme.colors.none};
`;

const UserNameCol = styled.View`
  flex: 2;
  align-items: flex-start;
  justify-content: center;
  padding-right: 4px;
`;
const UserTierCol = styled.View`
  flex: 1;
  align-items: flex-start;
  justify-content: center;
`;

const AdminButton = styled.TouchableOpacity`
  border: solid;
  border-width: 1px;
  border-color: ${theme.colors.textPrimary};
  padding: 10px;
  border-radius: 20px;
  z-index: 1;
  min-width: 100px;
`;
const AdminCardText = styled.Text`
  font-family: MarkOffcPro;
  font-weight: 500;
  line-height: 18px;
  font-size: 14px;
  color: ${theme.colors.textPrimary};
  text-align: center;
`;

const AdminResetText = styled.Text`
  font-family: MarkOffcPro;
  font-weight: 700;
  line-height: 22px;
  font-size: 18px;
  color: ${theme.colors.textPrimary};
  text-align: center;
`;

AdminIndexScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired,
    goBack: PropTypes.func.isRequired
  }).isRequired
};

export default AdminIndexScreen;
