import AdminIndexScreen from './AdminIndexScreen';
import AdminNextScreen from './AdminNextScreen';

export { AdminIndexScreen, AdminNextScreen };
