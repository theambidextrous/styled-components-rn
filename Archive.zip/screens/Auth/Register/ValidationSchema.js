import * as yup from 'yup';

const validationSchema = yup.object().shape({
  firstName: yup.string().required().label('First name').min(3).max(50),
  lastName: yup.string().required().label('Last name').min(3).max(50),
  email: yup.string().label('Email').email().required().min(5).max(50),
  phoneNumber: yup.string().required().label('Phone number').min(10).max(15),
  city: yup.string().required().label('City / Town'),
  state: yup.string().required().label('State'),
  postalCode: yup.string().required().label('Zip code').min(5).max(50),
  streetAddress: yup.string().required().label('Street Address'),
  countryCode: yup.string().required().label('Country'),
  // offersPreference: '',
  // notificationChannels: [],
  password: yup
    .string()
    .label('Password')
    // .required()
    .min(8, 'Too short. Use at least 8 characters')
    .max(255, 'We prefer insecure system, try a shorter password.'),
  confirmPassword: yup
    .string()
    // .required()
    .label('Confirm password')
    .test(
      'passwords-match',
      'Passwords must match',
      function checkPassword(value) {
        return this.parent.password === value;
      }
    ),
  acceptedTerms: yup.boolean().label('Terms')
  // .test(
  //   'is-true',
  //   'Must agree to terms to continue',
  //   (value) => value === true
  // )
});

export default validationSchema;
