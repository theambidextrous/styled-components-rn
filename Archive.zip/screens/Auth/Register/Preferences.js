import React from 'react';
import PropTypes from 'prop-types';
import { SectionOffers, SectionText, SectionNotifications } from '@components';
import {
  StyledSafeAreaView,
  StyledScrollView,
  StyleText,
  StepperText,
  StyledComponentView
} from './styles';

const offers = [
  {
    title: 'Daily Summary',
    formikKey: 'daily'
  },
  {
    title: 'Weekly Summary',
    formikKey: 'weekly'
  },
  {
    title: 'Monthly Summary',
    formikKey: 'monthly'
  }
];

const notificationsPreferences = [
  {
    title: 'Email',
    formikKey: 'emailNotification'
  },
  {
    title: 'SMS',
    formikKey: 'smsNotification'
  },
  {
    title: 'In-App Notification',
    formikKey: 'inAppNotification'
  }
];

const Preferences = (props) => {
  const { currentStep, formikProps, push, remove } = props;
  if (currentStep !== 2) {
    return null;
  }
  return (
    <StyledSafeAreaView>
      <StyledScrollView showsVerticalScrollIndicator={false} bounces>
        <StyledComponentView>
          <StepperText>{`Step ${currentStep} / 3`}</StepperText>
          <StyleText>Set preferences</StyleText>

          <SectionText
            title="Offers"
            subTitle="How often do you want to receive offers"
          />
          {offers.map((offer) => {
            const { title, formikKey } = offer;
            return (
              <SectionOffers
                formikKey={formikKey}
                formikProps={formikProps}
                title={title}
                key={title}
              />
            );
          })}
          <SectionText
            title="Notifications"
            subTitle="Reminders of existing offers or ways to
earn more points"
          />
          <SectionNotifications
            formikKey="allNotifications"
            title="All"
            formikProps={formikProps}
            push={push}
            remove={remove}
          />
          {notificationsPreferences.map((notification) => {
            const { title, formikKey } = notification;
            return (
              <SectionNotifications
                formikKey={formikKey}
                title={title}
                formikProps={formikProps}
                push={push}
                remove={remove}
                key={title}
              />
            );
          })}
        </StyledComponentView>
      </StyledScrollView>
    </StyledSafeAreaView>
  );
};

Preferences.propTypes = {
  currentStep: PropTypes.number.isRequired,
  push: PropTypes.func.isRequired,
  remove: PropTypes.func.isRequired,
  formikProps: PropTypes.objectOf(PropTypes.any).isRequired
};

export default Preferences;
