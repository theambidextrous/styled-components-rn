import React, { useEffect, useLayoutEffect, useState } from 'react';
import { Alert, LogBox } from 'react-native';
import CustomStatusBar from '@components/CustomStatusBar';
import { ifIphoneX } from 'react-native-iphone-x-helper';
import {
  client,
  extractError,
  triggerSuccessHaptic,
  AppTracker
} from '@utils/index';
import { FieldArray, Formik } from 'formik';
import { PrimaryButton, ModalPopUp } from '@components';
import * as actions from '@stores/actions/index';
import {
  UserApi,
  UserRegistrationRequest
} from 'mastercard_loyalty_sandbox_api';
import PropTypes from 'prop-types';
import { useDispatch, useSelector } from 'react-redux';
import Preferences from './Preferences';
import SetPassword from './SetPassword';
import SignUpScreen from './SignUpScreen';
import {
  BackButton,
  ButtonContainer,
  ModalDetails,
  StyledSafeAreaView,
  StyledView
} from './styles';
import validationSchema from './ValidationSchema';

const MultiStepForm = ({ navigation }) => {
  const dispatcher = useDispatch();
  const appStoredState = useSelector((state) => state);
  const currentShop = appStoredState.multiStore;
  const [currentStep, setCurrentStep] = useState(1);
  const [visible, setVisible] = useState(false);
  const [sessionData, setSessionData] = useState({});
  const [formState, SetFormState] = useState({
    message: '',
    isLoading: false,
    currentShop
  });

  /** tracker */
  const apptracker = new AppTracker();

  useEffect(() => {
    LogBox.ignoreLogs(['VirtualizedLists should never be nested']);
    return () => {
      setVisible(false);
    };
  }, []);

  // Checks the current step on mount and hides the
  // back button if current step is on step 1
  useLayoutEffect(() => {
    const prev = () => {
      let current = currentStep;
      current = current <= 1 ? 1 : current - 1;
      setCurrentStep(current);
    };
    const previousButton = () => {
      const current = currentStep;
      if (current !== 1) {
        return <BackButton onPress={() => prev()} />;
      }
      return <BackButton onPress={() => navigation.goBack()} />;
    };
    navigation.setOptions({
      headerLeft: () => previousButton()
    });
  }, [navigation, currentStep]);

  const findTokenExpiryFromNow = (expiration) => {
    const seconds = Math.floor(Date.now() / 1000);
    return Number(seconds) + Number(expiration);
  };

  const HandleOnSignUp = (values) => {
    try {
      const TrimmedValues = JSON.parse(
        JSON.stringify(values).replace(/"\s+|\s+"/g, '"')
      );
      SetFormState({ isLoading: true });
      client.defaultHeaders = {};
      const apiInstance = new UserApi(client);
      apiInstance.userRegistration(
        UserRegistrationRequest.constructFromObject(
          TrimmedValues,
          TrimmedValues
        ),
        (error, data, response) => {
          SetFormState({ isLoading: false });
          if (response !== undefined && response.statusCode === 201) {
            /** new usersigned up, clear any existing user on device */
            dispatcher(actions.clearUserStore());
            dispatcher(actions.clearCart());
            dispatcher(actions.clearWishlist());
            dispatcher(actions.clearPointsStore());
            dispatcher(actions.clearCardsStore());
            dispatcher(actions.clearPreferenceStore());
            dispatcher(actions.clearDeviceToken());
            dispatcher(actions.clearDemoUsers());

            const { accessToken, refreshToken, expiresIn } = response.body;
            const sessionObj = {
              accessToken,
              refreshToken,
              expiresIn,
              expiresAt: findTokenExpiryFromNow(expiresIn),
              email: values.email,
              password: values.password
            };
            setVisible(true);
            setSessionData(sessionObj);
            apptracker.logNewUser(sessionObj.email);
            dispatcher(actions.storeSuperUserSession(sessionObj));
            dispatcher(actions.userRegistered(response.body, true));
            SetFormState({
              isLoading: false
            });
            triggerSuccessHaptic();
          } else {
            // some error occurred
            const errorData = extractError(error);
            SetFormState({
              isLoading: false,
              message: errorData.Details
            });
            apptracker.logSignedUpFailure(errorData.Details, values.email);
            Alert.alert('Oops, something went wrong', errorData.Details);
          }
        }
      );
    } catch (error) {
      SetFormState({
        isLoading: false,
        message: 'Unknown error occured'
      });
      apptracker.logSignedUpFailure(JSON.stringify(error), values.email);
      Alert.alert('Oops, something went wrong', String(error));
    }
  };

  // function to navigate to the next step
  const next = () => {
    let current = currentStep;
    current = current >= 2 ? 3 : current + 1;
    setCurrentStep(current);
  };

  const GoToLogin = () => {
    setVisible(false);
    if (sessionData.accessToken.length > 0) {
      dispatcher(actions.userSignedIn(sessionData, true));
      return;
    }
    navigation.navigate('SignInScreen');
  };

  return (
    <StyledSafeAreaView>
      <CustomStatusBar isLightContent />
      <>
        <StyledView>
          <ModalPopUp visible={visible}>
            <ModalDetails />
            <PrimaryButton title="Continue" onPress={GoToLogin} />
          </ModalPopUp>
          <Formik
            initialValues={{
              firstName: '',
              lastName: '',
              email: '',
              phoneNumber: '',
              city: '',
              state: '',
              postalCode: '',
              streetAddress: '',
              countryCode: '',
              offersPreference: '',
              daily: false,
              weekly: false,
              monthly: false,
              notificationChannels: [],
              allNotifications: false,
              emailNotification: false,
              smsNotification: false,
              inAppNotification: false,
              password: '',
              confirmPassword: '',
              acceptedTerms: false
            }}
            validationSchema={validationSchema}
            onSubmit={(values) => {
              if (currentStep === 3) {
                HandleOnSignUp(values);
              } else {
                next(values);
                SetFormState({ isLoading: false });
              }
            }}
          >
            {(formikProps) => (
              <>
                <SignUpScreen
                  currentStep={currentStep}
                  formikProps={formikProps}
                />

                <FieldArray name="notificationChannels">
                  {({ push, remove }) => (
                    <Preferences
                      currentStep={currentStep}
                      formikProps={formikProps}
                      push={push}
                      remove={remove}
                    />
                  )}
                </FieldArray>
                <SetPassword
                  currentStep={currentStep}
                  formikProps={formikProps}
                />
                <ButtonContainer
                  style={{
                    ...ifIphoneX(
                      {
                        marginBottom: 0
                      },
                      {
                        paddingBottom: 16
                      }
                    )
                  }}
                >
                  <PrimaryButton
                    title={currentStep > 2 ? 'Create an account' : 'Continue'}
                    onPress={formikProps.handleSubmit}
                    loading={formState.isLoading}
                    disabled={formState.isLoading}
                  />
                </ButtonContainer>
              </>
            )}
          </Formik>
        </StyledView>
      </>
    </StyledSafeAreaView>
  );
};

MultiStepForm.propTypes = {
  navigation: PropTypes.object.isRequired
};

export default MultiStepForm;
