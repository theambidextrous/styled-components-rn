import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Platform } from 'react-native';

import { TextInputs, KeyboardAdaptableView, DropDown } from '@components';
import { countries } from '@utils';
import {
  StyledComponentView,
  StateZipCodeContainer,
  StyleText,
  StepperText
} from './styles';

const SignUpScreen = (props) => {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState(countries);
  const [value, setValue] = useState(null);

  const { formikProps, currentStep } = props;
  if (currentStep !== 1) {
    return null;
  }

  return (
    <KeyboardAdaptableView>
      <StyledComponentView
        style={Platform.OS !== 'android' && { zIndex: 999999 }}
      >
        <StepperText>{`Step ${currentStep} / 3`}</StepperText>
        <StyleText>Fill out your personal information</StyleText>
        <TextInputs
          label="First name"
          placeholder="First name"
          // autoFocus
          formikProps={formikProps}
          formikKey="firstName"
        />
        <TextInputs
          label="Last name"
          placeholder="Last name"
          formikProps={formikProps}
          formikKey="lastName"
        />
        <TextInputs
          label="Email address"
          placeholder="Email address"
          formikProps={formikProps}
          autoCapitalize="none"
          formikKey="email"
        />
        <TextInputs
          label="Phone number"
          placeholder="Phone number"
          keyboardType="phone-pad"
          formikProps={formikProps}
          formikKey="phoneNumber"
        />

        <DropDown
          placeholder="Country"
          open={open}
          value={value}
          items={items}
          setOpen={setOpen}
          formikProps={formikProps}
          formikKey="countryCode"
          setValue={setValue}
          onChangeValue={(countryCode) => {
            formikProps.setFieldValue('countryCode', countryCode);
          }}
          setItems={setItems}
        />

        <TextInputs
          label="State"
          placeholder="State"
          formikProps={formikProps}
          formikKey="state"
        />
        <StateZipCodeContainer>
          <TextInputs
            label="City / Town"
            placeholder="City / Town"
            formikProps={formikProps}
            formikKey="city"
          />
          <TextInputs
            label="Zip code"
            placeholder="Zip code"
            formikProps={formikProps}
            keyboardType="phone-pad"
            formikKey="postalCode"
          />
        </StateZipCodeContainer>
        <TextInputs
          label="Street Address"
          placeholder="Street Address"
          formikProps={formikProps}
          formikKey="streetAddress"
        />
      </StyledComponentView>
    </KeyboardAdaptableView>
  );
};

SignUpScreen.propTypes = {
  currentStep: PropTypes.number.isRequired,
  formikProps: PropTypes.object.isRequired
};

export default SignUpScreen;
