import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { TextInputs, KeyboardAdaptableView, Checkbox } from '@components';
import { StyleText, StepperText } from './styles';

const SetPassword = (props) => {
  const { formikProps, currentStep } = props;
  if (currentStep !== 3) {
    return null;
  }

  return (
    <KeyboardAdaptableView>
      <StyledComponentView>
        <StepperText>{`Step ${currentStep} / 3`}</StepperText>
        <StyleText>Set password</StyleText>
        <TextInputs
          label="Password"
          placeholder="Enter password"
          autoFocus
          formikProps={formikProps}
          formikKey="password"
          secureTextEntry
        />
        <TextInputs
          label="Confirm password"
          placeholder="Re-enter password"
          formikProps={formikProps}
          formikKey="confirmPassword"
          secureTextEntry
        />
        <>
          <Checkbox
            disabled={false}
            title="By signing up you agree to our Terms and Conditions"
            label="Agree to Terms"
            formikKey="acceptedTerms"
            formikProps={formikProps}
            error={formikProps.errors.acceptedTerms}
          />
        </>
      </StyledComponentView>
    </KeyboardAdaptableView>
  );
};

SetPassword.propTypes = {
  currentStep: PropTypes.number.isRequired,
  formikProps: PropTypes.object.isRequired
};

export default SetPassword;

const StyledComponentView = styled.View`
  margin: 0 24px;
`;
