import React from 'react';
import { render, cleanup } from '@testing-library/react-native';
import Preferences from '../Preferences';
import SignUpScreen from '../SignUpScreen';
import SetPassword from '../SetPassword';

describe('Preferences', () => {
  afterEach(cleanup);
  it('should render correctly', () => {
    const { toJSON } = render(<Preferences />);
    expect(toJSON()).toMatchSnapshot();
  });
});

describe('SignUpScreen', () => {
  afterEach(cleanup);
  it('should render correctly', () => {
    const { toJSON } = render(<SignUpScreen />);
    expect(toJSON()).toMatchSnapshot();
  });
});

describe('SetPassword', () => {
  afterEach(cleanup);
  it('should render correctly', () => {
    const { toJSON } = render(<SetPassword />);
    expect(toJSON()).toMatchSnapshot();
  });
});
