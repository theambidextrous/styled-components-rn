import React from 'react';
import styled from 'styled-components/native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { TouchableOpacity, View, Platform } from 'react-native';
import { moderateScale } from 'react-native-size-matters';
import { theme } from '@utils';

const smileImage = require('@assets/images/others/smile.png');
const successImage = require('@assets/images/others/success.png');

export const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.backgroundColor};
`;

export const StyledScrollView = styled.ScrollView`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;

export const StyledView = styled.View`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;

export const StyledComponentView = styled.View`
  margin: 20px;
  flex-direction: column;
`;

export const StateZipCodeContainer = styled.View`
  flex-direction: row;
  justify-content: space-between;
`;

export const StyleText = styled.Text`
  color: ${theme.colors.textBlack};
  font-family: 'MarkOffcPro';
  font-size: ${moderateScale(16)}px;
  line-height: 19px;
  text-align: center;
  margin: 0 0 10px 0;
`;

export const StepperText = styled.Text`
  color: ${theme.colors.textBlack};
  font-family: 'MarkOffcPro';
  font-size: ${moderateScale(16)}px;
  line-height: 19px;
  text-align: center;
  margin: 15px 0;
`;

export const ButtonContainer = styled.View`
  padding: 20px 33px 0 33px;
  justify-content: flex-end;
  background-color: ${theme.colors.backgroundColor};
  margin-bottom: ${Platform.OS === 'android' ? 10 : 0}px;
`;

const StyledModalTitle = styled.Text`
  font-family: 'MontrealSerialBold';
  font-size: 30px;
  line-height: 36px;
  text-align: center;
  color: ${theme.colors.modalTextBlack};
  margin-bottom: 15px;
`;

const StyledModalSubTitle = styled.Text`
  font-family: 'Montreal';
  font-size: 18px;
  line-height: 21px;
  text-align: center;
  color: ${theme.colors.modalTextGrey};
  margin-bottom: 23px;
`;

const BorderLine = styled.View`
  border: 1px solid #f5f5f5;
`;

const ModalImage = styled.Image`
  height: 70px;
  width: 70px;
  align-self: center;
  margin: 23px 0;
`;

export const BackButton = ({ ...rest }) => (
  <TouchableOpacity
    activeOpacity={1}
    style={{ paddingHorizontal: 20 }}
    {...rest}
  >
    <View>
      <Icon
        name="arrow-back"
        size={24}
        style={{
          color: theme.colors.textWhite
        }}
      />
    </View>
  </TouchableOpacity>
);

export const ModalDetails = () => (
  <>
    <ModalImage source={successImage} />
    <StyledModalTitle>Congratulations</StyledModalTitle>
    <StyledModalSubTitle>
      Your account has successfully been created
    </StyledModalSubTitle>
    <BorderLine />
    <ModalImage source={smileImage} />
    <StyledModalSubTitle>
      You have earned 50 points For joining the loyalty program
    </StyledModalSubTitle>
  </>
);
