import React, { useState } from 'react';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import { Alert } from 'react-native';
import { Formik } from 'formik';
// import { useSelector } from 'react-redux';
import * as yup from 'yup';
// Mastercard SDK
import { OtpRequest, AuthorizationApi } from 'mastercard_loyalty_sandbox_api';

// Components
import { TextInputs, PrimaryButton, Text, Loader } from '@components';

// Utils
import { theme, AppTracker, client, extractError } from '@utils/';

const validationSchema = yup.object().shape({
  email: yup.string().label('Email').email().required().min(5).max(50)
});

const ResetPassword = ({ navigation }) => {
  // const appStoredState = useSelector((state) => state);
  // const currentShop = appStoredState.multiStore;

  const [loading, setLoading] = useState(false);
  const apptracker = new AppTracker();

  // check email
  const resetPasswordRequest = (values) => {
    setLoading(true);
    const api = new AuthorizationApi(client);
    const otpRequest = OtpRequest.constructFromObject(values);
    api.resetPassword(otpRequest, (error, data, response) => {
      if (response && response.statusCode < 205) {
        setLoading(false);
        const { id } = response.body;
        navigation.navigate('Verification', {
          itemId: id
        });
      } else if (response.statusCode === 500) {
        setLoading(false);
        apptracker.logForgotPasswordFailure('Reset password email failed', {
          errorCode: response.statusCode,
          errorMessage: String(error)
        });
        Alert.alert('Something went wrong', 'Please try again later.');
      } else {
        setLoading(false);
        const errorData = extractError(error);
        apptracker.logForgotPasswordFailure('Reset password email failed', {
          errorCode: response.statusCode,
          errorMessage: errorData.Details
        });
        Alert.alert('Something went wrong', errorData.Details);
      }
    });
  };
  return (
    <StyledSafeAreaView>
      <Loader loading={loading} />
      <Formik
        validationSchema={validationSchema}
        initialValues={{
          validateOnMount: true,
          email: ''
        }}
        onSubmit={(values) => resetPasswordRequest(values)}
      >
        {(formikProps) => (
          <>
            <StyledComponentView>
              <TextWrapper>
                <Text
                  style={{
                    color: theme.colors.black
                    // fontSize: 18
                  }}
                  as="P3"
                >
                  Please enter your registered email address
                </Text>
              </TextWrapper>
              <TextInputs
                label="Email"
                placeholder="Registered email address"
                formikProps={formikProps}
                autoFocus
                formikKey="email"
              />
              <ButtonContainer>
                <PrimaryButton
                  title="Continue"
                  onPress={formikProps.handleSubmit}
                  disabled={loading}
                />
              </ButtonContainer>
            </StyledComponentView>
          </>
        )}
      </Formik>
    </StyledSafeAreaView>
  );
};
const StyledComponentView = styled.View`
  flex: 1;
  padding: 20px;
  background-color: ${theme.colors.backgroundLight};
`;

const ButtonContainer = styled.View`
  width: 100%;
  margin-top: 16px;
`;
const TextWrapper = styled.View`
  margin-bottom: 16px;
  margin-top: 16px;
`;
const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;

ResetPassword.propTypes = {
  navigation: PropTypes.object.isRequired
};

export default ResetPassword;
