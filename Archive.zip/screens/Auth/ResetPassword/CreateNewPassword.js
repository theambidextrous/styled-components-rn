import React, { useState } from 'react';
import styled from 'styled-components/native';
import { Alert } from 'react-native';
import PropTypes from 'prop-types';

import { useDispatch } from 'react-redux';
import { Formik } from 'formik';
import * as yup from 'yup';

// Actions
import * as actions from '@stores/actions/index';

// Mastercard SDK
import {
  ResetPasswordRequest,
  AuthorizationApi
} from 'mastercard_loyalty_sandbox_api';

// Components
import {
  TextInputs,
  Text,
  PrimaryButton,
  Loader,
  ModalPopUp
} from '@components';

// Utils
import { theme, AppTracker, client, extractError } from '@utils/';

// Images
const successImage = require('@assets/images/others/success.png');

const validationSchema = yup.object().shape({
  password: yup
    .string()
    .label('Password')
    // .required()
    .min(8, 'Too short. Use at least 8 characters')
    .max(255, 'We prefer insecure system, try a shorter password.'),
  confirmPassword: yup
    .string()
    // .required()
    .label('Confirm password')
    .test(
      'passwords-match',
      'Passwords must match',
      function checkPassword(value) {
        return this.parent.password === value;
      }
    )
});
const ChangePassword = ({ route, navigation }) => {
  const apptracker = new AppTracker();
  const { itemId } = route.params;
  const dispatcher = useDispatch();

  // const appStoredState = useSelector((state) => state);
  // const currentShop = appStoredState.multiStore;

  const [loading, setLoading] = useState(false);
  const [visible, setVisible] = useState(false);
  const [sessionData, setSessionData] = useState({});

  const findTokenExpiryFromNow = (expiration) => {
    const seconds = Math.floor(Date.now() / 1000);
    return Number(seconds) + Number(expiration);
  };

  // change password request
  const changePasswordRequest = (values) => {
    setLoading(true);
    const api = new AuthorizationApi(client);
    const id = itemId;
    const resetPasswordRequest =
      ResetPasswordRequest.constructFromObject(values);
    api.createNewPassword(id, resetPasswordRequest, (error, data, response) => {
      if (response && response.statusCode < 205) {
        setLoading(false);
        const { accessToken, refreshToken, expiresIn } = response.body;
        const sessionObj = {
          accessToken,
          refreshToken,
          expiresIn,
          expiresAt: findTokenExpiryFromNow(expiresIn),
          password: values.password
        };
        setVisible(true);
        setSessionData(sessionObj);
      } else if (response.statusCode === 500) {
        setLoading(false);
        apptracker.logForgotPasswordFailure('Create new password failed', {
          errorCode: response.statusCode,
          errorMessage: String(error)
        });
        Alert.alert('Something went wrong', 'Please try again later.');
      } else {
        setLoading(false);
        const errorData = extractError(error);
        apptracker.logForgotPasswordFailure('Create new password failed', {
          errorCode: response.statusCode,
          errorMessage: errorData.Details
        });
        Alert.alert('Something went wrong', errorData.Details);
      }
    });
  };

  const goToHome = () => {
    setVisible(false);
    if (sessionData.accessToken.length > 0) {
      dispatcher(actions.userSignedIn(sessionData, true));
      return;
    }
    navigation.navigate('SignInScreen');
  };

  return (
    <StyledSafeAreaView>
      <Loader loading={loading} />
      <ModalPopUp visible={visible}>
        <ModalDetails />
        <PrimaryButton title="Continue" onPress={goToHome} />
      </ModalPopUp>
      <Formik
        validationSchema={validationSchema}
        initialValues={{
          validateOnMount: true,
          password: '',
          confirmPassword: ''
        }}
        onSubmit={(values) => changePasswordRequest(values)}
      >
        {(formikProps) => (
          <>
            <StyledComponentView>
              <TextWrapper>
                <Text
                  style={{
                    color: theme.colors.black
                    // fontSize: 18
                  }}
                  as="P3"
                >
                  Set a new password
                </Text>
              </TextWrapper>
              <TextInputs
                label="Title"
                placeholder="Enter password"
                autoFocus
                formikProps={formikProps}
                formikKey="password"
                secureTextEntry
              />
              <TextInputs
                label="Title"
                placeholder="Re-enter password"
                formikProps={formikProps}
                formikKey="confirmPassword"
                secureTextEntry
              />
              <ButtonContainer>
                <PrimaryButton
                  title="Save New Password"
                  onPress={formikProps.handleSubmit}
                  disabled={loading}
                />
              </ButtonContainer>
            </StyledComponentView>
          </>
        )}
      </Formik>
    </StyledSafeAreaView>
  );
};
const StyledComponentView = styled.View`
  flex: 1;
  padding: 20px;
  background-color: ${theme.colors.backgroundLight};
`;

export const ButtonContainer = styled.View`
  width: 100%;
  margin-top: 16px;
`;
const TextWrapper = styled.View`
  margin-bottom: 16px;
  margin-top: 16px;
`;

const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.backgroundColor};
`;

const ModalContainer = styled.View`
  align-items: center;
  justify-content: center;
`;
const ModalImage = styled.Image`
  height: 70px;
  width: 70px;
  align-self: center;
  margin: 23px 0;
`;

const StyledModalTitle = styled.Text`
  font-family: 'MarkOffcPro-Bold';
  font-size: 30px;
  line-height: 36px;
  text-align: center;
  color: ${theme.colors.modalTextBlack};
  margin-bottom: 15px;
`;

const StyledModalSubTitle = styled.Text`
  font-family: 'MarkOffcPro';
  font-size: 18px;
  line-height: 21px;
  text-align: center;
  color: ${theme.colors.modalTextBlack};
  align-items: center;
  margin-bottom: 23px;
`;

const ModalDetails = () => (
  <ModalContainer>
    <ModalImage source={successImage} />
    <StyledModalTitle>Success</StyledModalTitle>
    <StyledModalSubTitle>
      Your password has been changed successfully.
    </StyledModalSubTitle>
  </ModalContainer>
);

ChangePassword.propTypes = {
  navigation: PropTypes.object.isRequired,
  route: PropTypes.object.isRequired
};
export default ChangePassword;
