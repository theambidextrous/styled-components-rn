import React, { useState } from 'react';
import styled from 'styled-components/native';
import { StyleSheet, Alert, ActivityIndicator } from 'react-native';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import Icon from 'react-native-vector-icons/MaterialIcons';
import PropTypes from 'prop-types';

// Mastercard SDK
import {
  OtpVerificationRequest,
  AuthorizationApi
} from 'mastercard_loyalty_sandbox_api';

// Utils
import { theme, DEVICE_WIDTH, extractError, client, AppTracker } from '@utils/';

// Components
import { PrimaryButton, Text } from '@components';

const Verification = ({ route, navigation }) => {
  const apptracker = new AppTracker();
  const [loading, setLoading] = useState(false);
  const [code, setCode] = useState('');
  const { itemId } = route.params;

  const otpRequest = (verificationCode) => {
    if (verificationCode) {
      setLoading(true);
      const api = new AuthorizationApi(client);
      const verificationId = itemId;
      const otpVerificationRequest = OtpVerificationRequest.constructFromObject(
        {
          otp: verificationCode
        }
      );
      api.confirmOtp(
        verificationId,
        otpVerificationRequest,
        (error, data, response) => {
          if (response && response.statusCode < 205) {
            const { id } = response.body;
            navigation.navigate('CreateNewPassword', {
              itemId: id
            });
          } else if (response.statusCode === 500) {
            setLoading(false);
            apptracker.logForgotPasswordFailure('Verification OTP failed', {
              errorCode: response.statusCode,
              errorMessage: String(error)
            });
          } else {
            setLoading(false);
            const errorData = extractError(error);
            apptracker.logForgotPasswordFailure('Verification OTP failed', {
              errorCode: response.statusCode,
              errorMessage: errorData.Details
            });
            Alert.alert('Something went wrong', errorData.Details);
          }
        }
      );
    }
  };

  return (
    <StyledSafeAreaView>
      <StyledComponentView>
        <ContentWrapper>
          <IconWrapper>
            <Icon
              name="lock-outline"
              size={52}
              color={theme.colors.textBlack}
            />
          </IconWrapper>

          <Text style={styles.headerText} as="H2">
            Verification
          </Text>
          <Text style={styles.descriptionText} as="P2">
            Enter the OTP code sent to your email
          </Text>
          <OTPInputView
            keyboardAppearance="light"
            keyboardType="number-pad"
            style={{ width: '100%', height: 150 }}
            pinCount={4}
            autoFocusOnLoad
            codeInputFieldStyle={styles.underlineStyleBase}
            codeInputHighlightStyle={styles.underlineStyleHighLighted}
            onCodeFilled={(verificationCode) => setCode(verificationCode)}
          />
          <ButtonContainer>
            {loading ? (
              <ActivityIndicator size="small" color={theme.colors.black} />
            ) : (
              <PrimaryButton
                title="Continue"
                disabled={code.length !== 4}
                onPress={() => otpRequest(code)}
              />
            )}
          </ButtonContainer>
        </ContentWrapper>
      </StyledComponentView>
    </StyledSafeAreaView>
  );
};
const StyledComponentView = styled.View`
  flex: 1;
  padding: 20px;
  background-color: ${theme.colors.backgroundLight};
`;

export const ButtonContainer = styled.View`
  width: 100%;
`;

const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;
const ContentWrapper = styled.View`
  align-items: center;
`;

const IconWrapper = styled.View`
  margin: 32px 0 16px 0;
`;

const styles = StyleSheet.create({
  borderStyleBase: {
    width: 30,
    height: 45
  },

  borderStyleHighLighted: {
    borderColor: theme.colors.primary
  },

  underlineStyleBase: {
    borderWidth: 0,
    fontSize: 18,
    borderRadius: 5,
    width: 60,
    height: 50,
    backgroundColor: theme.colors.backgroundColor,
    color: theme.colors.black
  },
  headerText: {
    textAlign: 'center',
    width: DEVICE_WIDTH * 0.7,
    marginBottom: 16
  },
  descriptionText: {
    textAlign: 'center',
    width: DEVICE_WIDTH * 0.7,
    fontWeight: '400'
  },
  underlineStyleHighLighted: {
    borderColor: theme.colors.primary
  }
});

Verification.propTypes = {
  navigation: PropTypes.object.isRequired,
  route: PropTypes.object.isRequired
};

export default Verification;
