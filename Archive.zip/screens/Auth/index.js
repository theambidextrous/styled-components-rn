import Login from './Login/Login';
import MultiStepForm from './Register/MultiStepForm';
import ResetPassword from './ResetPassword/ResetPassword';
import CreateNewPassword from './ResetPassword/CreateNewPassword';
import Verification from './ResetPassword/Verification';

export { Login, MultiStepForm, ResetPassword, CreateNewPassword, Verification };
