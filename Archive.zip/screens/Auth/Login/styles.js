import styled from 'styled-components/native';
import theme from '@utils/theme';
import { Platform } from 'react-native';

const CreateAccountTextStyles = `
font-family: 'MarkOffcPro-Bold';
font-size: 13px;
line-height: 15px;
text-align: center;
color: ${theme.colors.textWhite};
`;

export const TextInputStyledObj = {
  fontFamily: 'MarkOffcPro',
  height: 50,
  backgroundColor: theme.colors.backgroundLight,
  fontSize: 15,
  lineHeight: 18
};

export const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
`;

export const StyledView = styled.View`
  flex: 1;
  flex-direction: column;
  justify-content: center;
  margin-top: 40px;
  padding: 20px;
`;

export const StyledImage = styled.Image`
  width: 230px;
  height: 200px;
  align-self: center;
  margin-bottom: 40px;
`;

export const StyledBiometricsImage = styled.Image`
  width: 48px;
  height: 48px;
  align-self: center;
`;

export const ForgotPasswordText = styled.Text`
  font-family: 'MarkOffcPro';
  font-size: 16px;
  line-height: 22px;
  margin: 15px 0;
  text-align: center;
  color: ${theme.colors.textWhite};
`;

export const BiometricContainer = styled.View`
  flex-direction: row;
  margin: 35px 0;
  align-items: center;
  justify-content: center;
`;

export const CreatAccountContainer = styled.TouchableOpacity`
  flex-direction: row;
  justify-content: flex-end;
  align-self: center;
  padding-bottom: ${Platform.OS === 'ios' ? '0px' : '20px'};
`;

export const NoAccountAccountText = styled.Text`
  ${CreateAccountTextStyles}
`;

export const CreateAccountText = styled.Text`
  ${CreateAccountTextStyles};
  color: ${(props) => props.theme.colors.primary || theme.colors.primary};
  text-decoration: underline;
  text-decoration-color: ${(props) =>
    props.theme.colors.primary || theme.colors.primary};
  text-decoration-style: solid;
`;

export const ForgotPasswordButton = styled.TouchableOpacity``;
