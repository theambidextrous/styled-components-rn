/** eslint-disable no-unused-vars */
import React, { useState } from 'react';
import FastImage from 'react-native-fast-image';
import CustomStatusBar from '@components/CustomStatusBar';
import { Alert, TouchableOpacity, StyleSheet, View } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import PropTypes from 'prop-types';
import { PrimaryButton, TextInputs } from '@components';
import { Formik } from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import * as actions from '@stores/actions';
import {
  AuthorizationApi,
  UserLoginRequest
} from 'mastercard_loyalty_sandbox_api';

// utils
import {
  client,
  extractError,
  authenticateBiometrics,
  theme,
  AppTracker
} from '@utils/index';

// styles
import {
  StyledSafeAreaView,
  StyledView,
  ForgotPasswordText,
  StyledImage,
  CreatAccountContainer,
  CreateAccountText,
  NoAccountAccountText,
  TextInputStyledObj,
  StyledBiometricsImage,
  BiometricContainer,
  ForgotPasswordButton
} from './styles';

// images
const logo = require('@assets/images/logo/logo_light.png');
const backgroundImage = require('@assets/images/tutorial/screen1.jpg');
const faceIDImage = require('@assets/images/others/faceID.png');
const touchIDImage = require('@assets/images/others/touchID.png');

function Login({ navigation }) {
  const dispatcher = useDispatch();
  const appStoredState = useSelector((state) => state);
  const currentShop = appStoredState.multiStore;
  const persistedAuthState = appStoredState.authentication;
  const { biometricsAuthData } = persistedAuthState;
  const [formState, SetFormState] = useState({
    email: '',
    password: '',
    message: '',
    isLoading: false,
    currentShop
  });
  /** tracker */
  const apptracker = new AppTracker();

  const { themeImages } = currentShop;
  const darkLogo = themeImages.find((img) => img.name === 'darkLogo');
  const screenBackgroundImage = themeImages.find(
    (img) => img.name === 'screenBackgroundImage'
  );
  const findTokenExpiryFromNow = (expiration) => {
    const seconds = Math.floor(Date.now() / 1000);
    return Number(seconds) + Number(expiration);
  };

  const HandleOnSignIn = (values) => {
    SetFormState({ isLoading: true });
    const apiInstance = new AuthorizationApi(client);
    client.defaultHeaders = {};
    apiInstance.authorizationsPost(
      UserLoginRequest.constructFromObject(values),
      (error, data, response) => {
        if (error || Number(response.statusCode) > 204) {
          const errorData = extractError(error);
          SetFormState({
            ...formState,
            isLoading: false,
            message: errorData.Details
          });
          apptracker.logSignInFailure(errorData.Details, values.email);
          Alert.alert('Login Error', errorData.Details);
        } else {
          // console.log('response', response);
          const sessionData = {
            accessToken: data.accessToken,
            refreshToken: data.refreshToken,
            expiresIn: data.expiresIn,
            expiresAt: findTokenExpiryFromNow(data.expiresIn),
            email: values.email,
            password: values.password
          };
          dispatcher(actions.storeSuperUserSession(sessionData));
          SetFormState({
            ...formState,
            isLoading: false,
            email: values.email,
            password: values.password
          });
          dispatcher(actions.userSignedIn(sessionData, true));
        }
      }
    );
  };

  const BiometricsState = (status, message) => {
    if (status) {
      SetFormState({ isLoading: true });
      HandleOnSignIn({
        email: biometricsAuthData.email,
        password: biometricsAuthData.password
      });
    } else {
      apptracker.logSignInFailure(
        message,
        `${biometricsAuthData.email}: Biometrics login`
      );
      Alert.alert('Biometric Error', message);
    }
  };

  const HandleOnBiometricSignIn = () => {
    authenticateBiometrics(BiometricsState);
  };

  return (
    <FastImage
      style={{ flex: 1 }}
      source={
        screenBackgroundImage === undefined
          ? backgroundImage
          : {
              uri: `data:image/jpeg;base64,${screenBackgroundImage.image}`
            }
      }
      resizeMode="stretch"
    >
      <View
        style={[
          StyleSheet.absoluteFill,
          {
            backgroundColor: 'rgba(0, 0, 0, 0.3)'
          }
        ]}
      />
      <StyledSafeAreaView>
        <CustomStatusBar isLightContent />
        <KeyboardAwareScrollView>
          <StyledView>
            <StyledImage
              resizeMode="stretch"
              source={
                darkLogo === undefined
                  ? logo
                  : {
                      uri: `data:image/jpeg;base64,${darkLogo.image}`
                    }
              }
            />
            <Formik
              initialValues={{
                email: '',
                password: ''
              }}
              onSubmit={async (values) => {
                await HandleOnSignIn(values);
              }}
            >
              {(formikProps) => (
                <>
                  <TextInputs
                    style={TextInputStyledObj}
                    label="Email address"
                    placeholder="email@address.com"
                    placeholderTextColor={theme.colors.textGrey}
                    formikProps={formikProps}
                    autoCapitalize="none"
                    formikKey="email"
                  />
                  <TextInputs
                    style={TextInputStyledObj}
                    label="Password"
                    placeholderTextColor={theme.colors.textGrey}
                    placeholder="password"
                    autoCapitalize="none"
                    formikProps={formikProps}
                    formikKey="password"
                    secureTextEntry
                  />
                  <PrimaryButton
                    style={{ height: 50 }}
                    title="Login"
                    loading={formState.isLoading}
                    onPress={formikProps.handleSubmit}
                  />
                  <ForgotPasswordButton
                    onPress={() => navigation.push('ResetPassword')}
                  >
                    <ForgotPasswordText>Forgot password?</ForgotPasswordText>
                  </ForgotPasswordButton>
                  <BiometricContainer>
                    {persistedAuthState.hasFaceUnlock && (
                      <TouchableOpacity
                        onPress={() => HandleOnBiometricSignIn()}
                      >
                        <StyledBiometricsImage source={faceIDImage} />
                      </TouchableOpacity>
                    )}
                    {persistedAuthState.hasFingerUnlock && (
                      <TouchableOpacity
                        onPress={() => HandleOnBiometricSignIn()}
                      >
                        <StyledBiometricsImage source={touchIDImage} />
                      </TouchableOpacity>
                    )}
                  </BiometricContainer>
                </>
              )}
            </Formik>
          </StyledView>
        </KeyboardAwareScrollView>
        <CreatAccountContainer
          onPress={() => navigation.navigate('SignUpScreen')}
        >
          <NoAccountAccountText>Don’t have an account? </NoAccountAccountText>
          <CreateAccountText>Create one.</CreateAccountText>
        </CreatAccountContainer>
      </StyledSafeAreaView>
    </FastImage>
  );
}

Login.propTypes = {
  navigation: PropTypes.object.isRequired
};

export default Login;
