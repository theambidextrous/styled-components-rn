import React from 'react';
import { View, Platform } from 'react-native';
import styled from 'styled-components/native';
import {
  CustomBtnTextIconWraper,
  CustomButtonText,
  CustomButton,
  CustomStatusBar
} from '@components';
import Icon from 'react-native-vector-icons/FontAwesome';
import { theme, DEVICE_HEIGHT } from '@utils/index';
import PropTypes from 'prop-types';

const logo = require('@assets/images/logo/logo_light@x1.png');
const backgroundImage = require('@assets/images/tutorial/screen1.jpg');

const IntroScreen = ({ navigation }) => {
  const BtnIcon = ({ size, color }) => (
    <Icon
      name="long-arrow-right"
      color={color}
      size={size}
      style={{
        marginHorizontal: 15
      }}
    />
  );
  BtnIcon.propTypes = {
    size: PropTypes.number.isRequired,
    color: PropTypes.string
  };
  BtnIcon.defaultProps = {
    color: theme.colors.textWhite
  };
  const SignUpComponentText = () => (
    <CustomBtnTextIconWraper>
      <CustomButtonText label="Sign Up" isFilled />
      <BtnIcon size={25} />
    </CustomBtnTextIconWraper>
  );
  const ExploreComponentText = () => (
    <CustomBtnTextIconWraper>
      <CustomButtonText label="Lets Explore" isFilled isLight />
      <BtnIcon color={theme.colors.black} size={25} />
    </CustomBtnTextIconWraper>
  );
  return (
    <StyledImageBackground
      defaultSource={backgroundImage}
      source={backgroundImage}
      resizeMode="stretch"
    >
      <StyledSafeAreaView>
        <CustomStatusBar isLightContent />
        <StyledView>
          <LoginButton onPress={() => navigation.navigate('SignInScreen')}>
            <StyledLoginText style={{ fontWeight: 'bold' }}>
              Log in
            </StyledLoginText>
          </LoginButton>
          <StyledTopView>
            <View>
              <StyledImage resizeMode="contain" source={logo} />
            </View>
          </StyledTopView>
          <StyledMiddleView>
            <StyledCircle>
              <StyledPointsTextHed>GET</StyledPointsTextHed>
              <StyledPointsText>50</StyledPointsText>
              <StyledPointsTextSm>POINTS</StyledPointsTextSm>
            </StyledCircle>
            <View style={{ marginTop: 40 }}>
              <StyledSignUpPointsText>
                Get 50 points, for joining the loyalty program
              </StyledSignUpPointsText>
            </View>
          </StyledMiddleView>
          <StyledBottomView>
            <View>
              <View style={{ marginBottom: 15 }}>
                <CustomButton
                  labelComponent={<SignUpComponentText />}
                  isFilled
                  isSkip={false}
                  onPress={() => navigation.navigate('SignUpScreen')}
                />
              </View>
              <CustomButton
                labelComponent={<ExploreComponentText />}
                isFilled={true}
                isLight
                isSkip
                onPress={() => navigation.navigate('AppMiniTutorialScreen')}
              />
            </View>
          </StyledBottomView>
        </StyledView>
      </StyledSafeAreaView>
    </StyledImageBackground>
  );
};

IntroScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};
const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
`;
const StyledTopView = styled.View`
  /* justify-content: center; */
  /* flex: 2; */
`;
const StyledMiddleView = styled.View`
  /* flex: 4; */
  justify-content: center;
  align-items: center;
`;
const StyledBottomView = styled.View`
  flex: 1;
  justify-content: flex-end;
  padding-bottom: 12px;
`;
const StyledView = styled.View`
  flex: 1;
`;
const StyledCircle = styled.View`
  width: 200px;
  height: 200px;
  border-radius: 250px;
  background-color: ${theme.colors.textWhite};
  justify-content: center;
  align-items: center;
  border-width: 6px;
  border-color: ${theme.colors.primary};
`;
const StyledPointsText = styled.Text`
  font-size: 100px;
  font-weight: 900;
  color: ${theme.colors.black};
  font-family: 'MarkOffcPro-Bold';
`;

const StyledPointsTextHed = styled.Text`
  font-size: 24px;
  font-weight: 900;
  margin-bottom: -20px;
  color: ${theme.colors.black};
  font-family: 'MarkOffcPro-Bold';
`;
const StyledPointsTextSm = styled.Text`
  font-size: 16px;
  font-weight: 900;
  color: ${theme.colors.black};
  margin-top: -10px;
  font-family: 'MarkOffcPro-Bold';
`;
const StyledSignUpPointsText = styled.Text`
  font-size: 18px;
  font-weight: 400;
  width: 280px;
  color: ${theme.colors.textWhite};
  margin-top: -20px;
  text-align: center;
  font-family: 'MarkOffcPro';
`;
const StyledImageBackground = styled.ImageBackground`
  width: 100%;
  height: 100%;
`;

const LoginButton = styled.TouchableOpacity`
  margin-left: auto;
  margin-right: 20px;
  background-color: ${theme.colors.textWhite};
  align-items: center;
  justify-content: center;
  border-radius: 22px;
  top: ${Platform.OS === 'android'
    ? DEVICE_HEIGHT * 0.06
    : DEVICE_HEIGHT * 0.02}px;
`;

const StyledLoginText = styled.Text`
  font-size: 16px;
  font-weight: 600;
  color: ${theme.colors.black};
  line-height: 24px;
  font-family: 'MarkOffcPro';
  justify-content: center;
  align-items: center;
  padding: 6px 12px;
`;
const StyledImage = styled.Image`
  width: 200px;
  height: 200px;
  align-self: center;
`;
export default IntroScreen;
