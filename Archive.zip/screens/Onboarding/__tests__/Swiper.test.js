import * as React from 'react';
import { Provider } from 'react-redux';
import { render } from '@testing-library/react-native';
import renderer from 'react-test-renderer';
import { store } from '@stores';
import Swiper from '@screens/Onboarding/Swiper';

describe('Swiper components tests', () => {
  test('Swiper generally renders correctly', () => {
    const component = (
      <Provider store={store}>
        <Swiper />
      </Provider>
    );
    const tree = renderer.create(component).toJSON();
    expect(tree).toMatchSnapshot();
  });

  it('explore and skip buttons renderering', () => {
    const component = (
      <Provider store={store}>
        <Swiper />
      </Provider>
    );
    const { getByText } = render(component);
    const exploreButton = getByText('Lets Explore');
    const skipButton = getByText('Skip');
    expect(exploreButton).toBeTruthy();
    expect(skipButton).toBeTruthy();
  });
});
