import * as React from 'react';
import { View, TouchableOpacity, Text, TextInput } from 'react-native';
import { cleanup, render, fireEvent } from '@testing-library/react-native';

afterEach(cleanup);

test('change text fire event', () => {
  const onChangeTextMock = jest.fn();
  const CHANGE_TEXT = '';

  const { getByPlaceholderText } = render(
    <View>
      <TextInput placeholder="Enter data" onChangeText={onChangeTextMock} />
    </View>
  );

  fireEvent.changeText(getByPlaceholderText('Enter data'), CHANGE_TEXT);
  expect(onChangeTextMock).not.toBeNull();
});

test('onPress fire event', () => {
  const onPressMock = jest.fn();

  const { getByText } = render(
    <View>
      <TouchableOpacity onPress={onPressMock}>
        <Text>Press me</Text>
      </TouchableOpacity>
    </View>
  );
  fireEvent.press(getByText('Press me'));
  expect(onPressMock).toHaveBeenCalled();
});
