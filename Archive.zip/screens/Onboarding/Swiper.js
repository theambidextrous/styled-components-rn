import React from 'react';
import styled from 'styled-components/native';
import Onboarding from 'react-native-onboarding-swiper';
import { ScrollView, View, Dimensions } from 'react-native';
import {
  SwiperNextButton,
  SwiperSkipButton,
  SwiperDoneButton,
  SwiperImage,
  SwiperTitle,
  SwiperContent,
  SwiperButtonIcon,
  SwiperTextIconWraper,
  SwiperButtonText,
  DotsComponent
} from '@components';
import { theme } from '@utils';
import PropTypes from 'prop-types';

const offersCanvas = require('@assets/images/tutorial/screen2.png');
const earnPointsCanvas = require('@assets/images/tutorial/screen3.png');
const pointsCanvas = require('@assets/images/tutorial/screen4.png');

const tutorialPages = [
  {
    backgroundColor: theme.colors.none,
    image: <SwiperImage source={offersCanvas} />,
    title: <SwiperTitle title="Offers" />,
    subtitle: (
      <SwiperContent content="Get relevant offers and rewards for purchases made both instore or online with the merchant." />
    )
  },
  {
    backgroundColor: theme.colors.none,
    image: <SwiperImage source={earnPointsCanvas} />,
    title: <SwiperTitle title="Earn Points" />,
    subtitle: (
      <SwiperContent content="Earn points for both purchase and non-purchase activity with the merchant and use the points towards their future purchases." />
    )
  },
  {
    backgroundColor: theme.colors.none,
    image: <SwiperImage source={pointsCanvas} />,
    title: <SwiperTitle title="Points" />,
    subtitle: (
      <SwiperContent content="Accumulate points and move across tiers to leverage different feature offerings." />
    )
  }
];
const NextIcon = () => (
  <SwiperButtonIcon
    name="long-arrow-right"
    size={25}
    style={{
      marginHorizontal: 15
    }}
  />
);
const NextComponentText = () => (
  <SwiperTextIconWraper>
    <SwiperButtonText label="Lets Explore" isFilled />
    <NextIcon />
  </SwiperTextIconWraper>
);
const DoneComponentText = () => <SwiperButtonText label="Continue" isFilled />;

const SkipComponentText = () => (
  <SwiperButtonText label="Skip" isFilled={false} />
);
const NextComponent = ({ nextLabel, isLight, ...props }) => (
  <SwiperNextButton
    nextLabel={nextLabel}
    nextLabelComponent={<NextComponentText />}
    isFilled
    isSkip={false}
    {...props}
  />
);
NextComponent.propTypes = {
  nextLabel: PropTypes.string.isRequired,
  isLight: PropTypes.bool.isRequired
};
const SkipComponent = ({ skipLabel, isLight, ...props }) => (
  <SwiperSkipButton
    skipLabel={skipLabel}
    skipLabelComponent={<SkipComponentText />}
    isFilled={false}
    isSkip
    {...props}
  />
);
SkipComponent.propTypes = {
  skipLabel: PropTypes.string.isRequired,
  isLight: PropTypes.bool.isRequired
};
const DoneComponent = ({ isLight, ...props }) => (
  <SwiperDoneButton labelComponent={<DoneComponentText />} {...props} />
);
DoneComponent.propTypes = {
  isLight: PropTypes.bool.isRequired
};

const Swiper = ({ navigation }) => (
  <StyledSafeAreaView>
    <View>
      <ScrollView showsVerticalScrollIndicator={false}>
        <Onboarding
          containerStyles={{
            maxHeight: Dimensions.get('screen').height * 0.65
          }}
          pages={tutorialPages}
          controlStatusBar={false}
          NextButtonComponent={NextComponent}
          SkipButtonComponent={SkipComponent}
          DoneButtonComponent={DoneComponent}
          DotComponent={DotsComponent}
          imageContainerStyles={{
            paddingBottom: 30
          }}
          bottomBarHighlight={false}
          bottomBarHeight={180}
          onSkip={() => navigation.navigate('SignUpScreen')}
          onDone={() => {
            navigation.navigate('SignUpScreen');
            // dispatcher(actions.appLoaded(true));
          }}
        />
      </ScrollView>
    </View>
  </StyledSafeAreaView>
);
Swiper.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};

const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
`;

export default Swiper;
