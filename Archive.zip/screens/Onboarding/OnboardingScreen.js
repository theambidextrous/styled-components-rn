import React from 'react';
import { theme } from '@utils';
import styled from 'styled-components/native';
import Swiper from '@screens/Onboarding/Swiper';
import CustomStatusBar from '@components/CustomStatusBar';
import PropTypes from 'prop-types';

const OnboardingScreen = ({ navigation }) => (
  <StyledSafeAreaView>
    <CustomStatusBar isLightContent />
    <StyledView>
      <Swiper navigation={navigation} />
    </StyledView>
  </StyledSafeAreaView>
);
OnboardingScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired
  }).isRequired
};
const StyledView = styled.View`
  flex: 1;
`;
const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.textWhite};
`;
export default OnboardingScreen;
