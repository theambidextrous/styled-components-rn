import React, { useLayoutEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';
// Mastercard sdk
import {
  AccountApplicationRequest,
  UserApi
} from 'mastercard_loyalty_sandbox_api';
// components
import {
  Loader,
  ModalPopUp,
  PrimaryButton,
  TriggerLocalNotification
} from '@components';

// utils
import {
  client,
  extractError,
  RefreshAuthToken,
  triggerSuccessHaptic,
  triggerImpactLightHaptic,
  getTierColor,
  AppTracker
} from '@utils/index';

import FinancialInformationScreen from './FinancialInformation';
import PersonalInformationScreen from './PersonalInformation';
import {
  BackButton,
  ModalDetails,
  StyledSafeAreaView,
  StyledView
} from './styles';

const CoBrandForm = ({ navigation }) => {
  /**  tracker */
  const apptracker = new AppTracker();

  const appState = useSelector((state) => state);
  const authState = appState.authentication;
  const userState = appState.authentication;
  const {
    email,
    city,
    firstName,
    lastName,
    phoneNumber,
    streetAddress,
    countryCode,
    postalCode,
    state,
    tierName
  } = userState.user;
  const { accessToken, refreshToken, expiresAt } = authState.session;
  const [currentStep, setCurrentStep] = useState(1);
  const [visible, setVisible] = useState(false);
  const [formState, SetFormState] = useState(false);
  const [data, setData] = useState({
    firstName,
    lastName,
    email,
    phoneNumber,
    city,
    state,
    postalCode,
    streetAddress,
    countryCode,
    totalIncome: null,
    accountType: 'SAVINGS',
    securityAnswer: '',
    dob: '',
    idNumber: '',
    acceptedTerms: false
  });

  useLayoutEffect(() => {
    const prev = () => {
      let current = currentStep;
      current = current <= 1 ? 1 : current - 1;
      setCurrentStep(current);
    };
    const previousButton = () => {
      const current = currentStep;
      if (current === 2) {
        return (
          <BackButton color={getTierColor(tierName)} onPress={() => prev()} />
        );
      }
      return (
        <BackButton
          color={getTierColor(tierName)}
          onPress={() => navigation.goBack()}
        />
      );
    };
    navigation.setOptions({
      headerLeft: () => previousButton()
    });
  }, [navigation, currentStep, tierName]);

  const handleApplicationRequest = async (values) => {
    SetFormState(true);
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const api = new UserApi(client);
    const accountApplicationRequest =
      AccountApplicationRequest.constructFromObject(values, values);
    // console.log('values', values);
    api.accountApplication(
      accountApplicationRequest,
      (error, resData, response) => {
        if (response && response.statusCode < 205) {
          SetFormState(false);
          triggerSuccessHaptic();
          setVisible(true);
        } else if (response.statusCode === 500) {
          apptracker.logCardsFailure('Apply cobrand failure', {
            errorCode: response.statusCode,
            errorMessage: String(error)
          });
          SetFormState(false);
          TriggerLocalNotification({
            message: "We're sorry, but something went wrong, PLease try again.",
            type: 'error',
            icon: 'info'
          });
        } else {
          SetFormState(false);
          const errorData = extractError(error);
          apptracker.logCardsFailure('Apply cobrand failure', {
            errorCode: response.statusCode,
            errorMessage: errorData.Details
          });
          TriggerLocalNotification({
            message: errorData.Details,
            type: 'error',
            icon: 'warning'
          });
        }
      }
    );
  };

  const handleNextStep = (newData, final = false) => {
    triggerImpactLightHaptic();
    setData((prev) => ({ ...prev, ...newData }));

    if (final) {
      triggerImpactLightHaptic();
      handleApplicationRequest(newData);
      return;
    }

    setCurrentStep((prev) => prev + 1);
  };

  const GoToCoBrandScreen = () => {
    setVisible(false);
    navigation.navigate('CobrandCards');
  };

  return (
    <StyledSafeAreaView>
      <Loader loading={formState} description="Processing..." />
      <ModalPopUp visible={visible}>
        <ModalDetails />
        <PrimaryButton title="Done" onPress={GoToCoBrandScreen} />
      </ModalPopUp>
      <StyledView>
        <PersonalInformationScreen
          currentStep={currentStep}
          data={data}
          next={handleNextStep}
        />
        <FinancialInformationScreen
          currentStep={currentStep}
          data={data}
          next={handleNextStep}
        />
      </StyledView>
    </StyledSafeAreaView>
  );
};

CoBrandForm.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired,
    goBack: PropTypes.func.isRequired,
    setOptions: PropTypes.func.isRequired
  }).isRequired
};

export default CoBrandForm;
