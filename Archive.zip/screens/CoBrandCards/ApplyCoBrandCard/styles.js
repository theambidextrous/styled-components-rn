import { Platform, TouchableOpacity, View } from 'react-native';
import PropTypes from 'prop-types';

import Icon from 'react-native-vector-icons/MaterialIcons';
import React from 'react';
import { moderateScale } from 'react-native-size-matters';
import styled from 'styled-components/native';
import { theme } from '@utils';

const successImage = require('@assets/images/others/success.png');

export const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.backgroundColor};
`;
export const StyledView = styled.View`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;

export const StyledComponentView = styled.View`
  flex: 1;
  margin: 20px;
  flex-direction: column;
`;

export const StateZipCodeContainer = styled.View`
  flex-direction: row;
  justify-content: space-between;
`;

export const StyleText = styled.Text`
  color: ${theme.colors.textBlack};
  font-family: 'MarkOffcPro';
  font-size: ${moderateScale(16)}px;
  line-height: 19px;
  text-align: center;
  margin-bottom: 20px;
`;

export const StepperWrapper = styled.View`
  justify-content: center;
  align-items: center;
`;

export const StepperText = styled.Text`
  color: ${theme.colors.textBlack};
  font-family: 'MarkOffcPro';
  font-size: ${moderateScale(16)}px;
  line-height: 19px;
  font-weight: 400;
  text-align: center;
  margin: 15px 0;
`;

export const ButtonContainer = styled.View`
  /* flex: 2; */
  padding: 20px 20px 0px 20px;
  background-color: ${theme.colors.backgroundColor};
  justify-content: flex-end;
  margin-bottom: ${Platform.OS === 'android' ? 10 : 0}px;
`;

const StyledModalTitle = styled.Text`
  font-family: 'Montserrat';
  font-size: 30px;
  line-height: 36px;
  text-align: center;
  color: ${theme.colors.modalTextBlack};
  margin-bottom: 15px;
`;

const StyledModalSubTitle = styled.Text`
  font-family: 'MarkOffcPro';
  font-size: 18px;
  line-height: 21px;
  text-align: center;
  color: ${theme.colors.modalTextBlack};
  align-items: center;
  margin-bottom: 23px;
`;

const ModalContainer = styled.View`
  align-items: center;
  justify-content: center;
`;
const ModalImage = styled.Image`
  height: 70px;
  width: 70px;
  align-self: center;
  margin: 23px 0;
`;

export const BackButton = ({ color, ...rest }) => (
  <TouchableOpacity
    activeOpacity={1}
    style={{ paddingHorizontal: 20 }}
    {...rest}
  >
    <View>
      <Icon
        name="arrow-back"
        size={24}
        style={{
          color: color || theme.colors.textWhite
        }}
      />
    </View>
  </TouchableOpacity>
);

export const ModalDetails = () => (
  <ModalContainer>
    <ModalImage source={successImage} />
    <StyledModalTitle>Congratulations</StyledModalTitle>
    <StyledModalSubTitle>
      You are approved. Your physical card is in the mail.
    </StyledModalSubTitle>
  </ModalContainer>
);
BackButton.propTypes = {
  color: PropTypes.string.isRequired
};
