import * as yup from 'yup';

const PersonallValidationSchema = yup.object().shape({
  firstName: yup.string().required().label('First name').min(3).max(50),
  lastName: yup.string().required().label('Last name').min(3).max(50),
  email: yup.string().label('Email').email().required().min(5).max(50),
  phoneNumber: yup.string().required().label('Phone number').min(10).max(15),
  city: yup.string().required().label('City / Town'),
  state: yup.string().required().label('State'),
  postalCode: yup.string().required().label('Zip code').min(5).max(50),
  streetAddress: yup.string().required().label('Street Address'),
  countryCode: yup.string().required().label('Country'),
  dob: yup.string().required().label('Date of Birth').nullable()
});

const FinacialValidationSchema = yup.object().shape({
  totalIncome: yup.string().required().label('Total annual income').nullable(),
  accountType: yup.string().required().label('Account Type'),
  securityAnswer: yup.string().required().label('Mothers Maiden Name').min(5),
  idNumber: yup
    .string()
    .required()
    .label('Social Security Number')
    .min(9)
    .max(11),
  acceptedTerms: yup
    .boolean()
    .label('Terms')
    .test(
      'is-true',
      'Please agree to our terms to continue',
      (value) => value === true
    )
});
export { PersonallValidationSchema, FinacialValidationSchema };
