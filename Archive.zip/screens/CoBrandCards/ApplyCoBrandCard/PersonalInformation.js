import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Formik } from 'formik';
import { Platform, Dimensions } from 'react-native';
import { ifIphoneX } from 'react-native-iphone-x-helper';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import { DropDown, TextInputs, DateTime, PrimaryButton } from '@components';
import { countries } from '@utils';
import { PersonallValidationSchema } from './ValidationSchema';

import {
  StateZipCodeContainer,
  ButtonContainer,
  StepperText,
  StyledComponentView,
  StyleText,
  StepperWrapper
} from './styles';

const PersonalInformationScreen = (props) => {
  const { data, currentStep, next } = props;
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState(countries);
  const [value, setValue] = useState(data.countryCode);

  if (currentStep !== 1) {
    return null;
  }

  const handleSubmit = (values) => {
    next(values);
  };

  return (
    <>
      <Formik
        validationSchema={PersonallValidationSchema}
        initialValues={data}
        onSubmit={handleSubmit}
      >
        {(formikProps) => (
          <>
            <StyledComponentView
              style={Platform.OS !== 'android' && { zIndex: 999999 }}
            >
              <KeyboardAwareScrollView
                resetScrollToCoords={{ x: 0, y: 0 }}
                style={{ height: Dimensions.get('window').height }}
                automaticallyAdjustContentInsets={false}
                showsVerticalScrollIndicator={false}
              >
                <StepperWrapper>
                  <StepperText>{`Step ${currentStep} / 2`}</StepperText>
                  <StyleText>Fill out your personal information</StyleText>
                </StepperWrapper>
                <TextInputs
                  label="First name"
                  placeholder="First name"
                  // autoFocus
                  formikProps={formikProps}
                  formikKey="firstName"
                />
                <TextInputs
                  label="Last name"
                  placeholder="Last name"
                  formikProps={formikProps}
                  formikKey="lastName"
                />
                <TextInputs
                  label="Email address"
                  placeholder="Email address"
                  formikProps={formikProps}
                  autoCapitalize="none"
                  formikKey="email"
                />
                <TextInputs
                  label="Phone number"
                  placeholder="Phone number"
                  keyboardType="phone-pad"
                  formikProps={formikProps}
                  formikKey="phoneNumber"
                />

                <DropDown
                  placeholder="Country"
                  open={open}
                  value={value}
                  items={items}
                  setOpen={setOpen}
                  formikProps={formikProps}
                  formikKey="countryCode"
                  setValue={setValue}
                  onChangeValue={(countryCode) => {
                    formikProps.setFieldValue('countryCode', countryCode);
                  }}
                  setItems={setItems}
                />

                <TextInputs
                  label="State"
                  placeholder="State"
                  formikProps={formikProps}
                  formikKey="state"
                />
                <StateZipCodeContainer>
                  <TextInputs
                    label="City / Town"
                    placeholder="City / Town"
                    formikProps={formikProps}
                    formikKey="city"
                  />
                  <TextInputs
                    label="Zip code"
                    placeholder="Zip code"
                    formikProps={formikProps}
                    keyboardType="phone-pad"
                    formikKey="postalCode"
                  />
                </StateZipCodeContainer>
                <TextInputs
                  label="Street Address"
                  placeholder="Street Address"
                  formikProps={formikProps}
                  formikKey="streetAddress"
                />
                <DateTime
                  defualtDate="1985-01-01"
                  formikProps={formikProps}
                  formikKey="dob"
                  onDateChange={(val) => {
                    if (val !== null) {
                      formikProps.setFieldValue('dob', val);
                    }
                  }}
                />
              </KeyboardAwareScrollView>
            </StyledComponentView>
            <ButtonContainer
              style={{
                ...ifIphoneX(
                  {
                    marginBottom: 0
                  },
                  {
                    marginBottom: 16
                  }
                )
              }}
            >
              <PrimaryButton
                title={currentStep === 2 ? 'Confirmation' : 'Continue'}
                onPress={formikProps.handleSubmit}
              />
            </ButtonContainer>
          </>
        )}
      </Formik>
    </>
  );
};

PersonalInformationScreen.propTypes = {
  currentStep: PropTypes.number.isRequired,
  next: PropTypes.func.isRequired,
  data: PropTypes.object.isRequired
};

export default PersonalInformationScreen;
