import React from 'react';
import { Platform, View } from 'react-native';
import { Formik } from 'formik';
import PropTypes from 'prop-types';
import { ifIphoneX } from 'react-native-iphone-x-helper';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import {
  Checkbox,
  TextInputs,
  MaskTextInput,
  PrimaryButton
} from '@components';
import { FinacialValidationSchema } from './ValidationSchema';

import {
  StepperText,
  StepperWrapper,
  StyledComponentView,
  ButtonContainer,
  StyleText
} from './styles';

const FinancialInformationScreen = (props) => {
  const { currentStep, data, next } = props;
  if (currentStep !== 2) {
    return null;
  }
  const handleSubmit = (values) => {
    next(values, true);
  };

  return (
    <>
      <Formik
        validationSchema={FinacialValidationSchema}
        initialValues={data}
        onSubmit={handleSubmit}
      >
        {(formikProps) => (
          <>
            <StyledComponentView
              style={Platform.OS !== 'android' && { zIndex: 999999 }}
            >
              <KeyboardAwareScrollView automaticallyAdjustContentInsets={false}>
                <StepperWrapper>
                  <StepperText>{`Step ${currentStep} / 2`}</StepperText>
                  <StyleText>Financial Information</StyleText>
                </StepperWrapper>
                <MaskTextInput
                  label="Total annual income"
                  placeholder="Total annual income"
                  formikProps={formikProps}
                  onChangeText={(val) => {
                    formikProps.setFieldValue(
                      'totalIncome',
                      val.replace(/[^0-9]/g, '')
                    );
                  }}
                  type="money"
                  options={{
                    precision: 0,
                    separator: ',',
                    delimiter: ',',
                    unit: '$',
                    suffixUnit: ''
                  }}
                  formikKey="totalIncome"
                  keyboardType="numeric"
                />
                <StyleText style={{ marginTop: 42 }}>
                  Security information
                </StyleText>
                <TextInputs
                  label="Mothers Maiden Name"
                  placeholder="Mothers Maiden Name"
                  formikProps={formikProps}
                  formikKey="securityAnswer"
                />
                <MaskTextInput
                  label="Social Security Number"
                  placeholder="Social Security Number"
                  formikProps={formikProps}
                  formikKey="idNumber"
                  type="custom"
                  options={{
                    mask: '999-99-9999'
                  }}
                  keyboardType="numeric"
                />
                <View style={{ marginTop: 42 }}>
                  <Checkbox
                    disabled={false}
                    title="By signing up you agree to our Terms and Conditions"
                    label="Agree to Terms"
                    formikKey="acceptedTerms"
                    formikProps={formikProps}
                    error={formikProps.errors.acceptedTerms}
                  />
                </View>
              </KeyboardAwareScrollView>
            </StyledComponentView>
            <ButtonContainer
              style={{
                ...ifIphoneX(
                  {
                    marginBottom: 0
                  },
                  {
                    marginBottom: 16
                  }
                )
              }}
            >
              <PrimaryButton
                title={currentStep === 2 ? 'Confirmation' : 'Continue'}
                onPress={formikProps.handleSubmit}
              />
            </ButtonContainer>
          </>
        )}
      </Formik>
    </>
  );
};

FinancialInformationScreen.propTypes = {
  currentStep: PropTypes.number.isRequired,
  next: PropTypes.func.isRequired,
  data: PropTypes.object.isRequired
};

export default FinancialInformationScreen;
