import React from 'react';
import { Platform } from 'react-native';
import { PrimaryButton, Text } from '@components';

import FastImage from 'react-native-fast-image';
import PropTypes from 'prop-types';
import { ifIphoneX } from 'react-native-iphone-x-helper';

import styled from 'styled-components/native';
import { theme, triggerImpactLightHaptic } from '@utils/';

// images
const cobrandImage = require('@assets/images/others/cobrand.png');

const introData = [
  {
    title:
      'Personalized Card linked Offers from both participating merchant and other merchants'
  },
  {
    title: 'Option to pay for redemptions using previously accumulated points'
  },
  {
    title: 'Mastercard benefits associated with the cobrand card '
  }
];

const StyledSafeArea = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.backgroundColor};
`;

const Container = styled.ScrollView`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;

const headerTexStyle = {
  textAlign: 'center',
  marginBottom: 34,
  paddingHorizontal: 38,
  alignItems: 'center',
  justifyContent: 'center'
};

const introTexStyle = {
  textAlign: 'left',
  marginBottom: 34,
  paddingHorizontal: 24,
  marginRight: 34
};

const CardContainer = styled.View`
  flex-direction: row;
  padding-left: 23px;
  align-items: flex-start;
`;

const BulletPill = styled.View`
  width: 35px;
  height: 35px;
  border-radius: 35px;
  align-items: center;
  justify-content: center;
  background-color: ${theme.colors.black};
`;

const CardWrapper = styled.View`
  flex-direction: column;
`;

const ButtonContainer = styled.View`
  padding: 20px 33px 0 33px;
  justify-content: flex-end;
  margin-bottom: ${Platform.OS === 'android' ? 10 : 0}px;
`;

const CobrandImage = styled(FastImage)`
  justify-content: center;
  align-items: center;
  height: 263px;
  margin-top: 36px;
  margin-bottom: 34px;
`;

const IntroScreen = ({ navigation }) => (
  <StyledSafeArea>
    <Container>
      <CobrandImage
        source={cobrandImage}
        resizeMode={FastImage.resizeMode.contain}
      />
      <Text as="P2" style={headerTexStyle}>
        By signing up for cobrand cards, users will get access to additional
        product offerings and services such as:
      </Text>
      {introData.map((d, i) => (
        <CardContainer key={i}>
          <BulletPill>
            <Text style={{ color: theme.colors.textWhite }} as="P3">
              {String(i + 1)}
            </Text>
          </BulletPill>
          <CardWrapper>
            <Text as="P2" style={introTexStyle}>
              {d.title}
            </Text>
          </CardWrapper>
        </CardContainer>
      ))}
    </Container>
    <ButtonContainer
      style={{
        ...ifIphoneX(
          {
            marginBottom: 0
          },
          {
            marginBottom: 16
          }
        )
      }}
    >
      <PrimaryButton
        onPress={() => {
          triggerImpactLightHaptic();
          navigation.push('AddCoBrandCard');
        }}
      >
        Apply Now
      </PrimaryButton>
    </ButtonContainer>
  </StyledSafeArea>
);

IntroScreen.propTypes = {
  navigation: PropTypes.object.isRequired
};

export default IntroScreen;
