import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { Keyboard, KeyboardAvoidingView, Platform } from 'react-native';
import { TextInputs, MaskTextInput } from '@components';
import { theme } from '@utils/';

const StyledComponentView = styled.View`
  flex: 1;
  padding: 20px;
  background-color: ${theme.colors.backgroundLight};
`;
const ValidityContainer = styled.View`
  flex-direction: ${(props) => (props.layout === 'column' ? 'row' : 'column')};
  justify-content: space-between;
`;
const PickerWrap = styled.View`
  flex: ${(props) => (props.layout === 'column' ? 1 : 'none')};
  margin-right: 3px;
  z-index: 99999;
`;
const YearWrap = styled.View`
  flex: ${(props) => (props.layout === 'column' ? 1 : 'none')};
  z-index: 1;
`;
const AddCardForm = ({ formikProps, layout }) => {
  const OnMonthInput = (value) => {
    const monthVal = Number.parseInt(value, 10);
    if (Number.isNaN(monthVal)) {
      return '';
    }
    if (monthVal && monthVal < 10) {
      return `0${String(monthVal)}`;
    }
    if (monthVal > 12) {
      return '12';
    }
    return String(monthVal);
  };

  return (
    <KeyboardAvoidingView onTouchStart={Keyboard.dismiss} style={{ flex: 1 }}>
      <StyledComponentView style={Platform.OS === 'ios' && { zIndex: 999999 }}>
        <MaskTextInput
          label="Card Number"
          placeholder="Card Number"
          formikProps={formikProps}
          type="credit-card"
          options={{
            obfuscated: false
          }}
          formikKey="pan"
          keyboardType="numeric"
        />
        <TextInputs
          label="Cardholder Name"
          placeholder="Cardholder Name"
          formikProps={formikProps}
          formikKey="name"
        />
        <ValidityContainer layout={layout}>
          <PickerWrap layout={layout}>
            <MaskTextInput
              label="Expiry Month"
              placeholder="Expiry Month"
              formikProps={formikProps}
              formikKey="expiryMonth"
              type="custom"
              options={{
                mask: '999'
              }}
              keyboardType="numeric"
              maxLength={3}
              onChangeText={(masked) => {
                const month = OnMonthInput(masked);
                formikProps.setFieldValue('expiryMonth', month);
              }}
            />
          </PickerWrap>
          <YearWrap layout={layout}>
            <TextInputs
              label="Expiry Year"
              placeholder="Expiry Year"
              formikProps={formikProps}
              keyboardType="number-pad"
              maxLength={4}
              formikKey="expiryYear"
            />
          </YearWrap>
        </ValidityContainer>
      </StyledComponentView>
    </KeyboardAvoidingView>
  );
};
AddCardForm.propTypes = {
  formikProps: PropTypes.object.isRequired,
  layout: PropTypes.string
};

AddCardForm.defaultProps = {
  layout: 'column'
};

export default AddCardForm;
