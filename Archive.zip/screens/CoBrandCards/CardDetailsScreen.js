import React, { useState } from 'react';
import { Switch, StyleSheet, Platform, Alert, ScrollView } from 'react-native';
import styled from 'styled-components/native';
import { useTheme } from 'styled-components';
import { useSelector, useDispatch } from 'react-redux';
import { OffersApi, PreferencesRequest } from 'mastercard_loyalty_sandbox_api';
import * as actions from '@stores/actions';
import {
  theme,
  RefreshAuthToken,
  extractError,
  client,
  AppTracker
} from '@utils/index';
import { CreditCard, LoadingIndicator } from '@components/index';

import CardTransactions from './CardTransactions';

const CardDetailsScreen = () => {
  // theme
  const shopTheme = useTheme();
  /**  tracker */
  const apptracker = new AppTracker();
  /** state  */
  const dispatch = useDispatch();
  const appState = useSelector((state) => state);
  const authState = appState.authentication;
  const { accessToken, refreshToken, expiresAt } = authState.session;
  const { openCard } = appState.cards;
  const currentCard = openCard;
  const defaultRedemptionFrequency = currentCard.redemptionFrequency;

  /** preference */
  const [preference, SetPreference] = useState(defaultRedemptionFrequency);
  const [switchIsDisabled, SetDisabled] = useState(false);
  const [loading, SetLoading] = useState(false);

  const SwitchTheme = {
    false: theme.colors.grey,
    true: shopTheme.colors.primary || theme.colors.primary
  };

  const UpdatePreference = async (Pref) => {
    SetDisabled(true); /** disabled switch */
    SetLoading(true);
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const api = new OffersApi(client);
    const preferenceRequest = PreferencesRequest.constructFromObject({
      accountId: currentCard.mrsId,
      redemptionFrequency: Pref
    });
    api.setPreferences(
      preferenceRequest,
      { authorization: `Bearer ${newTkn.accessToken}` },
      (error, data, response) => {
        if (response && response.statusCode < 205) {
          const { redemptionFrequency } = response.body;
          dispatch(actions.setUserPwrPreference(redemptionFrequency));
          SetDisabled(false);
          SetPreference(redemptionFrequency);
          SetLoading(false);
        } else {
          const errorData = extractError(error);
          apptracker.logCardsFailure('Card preference failure', {
            errorCode: response.statusCode,
            errorMessage: errorData.Details
          });
          SetLoading(false);
          SetDisabled(false);
          Alert.alert('Oops, something went wrong', errorData.Details);
        }
      }
    );
  };

  const SwitchPreferenceAll = () => {
    const nextState = preference === 'OFF' ? 'MULT' : 'OFF';
    UpdatePreference(nextState);
    SetPreference(nextState);
  };
  const SwitchPreferenceNext = () => {
    const nextState = preference === 'MULT' ? 'SNGL' : 'MULT';
    UpdatePreference(nextState);
    SetPreference(nextState);
  };

  return (
    <StyledSafeAreaView>
      <ScrollView>
        <HeaderSection>
          <CardWrapper>
            <CreditCard
              card={currentCard}
              isCoBrand={currentCard.isCoBrand}
              OnCardPressed={() => null}
              pointsBalance={0}
            />
          </CardWrapper>
        </HeaderSection>
        {/* Will uncomment once they are in use */}
        {/* <CardActionsSection>
          <CardActionItem
            iconName="credit-card-settings-outline"
            isMd
            label="Add to mobile wallet"
            width={90}
          />
          <CardActionItem
            iconName="gift-outline"
            isMd
            label="Personalized Offers"
            width={80}
          />
          <CardActionItem
            iconName="bars"
            isMd={false}
            label="Card Details"
            width={60}
          />
        </CardActionsSection> */}
        <CardAPreferenceSection>
          <PrefSwitchWrapper>
            <PrefSwitchColumn flex={3}>
              <SectionRow>
                <PwrSwitchLabel>Pay with rewards</PwrSwitchLabel>
                {loading && (
                  <PreloadWrapper>
                    <LoadingIndicator />
                  </PreloadWrapper>
                )}
              </SectionRow>
            </PrefSwitchColumn>
            <PrefSwitchColumn flex={1} pullRight>
              <Switch
                disabled={switchIsDisabled}
                trackColor={SwitchTheme}
                thumbColor={SwitchTheme.false}
                onValueChange={SwitchPreferenceAll}
                value={preference !== 'OFF'}
                style={Jsx.switchTransform}
              />
            </PrefSwitchColumn>
          </PrefSwitchWrapper>
          {preference !== 'OFF' && (
            <PrefSwitchWrapper>
              <PrefSwitchColumn flex={3}>
                <PwrSwitchLabel>Only use for the next purchase</PwrSwitchLabel>
              </PrefSwitchColumn>
              <PrefSwitchColumn flex={1} pullRight>
                <Switch
                  disabled={switchIsDisabled}
                  trackColor={SwitchTheme}
                  thumbColor={SwitchTheme.false}
                  onValueChange={SwitchPreferenceNext}
                  value={preference === 'SNGL'}
                  style={Jsx.switchTransform}
                />
              </PrefSwitchColumn>
            </PrefSwitchWrapper>
          )}
        </CardAPreferenceSection>
        <TransactionContainer>
          <CardTransactions accountId={currentCard.mrsId} />
        </TransactionContainer>
      </ScrollView>
    </StyledSafeAreaView>
  );
};

const Jsx = StyleSheet.create({
  switchTransform: {
    transform: [
      { scaleX: Platform.OS === 'ios' ? 0.9 : 1.1 },
      { scaleY: Platform.OS === 'ios' ? 0.9 : 1.1 }
    ]
  }
});
const StyledSafeAreaView = styled.SafeAreaView`
  background-color: ${theme.colors.backgroundLight};
`;
const TransactionContainer = styled.View``;

const HeaderSection = styled.View`
  background-color: ${theme.colors.backgroundLight};
  padding: 24px 10px 12px 10px;
  flex-direction: row;
`;

// const CardActionsSection = styled.View`
//   background-color: ${theme.colors.backgroundLight};
//   padding: 0px 21px 15px 20px;
//   flex-direction: row;
//   border-bottom-width: 1px;
//   border-bottom-color: ${theme.colors.lightGrey};
// `;

const CardAPreferenceSection = styled.View`
  background-color: ${theme.colors.backgroundLight};
  padding: 12px 20px;
  border-bottom-width: 1px;
  border-bottom-color: ${theme.colors.lightGrey};
  align-items: center;
`;

const PrefSwitchWrapper = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: 2px 0px;
`;

const PrefSwitchColumn = styled.View`
  flex: ${(props) => props.flex};
  align-items: ${(props) => (props.pullRight ? 'flex-end' : 'flex-start')};
`;

const CardWrapper = styled.View`
  width: 100%;
`;

const PreloadWrapper = styled.View`
  position: absolute;
  left: 55%;
`;
const SectionRow = styled.View`
  flex-direction: row;
  align-items: center;
`;

const PwrSwitchLabel = styled.Text`
  font-family: Montserrat-SemiBold;
  text-align: left;
  letter-spacing: 0.2px;
  text-transform: uppercase;
  font-size: 13px;
  line-height: 15px;
`;
export default CardDetailsScreen;
