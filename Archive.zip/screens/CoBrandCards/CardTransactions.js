import {
  Loader,
  ModalContent,
  ModalPopUp,
  PrimaryButton,
  Text,
  TransactionDetailsRow,
  TriggerLocalNotification
} from '@components';
import {
  client,
  DEVICE_HEIGHT,
  extractError,
  money,
  RefreshAuthToken,
  SERVICE_ERROR_MESSAGE,
  theme,
  AppTracker
} from '@utils/index';
// Mastercard SDK
import {
  OffersApi,
  RedemptionsApi,
  RedeemPointsRequest
} from 'mastercard_loyalty_sandbox_api';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList } from 'react-native';
import { useSelector } from 'react-redux';
import styled from 'styled-components/native';

const successImage = require('@assets/images/others/success.png');

const CardTransactions = ({ accountId }) => {
  /**  tracker */
  const apptracker = new AppTracker();

  const appState = useSelector((state) => state);
  const authState = appState.authentication;
  const { accessToken, refreshToken, expiresAt } = authState.session;
  const [listTransactions, setTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [loading, SetRedeemLoading] = useState(false);
  const [visible, setVisible] = useState(false);
  const [redeemProperties, setProperties] = useState({
    showModal: false,
    redemptionPoints: null,
    cashBackAmount: '',
    paymentAuthId: ''
  });

  useEffect(() => {
    getCardTransactions();
  }, []);
  const getCardTransactions = async () => {
    setIsLoading(true);
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const fromDate = '2021-01-01';
    const toDate = '2050-12-01'; // change this to a dynamic date like fromNow()
    const includeReprocessed = true;
    const api = new OffersApi(client);
    api.listTransactions(
      accountId,
      fromDate,
      toDate,
      includeReprocessed,
      { authorization: `Bearer ${newTkn.accessToken}` },
      (error, data, response) => {
        if (response !== undefined && response.statusCode < 205) {
          setTransactions(response.body);
          setIsLoading(false);
        } else {
          setIsLoading(false);
          const errorData = extractError(error);
          apptracker.logCardsFailure('Card transactions failure', {
            errorCode: response.statusCode,
            errorMessage: errorData.Details
          });
          setIsLoading(false);
          TriggerLocalNotification({
            message: errorData.Details,
            type: 'info',
            icon: 'warning'
          });
        }
      }
    );
  };

  const handleRedeemPoints = async () => {
    setProperties({
      showModal: false
    });
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const api = new RedemptionsApi(client);
    const { redemptionPoints, cashBackAmount, paymentAuthId } =
      redeemProperties;
    const redeemPointsRequest = RedeemPointsRequest.constructFromObject({
      accountId,
      redemptionPoints,
      cashBackAmount,
      paymentAuthId
    });
    api.redeemPoints(redeemPointsRequest, (error, data, response) => {
      // console.log('response', response);
      if (response && response.statusCode < 205) {
        setProperties({
          showModal: false
        });
        getCardTransactions();
        SetRedeemLoading(false);
        setVisible(true);
      } else if (response.statusCode === 500) {
        setProperties({
          showModal: false
        });
        SetRedeemLoading(false);
        TriggerLocalNotification({
          message: SERVICE_ERROR_MESSAGE,
          type: 'error',
          icon: 'error'
        });
      } else if (response.statusCode === 400) {
        setProperties({
          showModal: false
        });
        SetRedeemLoading(false);
        TriggerLocalNotification({
          message: SERVICE_ERROR_MESSAGE,
          type: 'error',
          icon: 'warning'
        });
      } else {
        const errorData = extractError(error);
        setProperties({
          showModal: false
        });
        SetRedeemLoading(false);
        TriggerLocalNotification({
          message: errorData.Details,
          type: 'error',
          icon: 'warning'
        });
      }
    });
  };

  return (
    <Container>
      <Loader loading={loading} />
      <ModalPopUp visible={visible}>
        <ModalDetails message="You have redeemed your points." />
        <PrimaryButton title="Done" onPress={() => setVisible(false)} />
      </ModalPopUp>
      <ModalPopUp visible={redeemProperties.showModal}>
        <ModalContent
          hideImage
          title="Redeem"
          message={`Do you want to redeem ${
            redeemProperties.redemptionPoints
          } points for your ${money(
            redeemProperties.de006CardholderBillingAmount
          )} in ${redeemProperties.de043CardAcceptorNameLocation} `}
        />
        <PrimaryButton
          title="Redeem"
          onPress={() => {
            handleRedeemPoints();
            SetRedeemLoading(true);
          }}
        />
        <OutlineButton
          onPress={() =>
            setProperties({
              showModal: false
            })
          }
        >
          <Text style={outlineButtinStyle}>No, Thanks</Text>
        </OutlineButton>
      </ModalPopUp>
      <HeaderSection>
        <Text as="H4" style={headerTextStyle}>
          Recent Transactions
        </Text>
      </HeaderSection>
      {listTransactions.transactions &&
        listTransactions.transactions.length === 0 &&
        !isLoading && (
          <TransactionEmptyState>
            <Text as="H4" style={headerTextStyle}>
              No available Transactions
            </Text>
          </TransactionEmptyState>
        )}
      {isLoading ? (
        <LoadingWrapper>
          <ActivityIndicator size="small" />
        </LoadingWrapper>
      ) : (
        <FlatList
          nestedScrollEnabled
          data={listTransactions.transactions}
          keyExtractor={(item) => item.id}
          renderItem={(itemData) => {
            const { item } = itemData;
            const dateWithYear = item.de013TransactionDate;
            const dateWithoutYear = dateWithYear.split(',')[0];
            return (
              <TransactionDetailsRow
                key={item.id}
                merchant={item.de043CardAcceptorNameLocation}
                date={dateWithoutYear}
                amount={item.de006CardholderBillingAmount}
                responseReasonId={item.responseReasonId}
                loading={redeemProperties.loading}
                pointsRedeemed={item.pointsRedeemed}
                handleRedeemPoints={() =>
                  setProperties({
                    showModal: true,
                    cashBackAmount: item.cashBackAmount,
                    paymentAuthId: item.id,
                    redemptionPoints: item.totalPointsRequired,
                    de006CardholderBillingAmount:
                      item.de006CardholderBillingAmount,
                    de043CardAcceptorNameLocation:
                      item.de043CardAcceptorNameLocation
                  })
                }
              />
            );
          }}
        />
      )}
    </Container>
  );
};

CardTransactions.propTypes = {
  accountId: PropTypes.string.isRequired
};

const Container = styled.View`
  background-color: ${theme.colors.backgroundLight};
  min-height: ${DEVICE_HEIGHT / 2}px;
`;

const HeaderSection = styled.View`
  flex-direction: row;
  background-color: ${theme.colors.backgroundLight};
`;

const LoadingWrapper = styled.View`
  margin-top: 25px; ;
`;

const TransactionEmptyState = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
`;

const OutlineButton = styled.TouchableOpacity`
  background-color: ${theme.colors.backgroundLight};
  color: ${theme.colors.primary};
  margin-top: 15px;
  justify-content: center;
  align-items: center;
`;

const outlineButtinStyle = {
  fontSize: 18,
  fontWeight: '700'
};

const headerTextStyle = {
  fontFamily: 'Montserrat-SemiBold',
  textAlign: 'right',
  letterSpacing: 0.2,
  textTransform: 'uppercase',
  fontSize: 13,
  lineHeight: 15,
  padding: 20
};

const ModalContainer = styled.View`
  align-items: center;
  justify-content: center;
`;
const ModalImage = styled.Image`
  height: 70px;
  width: 70px;
  align-self: center;
  margin: 23px 0;
`;

const StyledModalTitle = styled.Text`
  font-family: 'Montserrat';
  font-size: 24px;
  line-height: 36px;
  text-align: center;
  color: ${theme.colors.modalTextBlack};
  margin-bottom: 15px;
  font-weight: 700;
`;

const StyledModalSubTitle = styled.Text`
  font-family: 'MarkOffcPro';
  font-size: 18px;
  line-height: 21px;
  text-align: center;
  color: ${theme.colors.modalTextBlack};
  width: 223px;
  align-items: center;
  margin-bottom: 23px;
  justify-content: center;
`;

export const ModalDetails = ({ message }) => (
  <ModalContainer>
    <ModalImage source={successImage} />
    <StyledModalTitle>Sucess</StyledModalTitle>
    <StyledModalSubTitle>{message}</StyledModalSubTitle>
  </ModalContainer>
);

ModalDetails.propTypes = {
  message: PropTypes.string.isRequired
};

export default CardTransactions;
