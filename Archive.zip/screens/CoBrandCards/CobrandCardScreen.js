import {
  CreditCard,
  ShopActionsText,
  Text,
  LoadingIndicator,
  EmptyState
} from '@components';
import { DrawerActions, useIsFocused } from '@react-navigation/native';
import { UserApi } from 'mastercard_loyalty_sandbox_api';
import { useTheme } from 'styled-components';
import * as actions from '@stores/actions';
import {
  theme,
  RefreshAuthToken,
  client,
  extractError,
  triggerImpactLightHaptic,
  AppTracker
} from '@utils/index';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import {
  Dimensions,
  TouchableOpacity,
  Animated,
  StyleSheet,
  View
} from 'react-native';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useDispatch, useSelector } from 'react-redux';
import styled from 'styled-components/native';

const cardHeight = 200;
const cardTitle = 45;
const cardPadding = 10;

const { height } = Dimensions.get('window');

const CobrandCardScreen = ({ navigation }) => {
  /**  tracker */
  const apptracker = new AppTracker();

  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const appState = useSelector((state) => state);
  const [loading, setLoading] = useState(false);
  const [y] = useState(new Animated.Value(0));
  const authState = appState.authentication;
  const { accessToken, refreshToken, expiresAt } = authState.session;
  const userTier = appState.points;
  const { cards } = appState.cards;
  const [remoteCards, SetRemoteCard] = useState([]);
  const shopTheme = useTheme();

  const OnCardPressed = (crd) => {
    dispatch(actions.openedUserCard(crd));
    navigation.navigate('CardDetails');
  };

  const IsNewCard = (crd) => {
    if (cards.filter((old) => old.mrsId === crd.id).length === 0) {
      return true;
    }
    return false;
  };

  useEffect(() => {
    navigation.addListener('focus', () => {
      navigation.dispatch(DrawerActions.closeDrawer());
    });
    if (isFocused) {
      GetUserAccounts();
    }

    return null;
  }, [navigation, isFocused]);

  const GetUserAccounts = async () => {
    setLoading(true);
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const api = new UserApi(client);
    api.listAccounts({ offset: 0, limit: 20 }, (error, data, response) => {
      // console.log('response', response.body);
      if (response && response.statusCode < 205) {
        const { accounts } = response.body;
        setLoading(false);
        const RemoteCardObject = [];
        accounts.forEach((crd) => {
          const cardObject = {
            name: `${crd.firstName} ${crd.lastName}`,
            pan: crd.accountNumber,
            mask: crd.accountNumber,
            mrsId: crd.id,
            validUntil: `${crd.expiryMonth}/${crd.expiryYear.slice(-2)}`,
            balance: '$0.00',
            isCoBrand: crd.isCoBrand,
            isDefault: crd.isDefault,
            redemptionFrequency: crd.redemptionFrequency
          };
          RemoteCardObject.push(cardObject);
          if (IsNewCard(crd)) {
            dispatch(actions.addUserCard(cardObject));
          }
        });
        SetRemoteCard(RemoteCardObject);
      } else {
        const errorData = extractError(error);
        apptracker.logCardsFailure('List cards failure', {
          errorCode: response.statusCode,
          errorMessage: errorData.Details
        });
        setLoading(false);
        throw errorData.Details;
      }
    });
  };

  return (
    <>
      <HeaderSection>
        <HeaderWrapperLeft>
          <ShopActionsText
            text="Cards"
            size={30}
            lineHeight={36}
            weight={900}
            transform="none"
            color={theme.colors.textPrimary}
            style={{ fontWeight: '900', fontFamily: 'MarkOffcPro-Black' }}
          />
          <Text as="P3" style={{ color: theme.colors.textSecondary }}>
            {`You have ${userTier.tierPoints} Points`}
          </Text>
        </HeaderWrapperLeft>
        <HeaderWrapperRight>
          <TouchableOpacity
            onPress={() => navigation.navigate('AddCardOnFile')}
          >
            <MIcon
              name="plus-circle"
              color={shopTheme.colors.primary || theme.colors.primary}
              size={42}
            />
          </TouchableOpacity>
        </HeaderWrapperRight>
      </HeaderSection>

      <CardsListView>
        <MessageRow>
          {remoteCards.length === 0 && loading && <LoadingIndicator />}
          {remoteCards.length === 0 && !loading && (
            <>
              <EmptyState
                title="No cards added"
                subTitle="Tap the '+' button to add a new card"
              />
            </>
          )}
        </MessageRow>
        <View style={styles.container}>
          <Animated.ScrollView
            scrollEventThrottle={16}
            contentContainerStyle={styles.content}
            showsVerticalScrollIndicator={false}
            onScroll={Animated.event(
              [
                {
                  nativeEvent: {
                    contentOffset: { y }
                  }
                }
              ],
              { useNativeDriver: true }
            )}
          >
            <View style={StyleSheet.absoluteFill}>
              {remoteCards.map((card, i) => {
                const inputRange = [-cardHeight, 0];
                const outputRange = [
                  cardHeight * i,
                  (cardHeight - cardTitle) * -i
                ];
                if (i > 0) {
                  inputRange.push(cardPadding * i);
                  outputRange.push((cardHeight - cardPadding) * -i);
                }
                const translateY = y.interpolate({
                  inputRange,
                  outputRange,
                  extrapolateRight: 'clamp'
                });
                return (
                  <Animated.View
                    key={i}
                    style={{ transform: [{ translateY }] }}
                  >
                    <View>
                      <TouchableOpacity
                        onPress={() => {
                          triggerImpactLightHaptic();
                          OnCardPressed(card);
                        }}
                        activeOpacity={0.98}
                      >
                        <View>
                          <CreditCard
                            card={card}
                            isCoBrand={card.isCoBrand}
                            pointsBalance={0}
                          />
                        </View>
                      </TouchableOpacity>
                    </View>
                  </Animated.View>
                );
              })}
            </View>
          </Animated.ScrollView>
        </View>
      </CardsListView>
      <FooterContainer>
        <ApplyButton
          onPress={() => {
            triggerImpactLightHaptic();
            navigation.push('CoBrandCardBanner');
          }}
        >
          <ApplyCardText>Apply for a Co-brand Card</ApplyCardText>
        </ApplyButton>
      </FooterContainer>
    </>
  );
};

CobrandCardScreen.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired,
    addListener: PropTypes.func.isRequired,
    dispatch: PropTypes.func.isRequired
  }).isRequired
};
const FooterContainer = styled.View`
  background-color: ${theme.colors.none};
  padding: 24px 20px;
  height: 100px;
  justify-content: center;
  align-items: center;
`;
const HeaderSection = styled.View`
  background-color: ${theme.colors.textWhite};
  padding: 24px 20px;
  flex-direction: row;
  align-items: flex-start;
`;
const HeaderWrapperLeft = styled.View`
  justify-content: flex-start;
  align-items: flex-start;
  flex: 1;
`;
const HeaderWrapperRight = styled.View`
  justify-content: flex-end;
  align-items: flex-end;
  flex: 1;
`;
const CardsListView = styled.View`
  flex: 1;
  padding: 0 10px;
  background-color: ${theme.colors.textWhite};
`;

const ApplyButton = styled.TouchableOpacity`
  border: solid;
  border-width: 1px;
  border-color: ${theme.colors.textPrimary};
  padding: 10px;
  border-radius: 20px;
  width: 95%;
`;
const ApplyCardText = styled.Text`
  font-family: MarkOffcPro;
  font-weight: 700;
  line-height: 22px;
  font-size: 18px;
  color: ${theme.colors.textPrimary};
  text-align: center;
`;
const MessageRow = styled.View`
  align-items: center;
`;

const styles = StyleSheet.create({
  root: {
    flex: 1,
    margin: 16
  },
  container: {
    flex: 1
  },
  content: {
    height: height * 2
  }
});

CobrandCardScreen.propTypes = {
  navigation: PropTypes.shape({
    addListener: PropTypes.func.isRequired,
    dispatch: PropTypes.func.isRequired,
    push: PropTypes.func.isRequired,
    navigate: PropTypes.func.isRequired
  }).isRequired
};

export default CobrandCardScreen;
