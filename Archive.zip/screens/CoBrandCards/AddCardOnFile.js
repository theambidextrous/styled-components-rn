import React from 'react';
import { Platform, Alert } from 'react-native';
import PropTypes from 'prop-types';
import { Formik } from 'formik';
import { useSelector, useDispatch } from 'react-redux';
import { ifIphoneX } from 'react-native-iphone-x-helper';
import styled from 'styled-components/native';
import * as actions from '@stores/actions';
import * as yup from 'yup';
import { UserApi, AddAccountRequest } from 'mastercard_loyalty_sandbox_api';
import {
  theme,
  client,
  RefreshAuthToken,
  extractError,
  CardIsExpired,
  triggerSuccessHaptic,
  AppTracker
} from '@utils/index';
import {
  PrimaryButton,
  CustomStatusBar,
  ShopActionsText,
  ModalPopUp,
  ModalContent
} from '@components';
import AddCardForm from './AddCardForm';

const validationSchema = yup.object().shape({
  pan: yup.string().required().label('Card Number').min(12).max(19),
  name: yup.string().required().label('Cardholder Name').min(5).max(50),
  expiryMonth: yup.string().required().label('Expiry Month').min(2).max(2),
  expiryYear: yup.string().required().label('Expiry year').min(4).max(4)
});

const AddCardOnFile = ({ navigation }) => {
  /**  tracker */
  const apptracker = new AppTracker();

  const dispatch = useDispatch();
  const appState = useSelector((state) => state);
  const { cards } = appState.cards;
  const userState = appState.authentication;
  const { accessToken, refreshToken, expiresAt } = userState.session;
  const { firstName, lastName } = userState.user;
  const [isLoading, SetStatus] = React.useState(false);
  const [showModal, SetModalStatus] = React.useState(false);

  const IsNewCard = (crd) => {
    if (cards.filter((old) => old.mrsId === crd.id).length === 0) {
      return true;
    }
    return false;
  };

  const HandlePullCardsAfterAdd = (newToken) => {
    client.defaultHeaders = {
      authorization: `Bearer ${newToken}`
    };
    const api = new UserApi(client);
    api.listAccounts({ offset: 0, limit: 20 }, (error, data, response) => {
      if (response && response.statusCode < 205) {
        const { accounts } = response.body;
        accounts.forEach((crd) => {
          const cardObject = {
            name: `${crd.firstName} ${crd.lastName}`,
            pan: crd.accountNumber,
            mask: crd.accountNumber,
            mrsId: crd.id,
            validUntil: `${crd.expiryMonth}/${crd.expiryYear.slice(-2)}`,
            balance: '$0.00'
          };
          if (IsNewCard(crd)) {
            dispatch(actions.addUserCard(cardObject));
          }
        });
      } else {
        const errorData = extractError(error);
        throw errorData.Details;
      }
    });
  };

  const HandleAddCard = async (requestBody, formik) => {
    const expDateYear = `${requestBody.expiryYear}-${requestBody.expiryMonth}-01`;
    if (CardIsExpired(expDateYear)) {
      Alert.alert('card error', 'This card is already expired.');
      return;
    }
    SetStatus(true);
    const newTkn = await RefreshAuthToken(accessToken, refreshToken, expiresAt);
    client.defaultHeaders = {
      authorization: `Bearer ${newTkn.accessToken}`
    };
    const api = new UserApi(client);
    const reqBody = {
      accountNumber: requestBody.pan,
      expiryMonth: requestBody.expiryMonth,
      expiryYear: requestBody.expiryYear
    };
    try {
      api.addAccount(
        AddAccountRequest.constructFromObject(reqBody),
        async (error, data, response) => {
          if (response && response.statusCode < 205) {
            await HandlePullCardsAfterAdd(newTkn.accessToken);
            SetStatus(false);
            formik.resetForm();
            triggerSuccessHaptic();
            SetModalStatus(true);
          } else if (response.statusCode === 500) {
            apptracker.logCardsFailure('Add card failure', {
              errorCode: response.statusCode,
              errorMessage: String(error)
            });
            SetStatus(false);
            Alert.alert(
              'Oops, something went wrong',
              'Service unavailable. Try again later',
              [
                {
                  text: 'Ok',
                  onPress: () => navigation.goBack()
                }
              ]
            );
          } else {
            const errorData = extractError(error);
            apptracker.logCardsFailure('Add card failure', {
              errorCode: response.statusCode,
              errorMessage: errorData.Details
            });
            SetStatus(false);
            Alert.alert('Oops, something went wrong', errorData.Details);
          }
        }
      );
    } catch (error) {
      Alert.alert('Oops, something went wrong', 'Request timed out');
    }
  };
  return (
    <StyledSafeAreaView>
      <CustomStatusBar />
      <ModalPopUp visible={showModal}>
        <ModalContent
          title="Success"
          message="Your card is now enabled for digital use (online, in-app). You can start spending today and earn valuable rewards! "
        />
        <PrimaryButton
          title="Done"
          onPress={() => {
            SetModalStatus(false);
            navigation.goBack();
          }}
        />
      </ModalPopUp>
      <HeaderSection>
        <HeaderTextWrapper>
          <ShopActionsText
            text="Add Card"
            size={30}
            lineHeight={36}
            weight={900}
            transform="none"
            color={theme.colors.textPrimary}
            style={{ fontWeight: '900', fontFamily: 'MarkOffcPro-Black' }}
          />
          <Gap />
          <ShopActionsText
            text="Add the card on file in order to personalize my offers"
            size={14}
            lineHeight={21}
            weight={400}
            transform="none"
            color={theme.colors.textSecondary}
          />
        </HeaderTextWrapper>
      </HeaderSection>
      <Formik
        initialValues={{
          pan: '',
          name: `${firstName}, ${lastName}`,
          expiryMonth: '',
          expiryYear: ''
        }}
        validationSchema={validationSchema}
        onSubmit={(values, formik) => HandleAddCard(values, formik)}
      >
        {(formikProps) => (
          <>
            <AddCardForm formikProps={formikProps} />
            <ButtonContainer
              style={{
                ...ifIphoneX(
                  {
                    marginBottom: 0
                  },
                  {
                    paddingBottom: 16
                  }
                )
              }}
            >
              <PrimaryButton
                title="Save Card"
                onPress={formikProps.handleSubmit}
                loading={isLoading}
                disabled={isLoading}
              />
            </ButtonContainer>
          </>
        )}
      </Formik>
    </StyledSafeAreaView>
  );
};

const ButtonContainer = styled.View`
  padding: 0 20px;
  margin-top: 30px;
  justify-content: flex-end;
  margin-bottom: ${Platform.OS === 'android' ? 10 : 0}px;
  background-color: ${theme.colors.none};
`;
const Gap = styled.View`
  height: 6px;
`;
const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.none};
`;
const HeaderSection = styled.View`
  background-color: ${theme.colors.textWhite};
  padding: 24px 20px 0px 20px;
`;
const HeaderTextWrapper = styled.View`
  justify-content: flex-start;
  align-items: flex-start;
`;

AddCardOnFile.propTypes = {
  navigation: PropTypes.shape({
    navigate: PropTypes.func.isRequired,
    goBack: PropTypes.func.isRequired
  }).isRequired
};

export default AddCardOnFile;
