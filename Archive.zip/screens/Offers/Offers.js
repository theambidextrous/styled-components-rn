import React from 'react';
import { StyleSheet, Dimensions } from 'react-native';
import styled from 'styled-components/native';
import { useSelector } from 'react-redux';
import { TabView, SceneMap } from 'react-native-tab-view';

import { theme, getStatusBar } from '@utils/index';

// Components
import { CustomStatusBar } from '@components';
import renderTabBar from '../Home/TabsRenderer';
import ThirdPartyOffersScreen from './ThirdPartyOffersScreen';
import InStoreOffersScreen from './InStoreOffers';

const OffersScreen = () => {
  const [index, setIndex] = React.useState(0);
  const [routes] = React.useState([
    { key: 'instore', title: 'In Store Offers' },
    { key: 'thirdparty', title: 'Third Party Offers' }
  ]);

  const appState = useSelector((state) => state);
  const { tierName } = appState.points;

  const renderScene = SceneMap({
    instore: InStoreOffersScreen,
    thirdparty: ThirdPartyOffersScreen
  });
  return (
    <>
      <StyledSafeAreaView>
        <CustomStatusBar isLightContent={getStatusBar(tierName)} />
        <Container>
          <TabView
            renderTabBar={renderTabBar}
            style={JsxStyle.TabView}
            navigationState={{ index, routes }}
            renderScene={renderScene}
            onIndexChange={setIndex}
            initialLayout={{ width: Dimensions.get('window').width }}
          />
        </Container>
      </StyledSafeAreaView>
    </>
  );
};

const Container = styled.View`
  flex: 1;
  background-color: ${theme.colors.background};
  padding: 20px;
`;
const StyledSafeAreaView = styled.SafeAreaView`
  flex: 1;
  background-color: ${theme.colors.backgroundLight};
`;

const JsxStyle = StyleSheet.create({
  TabView: {
    maxWidth: '100%',
    minHeight: 310
  }
});
export default OffersScreen;
