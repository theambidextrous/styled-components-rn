import React, { useState } from 'react';
import { Alert, ActivityIndicator } from 'react-native';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { useSelector } from 'react-redux';

// Mastercard API
import { OffersApi, RedeemOfferRequest } from 'mastercard_loyalty_sandbox_api';

import {
  theme,
  client,
  RefreshAuthToken,
  extractError,
  AppTracker,
  getStatusBar
} from '@utils/index';

// Components
import {
  OffersFlatList,
  EmptyState,
  ModalPopUp,
  PrimaryButton,
  CustomStatusBar
} from '@components';

// Hooks
import useStreamOffers from './Hooks/StreamOffers';

// Images
const successImage = require('@assets/images/others/success.png');

const ThirdPartyOffersScreen = () => {
  /**  tracker */
  const apptracker = new AppTracker();
  const [visible, setVisible] = React.useState(false);
  const [offers, fetchMore] = useStreamOffers();
  const [loading, SetLoading] = useState(false);

  const appState = useSelector((state) => state);
  const { tierName } = appState.points;
  const userState = appState.authentication;
  const { accessToken, refreshToken, expiresAt } = userState.session;

  const onDone = () => {
    // fetchMore();
    setVisible(false);
  };

  const OnRedeemOffer = async (offer) => {
    const { offerId, source, sourceId } = offer;
    SetLoading(true);
    try {
      const newTkn = await RefreshAuthToken(
        accessToken,
        refreshToken,
        expiresAt
      );
      client.defaultHeaders = {
        authorization: `Bearer ${newTkn.accessToken}`
      };
      const api = new OffersApi(client);
      const cleanId = offerId;
      const formData = {
        offerId: cleanId,
        source,
        sourceId: sourceId === null ? cleanId : sourceId
      };
      api.activateOffer(
        RedeemOfferRequest.constructFromObject(formData),
        (error, data, response) => {
          if (response && response.statusCode < 205) {
            // console.log('response', response);
            SetLoading(false);
            setVisible(true);
          } else {
            // console.log('error', error);
            SetLoading(false);
            const errorData = extractError(error);
            apptracker.logOffersFailure(
              'Activate offer failure',
              errorData.Details
            );
            Alert.alert(
              "We're sorry, but something went wrong",
              errorData.Details
            );
            throw errorData.Details;
          }
        }
      );
    } catch (error) {
      // console.log('error', error);
      // console.warn(error);
      apptracker.logOffersFailure('Activate offer failure', String(error));
      SetLoading(false);
    }
  };
  return (
    <>
      <CustomStatusBar isLightContent={getStatusBar(tierName)} />
      <ModalPopUp visible={visible}>
        <ModalDetails message="Offer has been successfully activated." />
        <PrimaryButton title="Done" onPress={onDone} />
      </ModalPopUp>
      <Container>
        {offers.isLoading && <ActivityIndicator size="small" color="#000000" />}
        {!offers.isLoading && offers.items.length === 0 && (
          <EmptyStateContainer>
            <EmptyState
              title="You currently do not have any third party offers."
              subTitle="Active offers will appear here!"
            />
          </EmptyStateContainer>
        )}
        <OffersFlatList
          offers={offers.items}
          loading={loading}
          OnActivatePressed={OnRedeemOffer}
          fetchMore={offers.endHasReached ? () => undefined : fetchMore}
        />
      </Container>
    </>
  );
};

const EmptyStateContainer = styled.View`
  justify-content: center;
  align-items: center;
`;

const Container = styled.View`
  margin-top: 20px;
`;

const ModalContainer = styled.View`
  align-items: center;
  justify-content: center;
`;
const ModalImage = styled.Image`
  height: 70px;
  width: 70px;
  align-self: center;
  margin: 23px 0;
`;

const StyledModalTitle = styled.Text`
  font-family: 'Montserrat';
  font-size: 24px;
  line-height: 36px;
  text-align: center;
  color: ${theme.colors.modalTextBlack};
  margin-bottom: 15px;
  font-weight: 700;
`;

const StyledModalSubTitle = styled.Text`
  font-family: 'MarkOffcPro';
  font-size: 18px;
  line-height: 21px;
  text-align: center;
  color: ${theme.colors.modalTextBlack};
  width: 223px;
  align-items: center;
  margin-bottom: 23px;
  justify-content: center;
`;

const ModalDetails = ({ message }) => (
  <ModalContainer>
    <ModalImage source={successImage} />
    <StyledModalTitle>Offer Activated</StyledModalTitle>
    <StyledModalSubTitle>{message}</StyledModalSubTitle>
  </ModalContainer>
);
ModalDetails.propTypes = {
  message: PropTypes.string.isRequired
};

export default ThirdPartyOffersScreen;
