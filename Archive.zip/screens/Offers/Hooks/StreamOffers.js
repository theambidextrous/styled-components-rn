import { useState, useEffect, useCallback } from 'react';
import { OffersApi } from 'mastercard_loyalty_sandbox_api';
import { useSelector } from 'react-redux';
import {
  client,
  OffersListFormatter,
  RefreshAuthToken,
  AppTracker
} from '@utils/index';

export default function useStreamOffers() {
  /**  tracker */
  const apptracker = new AppTracker();

  const { accessToken, refreshToken, expiresAt } = useSelector(
    (state) => state.authentication.session
  );
  const [currentPage, setPage] = useState(1);
  const [shouldFetch, setShouldFetch] = useState(true);
  const [offers, setOffers] = useState({
    error: '',
    items: [],
    isLoading: true,
    endHasReached: false
  });
  const fetchMore = useCallback(() => setShouldFetch(true), []);

  useEffect(() => {
    if (!shouldFetch) {
      return;
    }
    const GetUserOffers = async (page, limit) => {
      setOffers({
        ...offers,
        isLoading: true
      });
      const offset = page === 1 ? 0 : page * limit;
      /** refresh the token */
      const newTkn = await RefreshAuthToken(
        accessToken,
        refreshToken,
        expiresAt
      );
      client.defaultHeaders = {
        authorization: `Bearer ${newTkn.accessToken}`
      };
      const api = new OffersApi(client);
      api.listThirdPartyOffers({ offset, limit }, (error, data, response) => {
        setShouldFetch(false);
        if (Number(response.statusCode) < 205) {
          // console.log('response.body.offers', response.body.offers);
          if (
            Array.isArray(response.body.offers)
            && response.body.offers.length > 0 // prettier-ignore
          ) {
            const offersPayload = response.body.offers;
            const newOffers = OffersListFormatter(offersPayload);
            setOffers({
              ...offers,
              isLoading: false,
              items: [...offers.items, ...newOffers],
              endHasReached: limit > newOffers.length
            });
          } else {
            setOffers({
              ...offers,
              isLoading: false,
              items: [...offers.items],
              endHasReached: false
            });
          }
        } else {
          /** error */
          apptracker.logOffersFailure('Load offers failure', String(error));
          setOffers({
            ...offers,
            isLoading: false,
            items: [...offers.items],
            error: 'no offers found'
          });
        }
        setPage(currentPage + 1);
      });
    };
    GetUserOffers(currentPage, 5);
  }, [currentPage, shouldFetch]);
  return [offers, fetchMore];
}
