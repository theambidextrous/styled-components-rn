import { SERVER_API } from '@utils/apiClient';
import axios from 'axios';

const api = axios.create({
  baseURL: SERVER_API
});
/** time handler */
const TokenExpiryFromNow = (expiration) => {
  const seconds = Math.floor(Date.now() / 1000);
  return Number(seconds) + Number(expiration);
};
/** post headers */
api.defaults.headers.post['Content-Type'] = 'application/json';
api.defaults.headers.post.Accept = 'application/json';

const refreshUserToken = (requestBody) =>
  api.post('/authorizations/tokens', requestBody).then((res) => {
    const { accessToken, refreshToken, expiresIn } = res.data;
    return {
      accessToken,
      refreshToken,
      expiresIn,
      expiresAt: TokenExpiryFromNow(expiresIn)
    };
  });

const getNewArrivals = (requestBody, bearerToken, applicationId) =>
  api
    .get('/new-arrivals', requestBody, {
      headers: {
        Authorization: `Bearer ${bearerToken}`,
        'App-Id': applicationId
      }
    })
    .then((res) => res.data);

export { refreshUserToken, getNewArrivals };
