import CategoriesSkeleton from './CategoriesSkeleton';
import Loader from './Loader';
import LoaderSkeleton from './LoaderSkeleton';
import NewArrivalsSkeleton from './NewArrivals';
import CampaignSkeleton from './CampaignSkeleton';

export {
  NewArrivalsSkeleton,
  CategoriesSkeleton,
  LoaderSkeleton,
  CampaignSkeleton,
  Loader
};
