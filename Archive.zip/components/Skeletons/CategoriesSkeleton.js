import React from 'react';
import { View } from 'react-native';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';

const CategoriesSkeleton = ({}) =>
  Array.from({ length: 3 }).map((_, index) => (
    <View key={index} style={{ marginBottom: 1, marginVertical: 15 }}>
      <SkeletonPlaceholder
        backgroundColor="#efefef"
        speed={1500}
        highlightColor="#F6F6F6"
      >
        <SkeletonPlaceholder.Item flexDirection="row">
          <SkeletonPlaceholder.Item width={96} height={96} borderRadius={4} />
          <SkeletonPlaceholder.Item
            flex={1}
            justifyContent="center"
            marginLeft={10}
          >
            <SkeletonPlaceholder.Item
              width="50%"
              height={20}
              marginBottom={6}
              borderRadius={2}
            />
            <SkeletonPlaceholder.Item
              width="30%"
              height={10}
              borderRadius={2}
            />
          </SkeletonPlaceholder.Item>
        </SkeletonPlaceholder.Item>
      </SkeletonPlaceholder>
    </View>
  ));

export default CategoriesSkeleton;
