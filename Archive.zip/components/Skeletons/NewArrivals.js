import React from 'react';
import { View } from 'react-native';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import { DEVICE_WIDTH, DEVICE_HEIGHT } from '@utils/';

const NewArrivalsSkeleton = ({}) =>
  Array.from({ length: 6 }).map((_, index) => (
    <View key={index} style={{ marginBottom: 12 }}>
      <SkeletonPlaceholder
        backgroundColor="#efefef"
        speed={1500}
        highlightColor="#F6F6F6"
      >
        <SkeletonPlaceholder.Item flexDirection="column">
          <SkeletonPlaceholder.Item
            width={DEVICE_WIDTH * 0.43}
            height={DEVICE_HEIGHT * 0.2}
            borderRadius={6}
            marginBottom={12}
          />
          <SkeletonPlaceholder.Item>
            <SkeletonPlaceholder.Item
              width="90%"
              height={10}
              borderRadius={3}
              marginBottom={5}
            />
            <SkeletonPlaceholder.Item
              width="70%"
              height={10}
              borderRadius={3}
              marginBottom={5}
            />
            <SkeletonPlaceholder.Item
              width="20%"
              height={10}
              borderRadius={3}
            />
          </SkeletonPlaceholder.Item>
        </SkeletonPlaceholder.Item>
      </SkeletonPlaceholder>
    </View>
  ));

export default NewArrivalsSkeleton;
