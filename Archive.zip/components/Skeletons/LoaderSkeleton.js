import React from 'react';
import { View } from 'react-native';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';

const LoaderSkeleton = ({}) =>
  Array.from({ length: 1 }).map((_, index) => (
    <View key={index} style={{ marginBottom: 1, marginVertical: 8 }}>
      <SkeletonPlaceholder
        backgroundColor="#efefef"
        speed={1500}
        highlightColor="#F6F6F6"
      >
        <SkeletonPlaceholder.Item width="20%" height={8} borderRadius={2} />
      </SkeletonPlaceholder>
    </View>
  ));

export default LoaderSkeleton;
