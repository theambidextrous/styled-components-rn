import React from 'react';
import PropTypes from 'prop-types';
import { ActivityIndicator, Modal, View, Text } from 'react-native';

import { theme } from '@utils';

const Loader = (props) => {
  const { loading, description } = props;

  return (
    <Modal transparent={true} animationType="fade" visible={loading}>
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          flexDirection: 'column',
          justifyContent: 'space-around',
          backgroundColor: 'rgba(46, 53, 50, 0.8)'
        }}
      >
        <View
          style={{
            backgroundColor: '#fff',
            height: 90,
            minWidth: 110,
            borderRadius: 10,
            paddingLeft: 10,
            paddingRight: 10,
            flexDirection: 'column',
            alignSelf: 'center',
            justifyContent: 'space-around'
          }}
        >
          <View
            style={{
              paddingHorizintal: 30,
              paddingVertical: 30,
              alignSelf: 'center'
            }}
          >
            <ActivityIndicator
              animating={loading}
              color={theme.colors.textBlack}
              size="small"
            />
            {description && (
              <Text
                style={{
                  fontSize: 12,
                  marginTop: 12,
                  textAlign: 'center',
                  fontWeight: 'bold'
                }}
              >
                {description}
              </Text>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
};

Loader.defaultProps = {
  description: 'Loading...'
};
Loader.propTypes = {
  loading: PropTypes.bool.isRequired,
  description: PropTypes.string
};

export default Loader;
