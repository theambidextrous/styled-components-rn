import React from 'react';
import styled from 'styled-components/native';

const circularDotImage = require('@assets/images/tutorial/circular_dot.png');
const buttonDotImage = require('@assets/images/tutorial/button_dot.png');

const SliderIndicator = () => (
  <IndicatorView>
    <StyledSliderIndicatorImage
      resizeMode="contain"
      source={circularDotImage}
    />
    <StyledSliderIndicatorImage resizeMode="contain" source={buttonDotImage} />
    <StyledSliderIndicatorImage
      resizeMode="contain"
      source={circularDotImage}
    />
  </IndicatorView>
);

const StyledSliderIndicatorImage = styled.Image`
  width: 20px;
`;
const IndicatorView = styled.View`
  flex-direction: row;
`;

export default SliderIndicator;
