import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

const GoldMemberText = ({ text }) => (
  <StyledGoldMemberText>{text}</StyledGoldMemberText>
);

GoldMemberText.propTypes = {
  text: PropTypes.string.isRequired
};

const StyledGoldMemberText = styled.Text`
  font-size: 16px;
  font-weight: 700;
  line-height: 18px;
  font-family: MarkOffcPro;
  text-transform: uppercase;
`;

export default GoldMemberText;
