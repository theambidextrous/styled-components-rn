import React from 'react';
import { StyleSheet, View } from 'react-native';
import FastImage from 'react-native-fast-image';
import PropTypes from 'prop-types';
import { theme, getTierBackground } from '@utils/';
import styled from 'styled-components/native';
import Icon from 'react-native-vector-icons/FontAwesome';

import CustomProgressBar from './CustomProgressBar';
import UserPointsBottomLabel from './UserPointsBottomLabel';

import Text from '../Text';

const RenderPlatinum = ({ tierName }) => (
  <PlatinumContainer>
    <Text style={TextStyle.TierTitle}>Congratulations,</Text>
    <Text style={{ ...TextStyle.TierTitle, marginTop: 27 }}>You&apos;re a</Text>
    <Text style={TextStyle.TierTitle}>{`${tierName} member`}</Text>
    <BenefitButton>
      <Text style={TextStyle.BenefitText}>{`${tierName} Benefits`}</Text>
      <ButtonIcon>
        <Icon name="chevron-right" size={12} color={theme.colors.textWhite} />
      </ButtonIcon>
    </BenefitButton>
  </PlatinumContainer>
);

RenderPlatinum.propTypes = {
  tierName: PropTypes.string.isRequired
};
const UserTierCard = ({
  tierPoints,
  totalTierPoints,
  tierName,
  nextTier,
  nextTierRemainingPoints
}) => (
  <View>
    <TierImage
      source={getTierBackground(tierName)}
      defaultSource={getTierBackground(tierName)}
      imageStyle={[
        StyleSheet.absoluteFill,
        {
          borderR: 30
        }
      ]}
      resizeMode="cover"
    >
      <>
        {tierName.toUpperCase() === 'PLATINUM' && (
          <RenderPlatinum tierName={tierName} />
        )}
      </>
      <>
        {tierName.toUpperCase() !== 'PLATINUM' && (
          <Container>
            <Text style={TextStyle.TierTitle}>You&apos;re a </Text>
            <Text style={TextStyle.TierName}>{`${tierName} member`}</Text>
            <Text style={TextStyle.TierPoints}>{`${tierPoints} points`}</Text>
            <CustomProgressBar points={tierPoints} total={totalTierPoints} />
            <UserPointsBottomLabel
              points={nextTierRemainingPoints}
              nextLevel={nextTier}
            />
            <BenefitButton>
              <Text style={TextStyle.BenefitText}>
                {`${tierName} Benefits`}
              </Text>
              <ButtonIcon>
                <Icon
                  name="chevron-right"
                  size={12}
                  color={theme.colors.textWhite}
                />
              </ButtonIcon>
            </BenefitButton>
          </Container>
        )}
      </>
    </TierImage>
  </View>
);

const TierImage = styled(FastImage)`
  width: 100%;
  min-height: 200px;
  border-radius: 30px;
  margin-bottom: 8px;
  box-shadow: 2px 2px 2px rgba(0, 0, 0, 0.1);
`;

const Container = styled.View`
  padding: 22px 24px;
  /* border-radius: 50px; */
`;
const PlatinumContainer = styled.View`
  padding: 24px 24px;
  width: 100%;
`;

const ButtonIcon = styled.View`
  margin-left: auto;
`;

const BenefitButton = styled.TouchableOpacity`
  flex-direction: row;
  align-items: center;
  background-color: ${(props) =>
    props.theme.colors.primary || theme.colors.primary};
  border-radius: 24px;
  padding: 10px 18px;
  align-self: flex-start;
  margin-top: 8px;
  margin-bottom: 10px; ;
`;
const TextStyle = StyleSheet.create({
  TierTitle: {
    fontSize: 16,
    lineHeight: 20,
    letterSpacing: -0.36,
    color: '#090B18',
    marginBottom: 4
  },
  TierName: {
    fontSize: 15,
    fontFamily: 'System',
    lineHeight: 20,
    letterSpacing: -0.36,
    fontWeight: '500',
    color: '#090B18',
    marginBottom: 18
  },
  TierPoints: {
    fontSize: 28,
    fontFamily: 'System',
    lineHeight: 34,
    letterSpacing: 0.36,
    fontWeight: 'bold',
    color: '#090B18',
    marginBottom: 12
  },
  pointText: {
    fontSize: 12
  },
  BenefitText: {
    fontSize: 14,
    lineHeight: 18,
    marginRight: 12,
    fontWeight: 'bold',
    textTransform: 'uppercase',
    color: theme.colors.textWhite
  }
});

UserTierCard.propTypes = {
  tierName: PropTypes.string.isRequired,
  tierPoints: PropTypes.number.isRequired,
  totalTierPoints: PropTypes.number.isRequired,
  nextTier: PropTypes.string.isRequired,
  nextTierRemainingPoints: PropTypes.number.isRequired
};

export default UserTierCard;
