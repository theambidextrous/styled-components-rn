import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

const GoldMemberTooltip = ({ text }) => (
  <StyledGoldMemberTooltip>{text}</StyledGoldMemberTooltip>
);
GoldMemberTooltip.propTypes = {
  text: PropTypes.string.isRequired
};

const StyledGoldMemberTooltip = styled.Text`
  font-size: 13px;
  font-weight: 400;
  line-height: 14px;
  font-family: MarkOffcPro;
  text-transform: none;
`;

export default GoldMemberTooltip;
