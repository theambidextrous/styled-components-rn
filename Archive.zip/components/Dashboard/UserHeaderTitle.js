import React from 'react';
import { View } from 'react-native';
import PropTypes from 'prop-types';
import { theme } from '@utils/';
import styled from 'styled-components/native';

const UserHeaderTitle = ({ firstText, secondText }) => (
  <View>
    <View>
      <StyledUserHeaderTitle>{firstText}</StyledUserHeaderTitle>
    </View>
    <View>
      <StyledUserHeaderTitleThick>{secondText}</StyledUserHeaderTitleThick>
    </View>
  </View>
);
UserHeaderTitle.propTypes = {
  firstText: PropTypes.string.isRequired,
  secondText: PropTypes.string.isRequired
};

const StyledUserHeaderTitleThick = styled.Text`
  color: ${theme.colors.textWhite};
  font-weight: 600;
  font-size: 15px;
  text-align: center;
  font-family: MarkOffcPro;
`;
const StyledUserHeaderTitle = styled.Text`
  color: ${theme.colors.textWhite};
  font-weight: 400;
  font-size: 15px;
  text-align: center;
  font-family: MarkOffcPro;
`;
export default UserHeaderTitle;
