import React from 'react';
import PropTypes from 'prop-types';
import { theme } from '@utils/';
import styled from 'styled-components/native';

const CustomProgressBar = ({ points, total }) => {
  const larger = total > points ? total : points;
  return (
    <StyledView>
      <StyledProgressBar>
        <StyledProgressBarFill width={Number((points / larger) * 100)} />
      </StyledProgressBar>
    </StyledView>
  );
};
CustomProgressBar.propTypes = {
  points: PropTypes.number.isRequired,
  total: PropTypes.number.isRequired
};

/** progress bar */
const StyledProgressBar = styled.View`
  height: 8px;
  background-color: ${theme.colors.progressBarEmpty};
  width: 100%;
  border-radius: 8px;
`;

const StyledView = styled.View`
  margin-bottom: 12px;
`;

const StyledProgressBarFill = styled.View`
  height: 8px;
  background-color: ${(props) =>
    props.theme.colors.primary || theme.colors.primary};
  width: ${(props) => props.width}%;
  border-radius: 8px;
`;

export default CustomProgressBar;
