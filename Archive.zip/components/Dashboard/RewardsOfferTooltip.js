import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { theme } from '@utils/index';

const RewardsOfferTooltip = ({ text, boldText }) => (
  <StyledRewardsOfferTooltip>
    {text}
    <StyledRewardsOfferTooltipBold>{boldText}</StyledRewardsOfferTooltipBold>
  </StyledRewardsOfferTooltip>
);
RewardsOfferTooltip.defaultProps = {
  text: 'buy 1 get 1 free',
  boldText: ''
};
RewardsOfferTooltip.propTypes = {
  text: PropTypes.string,
  boldText: PropTypes.string
};

const StyledRewardsOfferTooltip = styled.Text`
  font-size: 12px;
  font-weight: 500;
  line-height: 15px;
  margin-top: 7px;
  font-family: Montserrat-Black;
  color: ${theme.colors.black};
`;
const StyledRewardsOfferTooltipBold = styled.Text`
  font-size: 12px;
  font-weight: 700;
  line-height: 12px;
  font-family: Montserrat;
`;

export default RewardsOfferTooltip;
