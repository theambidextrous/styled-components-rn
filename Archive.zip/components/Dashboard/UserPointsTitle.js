import React from 'react';
import PropTypes from 'prop-types';
import { theme } from '@utils/';
import styled from 'styled-components/native';

const UserPointsTitle = ({ points }) => {
  const label = `${points} points`;
  return <StyledUserPointsTitle>{label}</StyledUserPointsTitle>;
};
UserPointsTitle.propTypes = {
  points: PropTypes.number.isRequired
};
const StyledUserPointsTitle = styled.Text`
  line-height: 35px;
  font-size: 30px;
  color: ${theme.colors.black};
  font-family: 'MarkOffcPro-Black';
`;

export default UserPointsTitle;
