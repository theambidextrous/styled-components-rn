import React from 'react';
import PropTypes from 'prop-types';
import FastImage from 'react-native-fast-image';
import styled from 'styled-components/native';

const MemberShipIcon = ({ source, ...rest }) => (
  <StyledMemberShipIcon source={source} {...rest} />
);

MemberShipIcon.propTypes = {
  source: PropTypes.number.isRequired
};
const StyledMemberShipIcon = styled(FastImage)`
  height: 44px;
  width: 44px;
`;
export default MemberShipIcon;
