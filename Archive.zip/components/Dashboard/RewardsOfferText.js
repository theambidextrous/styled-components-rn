import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { theme } from '@utils/index';

const RewardsOfferText = ({ text }) => (
  <StyledRewardsOfferText>{text}</StyledRewardsOfferText>
);
RewardsOfferText.defaultProps = {
  text: '$1 offer'
};
RewardsOfferText.propTypes = {
  text: PropTypes.string
};

const StyledRewardsOfferText = styled.Text`
  font-size: 22px;
  font-weight: 800;
  flex-wrap: wrap;
  line-height: 28px;
  font-family: 'Montserrat-Black';
  text-transform: uppercase;
  color: ${theme.colors.black};
`;

export default RewardsOfferText;
