import React from 'react';
import PropTypes from 'prop-types';
import { theme } from '@utils/';
import styled from 'styled-components/native';

const UserPointsTooltip = ({ points, total }) => {
  const labelOne = `${points} points of `;
  const labelTwo = `${total} `;
  return (
    <StyledUserPointsTooltip>
      {labelOne}
      <StyledUserPointsTooltipBold>{labelTwo}</StyledUserPointsTooltipBold>
      points
    </StyledUserPointsTooltip>
  );
};
UserPointsTooltip.propTypes = {
  points: PropTypes.number.isRequired,
  total: PropTypes.number.isRequired
};

const StyledUserPointsTooltip = styled.Text`
  line-height: 12px;
  font-size: 10px;
  color: ${theme.colors.black};
  font-family: MarkOffcPro;
  text-align: right;
  flex: 2;
  margin-bottom: -10px;
`;
const StyledUserPointsTooltipBold = styled.Text`
  line-height: 12px;
  font-size: 10px;
  color: ${theme.colors.black};
  font-weight: bold;
  font-family: MarkOffcPro;
  text-align: right;
`;

export default UserPointsTooltip;
