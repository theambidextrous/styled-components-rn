import React from 'react';
import PropTypes from 'prop-types';
import { theme } from '@utils/';
import styled from 'styled-components/native';

const UserPointsBottomLabel = ({ points, nextLevel }) => {
  const labelOne = ` ${points} `;
  const labelTwo = ` ${nextLevel}`;
  return (
    <StyledUserPointsBottomLabel>
      Earn
      <StyledUserPointsBottomLabelBold>
        {labelOne}
      </StyledUserPointsBottomLabelBold>
      more and unlock
      <StyledUserPointsBottomLabelBold>
        {labelTwo}
      </StyledUserPointsBottomLabelBold>
    </StyledUserPointsBottomLabel>
  );
};
UserPointsBottomLabel.propTypes = {
  points: PropTypes.number.isRequired,
  nextLevel: PropTypes.string.isRequired
};

const StyledUserPointsBottomLabel = styled.Text`
  width: 100%;
  text-align: left;
  line-height: 12px;
  font-size: 12px;
  color: ${theme.colors.black};
  font-family: MarkOffcPro;
`;
const StyledUserPointsBottomLabelBold = styled.Text`
  line-height: 12px;
  font-size: 12px;
  color: ${theme.colors.black};
  font-family: MarkOffcPro;
  font-weight: bold;
`;

export default UserPointsBottomLabel;
