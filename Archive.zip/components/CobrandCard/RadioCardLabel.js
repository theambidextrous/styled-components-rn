import React from 'react';
import { View } from 'react-native';
import PropTypes from 'prop-types';
import FastImage from 'react-native-fast-image';
import styled from 'styled-components/native';
import { theme, BackgroundSelector } from '@utils/index';
import ShopActionsText from '../Shop/ShopActionsText';

const cobrandImage = require('@assets/images/others/cobrandart_sm.png');

const RadioCardLabel = ({ id, pan, name, isCobrand }) => (
  <Wrapper>
    <View>
      <CardBackground
        resizeMode="cover"
        source={isCobrand ? Number(cobrandImage) : BackgroundSelector(id, 'sm')}
      />
    </View>
    <View style={{ marginLeft: 16 }}>
      <ShopActionsText
        numberOfLines={1}
        style={{ fontFamily: 'Montserrat', width: 170 }}
        text={name}
        size={16}
        lineHeight={19}
        weight={600}
        transform="none"
        color={theme.colors.textPrimary}
      />
      <Gap />
      <ShopActionsText
        numberOfLines={1}
        style={{ fontFamily: 'Montserrat', width: 170 }}
        text={pan}
        size={14}
        lineHeight={15}
        weight={500}
        transform="none"
        color={theme.colors.textSecondary}
      />
    </View>
  </Wrapper>
);

const CardBackground = styled(FastImage)`
  width: 60px;
  height: 40px;
  border-radius: 5px;
`;
const Gap = styled.View`
  height: 11px;
`;
const Wrapper = styled.View`
  flex: 1;
  flex-direction: row;
  justify-content: center;
  align-items: center;
`;
RadioCardLabel.propTypes = {
  id: PropTypes.number.isRequired,
  pan: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  isCobrand: PropTypes.bool.isRequired
};

export default RadioCardLabel;
