import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

const CardPileWrapper = ({ zIndex, bottom, Child, transform }) => (
  <CardPileWrapperView
    zIndex={zIndex}
    bottom={bottom}
    style={{
      transform: [{ scale: transform }]
    }}
  >
    {Child}
  </CardPileWrapperView>
);

CardPileWrapper.propTypes = {
  zIndex: PropTypes.number.isRequired,
  bottom: PropTypes.number.isRequired,
  transform: PropTypes.number.isRequired,
  Child: PropTypes.node.isRequired
};

const CardPileWrapperView = styled.View`
  width: 100%;
  align-self: center;
  position: absolute;
  opacity: 1;
  z-index: ${(props) => props.zIndex};
  bottom: ${(props) => props.bottom}px;
`;

export default CardPileWrapper;
