import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import FIcon from 'react-native-vector-icons/FontAwesome';
import { theme } from '@utils';

const CardActionItem = ({ iconName, isMd, label, width, OnActionPressed }) => (
  <ActionWrapper>
    <ActionTouchable onPress={OnActionPressed}>
      <ActionView>
        {isMd ? (
          <MIcon name={iconName} size={20} color={theme.colors.primary} />
        ) : (
          <FIcon name={iconName} size={20} color={theme.colors.primary} />
        )}
      </ActionView>
      <ActionLabel len={width}>{label}</ActionLabel>
    </ActionTouchable>
  </ActionWrapper>
);

const ActionWrapper = styled.View`
  flex: 1;
  align-items: center;
`;
const ActionTouchable = styled.TouchableOpacity`
  align-items: center;
`;
const ActionView = styled.View`
  background-color: ${theme.colors.lightGrey};
  height: 40px;
  width: 40px;
  border-radius: 20px;
  justify-content: center;
  align-items: center;
`;
const ActionLabel = styled.Text`
  margin-top: 5px;
  font-family: Montserrat;
  font-size: 10px;
  font-weight: 700;
  line-height: 12.19px;
  text-align: center;
  color: ${theme.colors.textPrimary};
  width: ${(props) => props.len}px;
`;
CardActionItem.propTypes = {
  iconName: PropTypes.string.isRequired,
  isMd: PropTypes.bool.isRequired,
  label: PropTypes.string.isRequired,
  width: PropTypes.number,
  OnActionPressed: PropTypes.func
};
CardActionItem.defaultProps = {
  width: 60,
  OnActionPressed: () => null
};

export default CardActionItem;
