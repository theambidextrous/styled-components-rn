/* eslint no-nested-ternary: "off" */
import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { useSelector } from 'react-redux';

import { theme, money } from '@utils';

import { PillButton } from '../Button';
import Text from '../Text';

const Container = styled.View`
  flex-direction: column;
  border-bottom-width: 0.5px;
  border-bottom-color: ${theme.colors.border};
  background-color: ${theme.colors.backgroundLight}; ;
`;

const Wrapper = styled.View`
  padding: 10px 20px;
`;

const HeaderWrapper = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  padding: 0 0 5px 0;
`;

const FooterWrapper = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
`;
const merchantTextStyle = {
  fontFamily: 'Montserrat-SemiBold',
  fontWeight: '600',
  textAlign: 'right',
  fontSize: 12
};

const IneligibleView = styled.View`
  background-color: ${theme.colors.textSecondary};
  border-radius: 22px;
  align-items: center;
  justify-content: center;
`;
const ineligibleTextStyled = {
  fontFamily: 'MarkOffcPro-Heavy',
  fontSize: 12,
  textTransform: 'uppercase',
  fontWeight: '600',
  textAlign: 'right',
  paddingHorizontal: 8,
  color: theme.colors.textWhite
};

const redeemedTextStyle = {
  fontFamily: 'Montserrat-Medium',
  fontSize: 12,
  textTransform: 'uppercase',
  fontWeight: '600',
  textAlign: 'right',
  color: theme.colors.textSecondary
};

const dateTextStyles = {
  color: theme.colors.textSecondary,
  fontSize: 12
};

const getTextStatus = (status) => {
  if (status === '72') {
    return 'Redeem';
  }
  if (status === '59') {
    return 'Redeem';
  }

  return 'Ineligible to Redeem';
};

const TransactionDetailsRow = ({
  date,
  amount,
  responseReasonId,
  pointsRedeemed,
  handleRedeemPoints,
  loading
}) => {
  const userState = useSelector((state) => state);
  const currentShop = userState.multiStore;
  const { shopName } = currentShop;
  return (
    <Container>
      <Wrapper>
        <HeaderWrapper>
          <Text style={merchantTextStyle} as="H4">
            {shopName}
          </Text>
          <Text style={{ fontFamily: 'Montserrat-SemiBold' }} as="P3">
            {money(amount)}
          </Text>
        </HeaderWrapper>
        <FooterWrapper>
          <Text style={dateTextStyles} as="P3">
            {date}
          </Text>
          {responseReasonId === '72' ? (
            <PillButton
              onPress={handleRedeemPoints}
              disabled={responseReasonId !== '72'}
              active={responseReasonId === '59' || '72'}
              inactive={responseReasonId === '70'}
              loading={loading}
              title={getTextStatus(responseReasonId)}
            />
          ) : responseReasonId === '60' ? (
            <Text style={redeemedTextStyle}>
              {`${pointsRedeemed} Points Redeemed`}
            </Text>
          ) : (
            <IneligibleView>
              <Text style={ineligibleTextStyled}>Ineligible to Redeem</Text>
            </IneligibleView>
          )}
        </FooterWrapper>
      </Wrapper>
    </Container>
  );
};

TransactionDetailsRow.propTypes = {
  date: PropTypes.string.isRequired,
  amount: PropTypes.number.isRequired,
  responseReasonId: PropTypes.string.isRequired,
  pointsRedeemed: PropTypes.number.isRequired,
  handleRedeemPoints: PropTypes.func,
  loading: PropTypes.bool
};

TransactionDetailsRow.defaultProps = {
  // onPress: () => null,
  handleRedeemPoints: () => null,
  loading: false
};

export default TransactionDetailsRow;
