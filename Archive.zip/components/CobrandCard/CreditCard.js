import React from 'react';
import PropTypes from 'prop-types';
import FastImage from 'react-native-fast-image';
import styled from 'styled-components/native';
import { theme, normalize } from '@utils/';

const clothesLogo = require('@assets/images/others/clothes_icon.png');
const cardBackground = require('@assets/images/others/card.bg.png');
const cobrandImage = require('@assets/images/others/cobrandart.png');

const cardHeight = 220;

const CreditCard = ({ card, isCoBrand }) => (
  <CardBackground
    isSpaced={isCoBrand}
    resizeMode="cover"
    source={isCoBrand ? cobrandImage : cardBackground}
  >
    {isCoBrand && (
      <McIconView>
        <McIcon resizeMode="contain" source={clothesLogo} />
      </McIconView>
    )}
    <CardMaskView>
      <CardText isLight={isCoBrand} gap={2}>
        {card.mask}
      </CardText>
    </CardMaskView>
    <CardDataRow>
      {/* cardholder */}
      <CardHolderView>
        <CardLabel isLight={isCoBrand}>Card Holder name</CardLabel>
        <CardText
          isLight={isCoBrand}
          numberOfLines={1}
          ellipsizeMode="tail"
          gap={1}
        >
          {card.name}
        </CardText>
      </CardHolderView>
      {/* validity */}
      <CardValidityView>
        <CardLabel isLight={isCoBrand}>Expiry date</CardLabel>
        <CardText isLight={isCoBrand} gap={2}>
          {card.validUntil}
        </CardText>
      </CardValidityView>
    </CardDataRow>
  </CardBackground>
);

CreditCard.propTypes = {
  card: PropTypes.objectOf(PropTypes.any).isRequired,
  isCoBrand: PropTypes.bool.isRequired
};

const CardBackground = styled(FastImage)`
  width: 100%;
  height: ${cardHeight}px;
  border-radius: 14px;
  border-width: 2.5px;
  border-color: ${theme.colors.backgroundColor};
`;
const McIconView = styled.View`
  position: absolute;
  right: 80px;
  bottom: 70px;
`;

const McIcon = styled.Image`
  height: 50px;
  width: 80px;
  position: absolute;
  top: 3px;
`;
const CardLabel = styled.Text`
  text-transform: uppercase;
  font-size: 8px;
  font-family: MarkOffcPro;
  font-weight: 400;
  line-height: 9px;
  color: ${(props) =>
    props.isLight ? theme.colors.textWhite : theme.colors.textPrimary};
`;
const CardText = styled.Text`
  text-transform: uppercase;
  font-size: ${normalize(18)}px;
  font-family: MarkOffcPro;
  line-height: 23.7px;
  color: ${(props) =>
    props.isLight ? theme.colors.textWhite : theme.colors.textPrimary};
  letter-spacing: ${(props) => props.gap}px;
`;
const CardMaskView = styled.View`
  align-items: flex-start;
  padding-left: 20px;
  padding-top: 10px;
  margin-top: 15px;
  margin-bottom: 16px;
`;
const CardDataRow = styled.View`
  flex-direction: row;
  align-items: center;
`;
const CardHolderView = styled.View`
  align-items: flex-start;
  padding-left: 20px;
  padding-top: 10px;
  margin-top: 10px;
  flex: 3;
`;
const CardValidityView = styled.View`
  align-items: flex-start;
  padding-left: 20px;
  padding-top: 10px;
  margin-top: 10px;
  flex: 1;
`;

export default CreditCard;
