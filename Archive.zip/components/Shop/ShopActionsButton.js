import React from 'react';
import { StyleSheet } from 'react-native';
import PropTypes from 'prop-types';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import styled from 'styled-components/native';
import ShopActionsButtonText from './ShopActionsButtonText';

const ShopActionsButton = ({
  width,
  height,
  radius,
  background,
  text,
  color,
  transform,
  weight,
  size,
  lineHeight,
  hasShadow,
  icon,
  press,
  ...props
}) => (
  <StyledShopActionsButton
    style={hasShadow ? Styles.shadow : {}}
    width={width}
    height={height}
    radius={radius}
    background={background}
    onPress={press}
  >
    <ShopActionsButtonText
      color={color}
      transform={transform}
      weight={weight}
      size={size}
      lineHeight={lineHeight}
      text={text}
      {...props}
    />
    {icon && <MIcon name={icon} size={25} color={color} />}
  </StyledShopActionsButton>
);
ShopActionsButton.defaultProps = {
  width: 200,
  height: 44,
  radius: 12,
  background: 'black',
  text: 'sample btn',
  color: 'white',
  transform: 'uppercase',
  weight: 500,
  size: 10,
  lineHeight: 11,
  hasShadow: false,
  icon: null,
  press: () => null
};
ShopActionsButton.propTypes = {
  width: PropTypes.number,
  height: PropTypes.number,
  radius: PropTypes.number,
  background: PropTypes.string,
  text: PropTypes.string,
  color: PropTypes.string,
  transform: PropTypes.string,
  weight: PropTypes.number,
  size: PropTypes.number,
  lineHeight: PropTypes.number,
  icon: PropTypes.string,
  press: PropTypes.func,
  hasShadow: PropTypes.bool
};

const StyledShopActionsButton = styled.TouchableOpacity`
  border-radius: ${(props) => props.radius}px;
  background-color: ${(props) => props.background};
  width: ${(props) => props.width}px;
  align-self: center;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  height: ${(props) => props.height}px;
`;

const Styles = StyleSheet.create({
  shadow: {
    shadowColor: 'rgba(0,0,0, .3)',
    shadowOffset: { height: 1, width: 1 },
    shadowOpacity: 1,
    shadowRadius: 2,
    elevation: 2
  }
});

export default ShopActionsButton;
