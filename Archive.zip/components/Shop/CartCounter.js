import React from 'react';
import { useNavigation } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import Icon from 'react-native-vector-icons/Feather';
import { theme, cartQuantity } from '@utils/';
import styled from 'styled-components/native';

const CartCounter = () => {
  const navigation = useNavigation();
  const appState = useSelector((state) => state);
  const { tierName } = appState.points;
  const cartState = useSelector((state) => state.cart);
  const { items } = cartState;
  const quantity = cartQuantity(items);
  return (
    <StyledCartCounter
      hitSlop={{ top: 20, bottom: 20, left: 50, right: 50 }}
      onPress={() => navigation.push('Cart')}
    >
      <Icon
        name="shopping-bag"
        size={24}
        color={
          tierName === 'Silver'
            ? theme.colors.textWhite
            : theme.colors.textBlack
        }
      />
      {quantity > 0 && (
        <StyledCartCounterView>
          <StyledCartCounterText>{quantity}</StyledCartCounterText>
        </StyledCartCounterView>
      )}
    </StyledCartCounter>
  );
};

const StyledCartCounter = styled.TouchableOpacity`
  border-radius: 24px;
  margin-right: 20px;
  background-color: ${theme.colors.none};
`;
const StyledCartCounterText = styled.Text`
  color: ${theme.colors.textWhite};
  font-size: 11px;
  font-weight: 500;
`;
const StyledCartCounterView = styled.View`
  position: absolute;
  top: -8px;
  right: 3px;
  justify-content: center;
  align-items: center;
  background-color: ${(props) =>
    props.theme.colors.primary || theme.colors.primary};
  width: 16px;
  height: 16px;
  border-radius: 16px;
  color: ${theme.colors.black};
  left: 13px;
`;

export default CartCounter;
