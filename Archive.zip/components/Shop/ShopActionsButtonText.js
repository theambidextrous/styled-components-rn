import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

const ShopActionsButtonText = ({
  text,
  color,
  transform,
  weight,
  size,
  lineHeight,
  ...props
}) => (
  <StyledShopActionsButtonText
    {...props}
    color={color}
    transform={transform}
    weight={weight}
    size={size}
    lineHeight={lineHeight}
  >
    {text}
  </StyledShopActionsButtonText>
);
ShopActionsButtonText.propTypes = {
  text: PropTypes.string.isRequired,
  color: PropTypes.string.isRequired,
  transform: PropTypes.string.isRequired,
  weight: PropTypes.number.isRequired,
  size: PropTypes.number.isRequired,
  lineHeight: PropTypes.number.isRequired
};

const StyledShopActionsButtonText = styled.Text`
  line-height: ${(props) => props.lineHeight}px;
  font-size: ${(props) => props.size}px;
  color: ${(props) => props.color};
  text-transform: ${(props) => props.transform};
  font-family: MarkOffcPro;
  font-weight: ${(props) => props.weight};
`;

export default ShopActionsButtonText;
