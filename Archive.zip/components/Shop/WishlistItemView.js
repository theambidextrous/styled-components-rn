import React from 'react';
import {
  TouchableOpacity,
  View,
  StyleSheet,
  ImageBackground
} from 'react-native';
import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialIcons';
import styled from 'styled-components/native';
import { theme } from '@utils/';
import * as actions from '@stores/actions';
import ShopActionsText from './ShopActionsText';
import ShopPriceComponent from './ShopPriceComponent';

const WishlistItemView = ({ item, OnProductPressed }) => {
  const dispatcher = useDispatch();
  return (
    <View style={Styles.WishlistItemView}>
      <ImageBackground
        style={Styles.ProductDetailsImg}
        imageStyle={{ borderRadius: 4 }}
        resizeMode="contain"
        source={{ uri: item.image }}
      />
      <StyledProductDetailsInnerLeft>
        <TouchableOpacity onPress={() => OnProductPressed(item)}>
          <ShopActionsText
            style={{ marginBottom: 3 }}
            text={item.name}
            size={16}
            lineHeight={20}
            weight={700}
            ellipsizeMode="tail"
            numberOfLines={2}
            transform="none"
            color={theme.colors.textPrimary}
          />
          <ShopActionsText
            text={item.category}
            size={12}
            lineHeight={18}
            ellipsizeMode="tail"
            numberOfLines={1}
            weight={400}
            transform="none"
            color={theme.colors.textPrimary}
          />
          <PricePadding>
            <ShopPriceComponent
              price={item.price}
              salePrice={item.salePrice}
              direction="column"
            />
          </PricePadding>
        </TouchableOpacity>
      </StyledProductDetailsInnerLeft>
      <StyledProductDetailsInnerRight>
        <RemoveButton
          onPress={() => dispatcher(actions.removeFromWishlist(item.id))}
        >
          <Icon
            name="close"
            size={24}
            style={{
              color: theme.colors.textWhite
            }}
          />
        </RemoveButton>
      </StyledProductDetailsInnerRight>
    </View>
  );
};
WishlistItemView.propTypes = {
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  OnProductPressed: PropTypes.func
};
WishlistItemView.defaultProps = {
  OnProductPressed: () => null
};

const StyledProductDetailsInnerLeft = styled.View`
  margin-left: 20px;
  justify-content: center;
  width: 150px;
`;
const StyledProductDetailsInnerRight = styled.View`
  flex: 1;
  justify-content: center;
  align-items: flex-end;
`;

const PricePadding = styled.View`
  margin-top: 12px;
`;

const RemoveButton = styled.TouchableOpacity`
  position: relative;
  bottom: 16px;
  width: 32px;
  height: 32px;
  margin-left: auto;
  background-color: ${theme.colors.danger};
  border-radius: 32px;
  align-items: center;
  justify-content: center;
`;

const Styles = StyleSheet.create({
  WishlistItemView: {
    marginVertical: 20,
    flexDirection: 'row'
  },
  ProductDetailsImg: {
    height: 96,
    width: 96
  }
});

export default WishlistItemView;
