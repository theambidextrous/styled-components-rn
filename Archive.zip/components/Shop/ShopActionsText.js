import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { normalize } from '@utils';

const ShopActionsText = ({
  text,
  size,
  weight,
  lineHeight,
  transform,
  color,
  ...props
}) => (
  <StyledShopActionsText
    size={size}
    weight={weight}
    lineHeight={lineHeight}
    transform={transform}
    color={color}
    {...props}
  >
    {text}
  </StyledShopActionsText>
);
ShopActionsText.propTypes = {
  text: PropTypes.string.isRequired,
  size: PropTypes.number.isRequired,
  weight: PropTypes.number.isRequired,
  lineHeight: PropTypes.number.isRequired,
  transform: PropTypes.string.isRequired,
  color: PropTypes.string.isRequired
};

const StyledShopActionsText = styled.Text`
  font-size: ${(props) => normalize(props.size)}px;
  font-weight: ${(props) => props.weight};
  line-height: ${(props) => props.lineHeight}px;
  font-family: MarkOffcPro;
  text-transform: ${(props) => props.transform};
  color: ${(props) => props.color};
`;

export default ShopActionsText;
