import React from 'react';
import {
  TouchableOpacity,
  View,
  StyleSheet,
  ImageBackground
} from 'react-native';
import PropTypes from 'prop-types';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import styled from 'styled-components/native';
import { useTheme } from 'styled-components';
import { useDispatch, useSelector } from 'react-redux';
import {
  WishlistsApi,
  CreateWishlistRequest
} from 'mastercard_loyalty_sandbox_api';
import {
  theme,
  IsInWishlist,
  client,
  RefreshAuthToken,
  refreshUserProfile,
  triggerSuccessHaptic,
  triggerImpactLightHaptic,
  AppTracker,
  DEVICE_WIDTH
} from '@utils/index';
import * as actions from '@stores/actions';
import ShopActionsText from './ShopActionsText';
import ShopPriceComponent from './ShopPriceComponent';
import TriggerLocalNotification from '../Notification/index';

const ProductDetailsView = ({ item, OnProductPressed }) => {
  const dispatcher = useDispatch();
  const persistedState = useSelector((state) => state);
  const { accessToken, refreshToken, expiresAt } =
    persistedState.authentication.session;
  const myWishlist = persistedState.wishlist;
  const isInList = IsInWishlist(item.id, myWishlist.items);
  // theme
  const shopTheme = useTheme();
  const AddToWishlist = async () => {
    /**  tracker */
    const apptracker = new AppTracker();

    try {
      const newTkn = await RefreshAuthToken(
        accessToken,
        refreshToken,
        expiresAt
      );
      client.defaultHeaders = {
        authorization: `Bearer ${newTkn.accessToken}`
      };
      const api = new WishlistsApi(client);
      api.createWishlist(
        CreateWishlistRequest.constructFromObject({ sku: item.sku }),
        (error, data, response) => {
          if (Number(response.statusCode) < 205) {
            const points =
              response.body !== undefined
                ? Number(response.body.pointsEarned)
                : 0;
            dispatcher(actions.addUserPoints(points));
            dispatcher(actions.setWishlistPoints(points));
            if (points > 0) {
              setTimeout(() => {
                refreshUserProfile(newTkn.accessToken);
              }, 3000);
              triggerSuccessHaptic();
              TriggerLocalNotification({
                message: `You have earned ${points}points for creating a wishlist`,
                type: 'success',
                icon: 'success',
                duration: 4000
              });
            }
          } else {
            apptracker.logWooCommerceFailure(
              'Add to wishlist failure',
              String(error),
              'hidden'
            );
          }
        }
      );
      triggerImpactLightHaptic();
      dispatcher(actions.addToWishlist(item));
    } catch (error) {
      apptracker.logWooCommerceFailure(
        'Add to wishlist failure',
        String(error),
        'hidden'
      );
      dispatcher(actions.setWishlistPoints(0));
    }
  };
  return (
    <View style={Styles.ProductDetailsView}>
      <View style={Styles.imageContainer}>
        <ImageBackground
          style={Styles.ProductDetailsImg}
          imageStyle={{ borderRadius: 4 }}
          resizeMode="cover"
          source={{ uri: item.image }}
        />
      </View>
      <StyledProductDetailsInnerLeft>
        <TouchableOpacity onPress={() => OnProductPressed(item)}>
          <ShopActionsText
            style={{ marginBottom: 3, fontFamily: 'MarkOffcPro-Bold' }}
            text={item.name}
            size={14}
            lineHeight={20}
            ellipsizeMode="tail"
            numberOfLines={2}
            weight={700}
            transform="none"
            color={theme.colors.textPrimary}
          />
          <ShopActionsText
            text={item.category}
            size={14}
            lineHeight={18}
            ellipsizeMode="tail"
            numberOfLines={1}
            weight={400}
            transform="none"
            style={{ width: DEVICE_WIDTH * 0.46 }}
            color={theme.colors.textPrimary}
          />
          <PricePadding>
            <ShopPriceComponent
              price={item.price}
              salePrice={item.salePrice}
              direction="column"
              style={{ fontFamily: 'MarkOffcPro-Bold' }}
            />
          </PricePadding>
        </TouchableOpacity>
      </StyledProductDetailsInnerLeft>
      <StyledProductDetailsInnerRight>
        <TouchableOpacity
          hitSlop={{ top: 20, bottom: 20, left: 50, right: 50 }}
          onPress={() => {
            if (isInList === false) {
              AddToWishlist();
            }
          }}
        >
          <MIcon
            color={
              isInList
                ? shopTheme.colors.primary || theme.colors.primary
                : theme.colors.textSecondary
            }
            name={isInList ? 'heart' : 'heart-outline'}
            size={22}
          />
        </TouchableOpacity>
      </StyledProductDetailsInnerRight>
    </View>
  );
};
ProductDetailsView.propTypes = {
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  OnProductPressed: PropTypes.func
};
ProductDetailsView.defaultProps = {
  OnProductPressed: () => null
};

const StyledProductDetailsInnerLeft = styled.View`
  margin-left: 20px;
  justify-content: center;
  width: 180px;
`;
const StyledProductDetailsInnerRight = styled.View`
  flex: 1;
  align-items: flex-end;
  /* padding-left: 12px;
  padding-right: 6px; */
`;

const PricePadding = styled.View`
  margin-top: 12px;
`;

const Styles = StyleSheet.create({
  ProductDetailsView: {
    marginVertical: 10,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20
  },
  imageContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderRadius: 6,
    borderColor: theme.colors.backgroundColor,
    backgroundColor: theme.colors.backgroundColor
  },
  ProductDetailsImg: {
    height: 110,
    width: 110
  }
});

export default ProductDetailsView;
