import React from 'react';
import {
  TouchableOpacity,
  ImageBackground,
  View,
  StyleSheet
} from 'react-native';
import PropTypes from 'prop-types';
import { useTheme } from 'styled-components';
import { theme } from '@utils/';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import styled from 'styled-components/native';
import ShopActionsText from './ShopActionsText';

const CategoryDetailsView = ({ item, OnCategoryPressed }) => {
  const shopTheme = useTheme();
  const itemsLabel = `${item.count} items`;
  return (
    <TouchableOpacity onPress={() => OnCategoryPressed(item)}>
      <View style={Styles.CategoryDetailsView}>
        <ImageBackground
          style={Styles.CategoryDetailsImg}
          imageStyle={{ borderRadius: 4 }}
          resizeMode="cover"
          source={{ uri: item.image }}
        />
        <StyledCategoryDetailsInnerLeft>
          <ShopActionsText
            text={item.name}
            size={18}
            lineHeight={28}
            weight={700}
            ellipsizeMode="tail"
            numberOfLines={2}
            transform="none"
            color={theme.colors.textPrimary}
            style={{ fontWeight: '800', fontFamily: 'MarkOffcPro-Black' }}
          />
          <ShopActionsText
            text={itemsLabel}
            size={14}
            lineHeight={18}
            weight={400}
            transform="none"
            color={shopTheme.colors.primary || theme.colors.primary}
          />
        </StyledCategoryDetailsInnerLeft>
        <StyledCategoryDetailsInnerRight>
          <MIcon name="chevron-right" size={24} />
        </StyledCategoryDetailsInnerRight>
      </View>
    </TouchableOpacity>
  );
};
CategoryDetailsView.propTypes = {
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  OnCategoryPressed: PropTypes.func
};
CategoryDetailsView.defaultProps = {
  OnCategoryPressed: () => null
};

const StyledCategoryDetailsInnerLeft = styled.View`
  margin-left: 10px;
  justify-content: center;
  width: 150px;
`;
const StyledCategoryDetailsInnerRight = styled.View`
  flex: 1;
  justify-content: center;
  align-items: flex-end;
`;

const Styles = StyleSheet.create({
  CategoryDetailsView: {
    marginVertical: 10,
    flexDirection: 'row'
  },
  CategoryDetailsImg: {
    height: 96,
    width: 96
  }
});

export default CategoryDetailsView;
