import React from 'react';
import { TouchableOpacity, View, StyleSheet, Dimensions } from 'react-native';
import PropTypes from 'prop-types';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import styled from 'styled-components/native';
import { useTheme } from 'styled-components';
import { useDispatch, useSelector } from 'react-redux';
import {
  WishlistsApi,
  CreateWishlistRequest
} from 'mastercard_loyalty_sandbox_api';
import {
  theme,
  IsInWishlist,
  client,
  RefreshAuthToken,
  refreshUserProfile,
  triggerSuccessHaptic,
  AppTracker
} from '@utils/index';
import * as actions from '@stores/actions';
import ShopActionsText from './ShopActionsText';
import ShopPriceComponent from './ShopPriceComponent';
import TriggerLocalNotification from '../Notification/index';

const ProductGridView = ({
  item,
  cols,
  iconSpaceTop,
  iconSpaceRight,
  OnProductPressed
}) => {
  const dispatcher = useDispatch();
  const persistedState = useSelector((state) => state);
  const { accessToken, refreshToken, expiresAt } =
    persistedState.authentication.session;
  const myWishlist = persistedState.wishlist;
  const isInList = IsInWishlist(item.id, myWishlist.items);
  // theme
  const shopTheme = useTheme();
  const AddToWishlist = async () => {
    /**  tracker */
    const apptracker = new AppTracker();

    try {
      const newTkn = await RefreshAuthToken(
        accessToken,
        refreshToken,
        expiresAt
      );
      client.defaultHeaders = {
        authorization: `Bearer ${newTkn.accessToken}`
      };
      const api = new WishlistsApi(client);
      api.createWishlist(
        CreateWishlistRequest.constructFromObject({ sku: item.sku }),
        (error, data, response) => {
          if (Number(response.statusCode) < 205) {
            const points =
              response.body !== undefined
                ? Number(response.body.pointsEarned)
                : 0;
            dispatcher(actions.addUserPoints(points));
            dispatcher(actions.setWishlistPoints(points));
            if (points > 0) {
              setTimeout(() => {
                refreshUserProfile(newTkn.accessToken);
              }, 3000);
              triggerSuccessHaptic();
              TriggerLocalNotification({
                message: `You have earned ${points}points for creating a wishlist`,
                type: 'success',
                icon: 'success',
                duration: 4000
              });
            }
          } else {
            apptracker.logWooCommerceFailure(
              'Add to wishlist failure',
              String(error),
              'hidden'
            );
          }
        }
      );
      dispatcher(actions.addToWishlist(item));
    } catch (error) {
      apptracker.logWooCommerceFailure(
        'Add to wishlist failure',
        String(error),
        'hidden'
      );
      dispatcher(actions.setWishlistPoints(0));
    }
  };
  return (
    <View style={Styles.marginBottom}>
      <StyledProductGridView cols={cols}>
        <StyledProductGridImage
          cols={cols}
          imageStyle={{ borderRadius: 4 }}
          resizeMode="cover"
          source={{ uri: item.image }}
        >
          <TouchableOpacity
            onPress={() => {
              if (isInList === false) {
                AddToWishlist();
              }
            }}
          >
            <StyledHeartIcon
              color={
                isInList
                  ? shopTheme.colors.primary || theme.colors.primary
                  : theme.colors.mediumGrey
              }
              name={isInList ? 'heart' : 'heart-outline'}
              top={iconSpaceTop}
              right={iconSpaceRight}
              size={22}
            />
          </TouchableOpacity>
        </StyledProductGridImage>
        <TouchableOpacity onPress={() => OnProductPressed(item)}>
          <View style={{ marginTop: 7, alignSelf: 'flex-start' }}>
            <ShopActionsText
              text={item.name}
              size={16}
              ellipsizeMode="tail"
              numberOfLines={1}
              lineHeight={20}
              weight={700}
              transform="none"
              color={theme.colors.textPrimary}
              style={{
                fontWeight: '700',
                fontFamily: 'MarkOffcPro-Bold',
                marginBottom: 3
              }}
            />
            <ShopActionsText
              style={{ marginBottom: 5 }}
              text={item.category}
              size={12}
              lineHeight={18}
              ellipsizeMode="tail"
              numberOfLines={1}
              weight={400}
              transform="none"
              color={theme.colors.textPrimary}
            />
          </View>
          <ShopPriceComponent price={item.price} salePrice={item.salePrice} />
        </TouchableOpacity>
      </StyledProductGridView>
    </View>
  );
};
ProductGridView.propTypes = {
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  cols: PropTypes.number.isRequired,
  OnProductPressed: PropTypes.func,
  iconSpaceRight: PropTypes.number,
  iconSpaceTop: PropTypes.number
};
ProductGridView.defaultProps = {
  iconSpaceRight: 15,
  iconSpaceTop: 15,
  OnProductPressed: () => null
};

const StyledProductGridView = styled.View`
  width: ${(props) => {
    if (props.cols === 1) {
      return Dimensions.get('screen').width * 0.9;
    }
    return Dimensions.get('screen').width * 0.45;
  }}px;
  align-items: center;
  padding: 20px;
`;

const StyledProductGridImage = styled.ImageBackground`
  width: ${(props) => (props.cols === 1 ? 320 : 160)}px;
  height: ${(props) => (props.cols === 1 ? 320 : 160)}px;
`;
const StyledHeartIcon = styled(MIcon)`
  align-self: flex-end;
  top: ${(props) => props.top}px;
  right: ${(props) => props.right}px;
`;

const Styles = StyleSheet.create({
  marginBottom: {
    marginBottom: 40
  }
});

export default ProductGridView;
