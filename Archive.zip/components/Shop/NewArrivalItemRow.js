import React from 'react';
import { View, Dimensions, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { useTheme } from 'styled-components';
import { useDispatch, useSelector } from 'react-redux';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  WishlistsApi,
  CreateWishlistRequest
} from 'mastercard_loyalty_sandbox_api';
import {
  theme,
  IsInWishlist,
  client,
  RefreshAuthToken,
  refreshUserProfile,
  triggerImpactLightHaptic,
  DEVICE_WIDTH,
  DEVICE_HEIGHT,
  triggerSuccessHaptic,
  AppTracker
} from '@utils/index';
import * as actions from '@stores/actions';
import ShopActionsText from './ShopActionsText';
import ShopPriceComponent from './ShopPriceComponent';
import TriggerLocalNotification from '../Notification/index';

const NewArrivalItemRow = ({ item, OnProductPressed }) => {
  const shopTheme = useTheme();
  const dispatcher = useDispatch();
  const persistedState = useSelector((state) => state);
  const { accessToken, refreshToken, expiresAt } =
    persistedState.authentication.session;
  const myWishlist = persistedState.wishlist;
  const isInList = IsInWishlist(item.id, myWishlist.items);
  const AddToWishlist = async () => {
    /**  tracker */
    const apptracker = new AppTracker();

    try {
      const newTkn = await RefreshAuthToken(
        accessToken,
        refreshToken,
        expiresAt
      );
      client.defaultHeaders = {
        authorization: `Bearer ${newTkn.accessToken}`
      };
      const api = new WishlistsApi(client);
      api.createWishlist(
        CreateWishlistRequest.constructFromObject({ sku: item.sku }),
        (error, data, response) => {
          if (Number(response && response.statusCode) < 205) {
            const points =
              response.body !== undefined
                ? Number(response.body.pointsEarned)
                : 1;
            dispatcher(actions.addUserPoints(points));
            dispatcher(actions.setWishlistPoints(points));
            if (points > 0) {
              setTimeout(() => {
                refreshUserProfile(newTkn.accessToken);
              }, 3000);
              triggerSuccessHaptic();
              TriggerLocalNotification({
                message: `You have earned ${points}points for creating a wishlist`,
                type: 'success',
                icon: 'success',
                duration: 4000
              });
            }
          } else {
            apptracker.logWooCommerceFailure(
              'Add to wishlist failure',
              String(error),
              'hidden'
            );
          }
        }
      );
    } catch (error) {
      apptracker.logWooCommerceFailure(
        'Add to wishlist failure',
        String(error),
        'hidden'
      );
      dispatcher(actions.setWishlistPoints(0));
    }
    triggerImpactLightHaptic();
    dispatcher(actions.addToWishlist(item));
  };
  return (
    <>
      <StyledArrivalsItemView>
        <StyledArrivalsItemImage
          source={{ uri: item.image }}
          imageStyle={{ borderRadius: 8 }}
          resizeMode="cover"
        >
          <HeartButton
            hitSlop={{ top: 20, bottom: 20, left: 50, right: 50 }}
            onPress={() => {
              if (isInList === false) {
                AddToWishlist();
              }
            }}
          >
            <StyledHeartIcon
              color={
                isInList
                  ? shopTheme.colors.primary || theme.colors.primary
                  : theme.colors.textPrimary
              }
              name={isInList ? 'heart' : 'heart-outline'}
              size={18}
            />
          </HeartButton>
        </StyledArrivalsItemImage>
        <TouchableOpacity
          onPress={() => OnProductPressed(item)}
          activeOpacity={0.8}
        >
          <View>
            <View>
              <ShopActionsText
                style={{
                  marginBottom: 3,
                  marginTop: 8,
                  fontFamily: 'MarkOffcPro-Bold',
                  width: DEVICE_WIDTH * 0.43
                }}
                text={item.name}
                size={15}
                lineHeight={20}
                ellipsizeMode="tail"
                numberOfLines={1}
                weight={500}
                transform="none"
                color={theme.colors.textPrimary}
              />
              <ShopActionsText
                style={{ marginBottom: 8 }}
                text={item.category}
                size={12}
                ellipsizeMode="tail"
                numberOfLines={1}
                lineHeight={18}
                weight={300}
                transform="none"
                color={theme.colors.black}
              />
            </View>
            <ShopPriceComponent
              price={item.price}
              salePrice={item.salePrice}
              style={{ fontFamily: 'MarkOffcPro-Bold', fontSize: 15 }}
            />
          </View>
        </TouchableOpacity>
      </StyledArrivalsItemView>
    </>
  );
};
NewArrivalItemRow.propTypes = {
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  OnProductPressed: PropTypes.func.isRequired
};

const StyledArrivalsItemView = styled.View`
  margin-bottom: 31px;
  max-width: ${Dimensions.get('screen').width * 0.45}px;
`;

const HeartButton = styled.TouchableOpacity`
  position: relative;
  width: 36px;
  height: 36px;
  margin-left: auto;
  background-color: ${theme.colors.backgroundLight};
  border-radius: 36px;
  align-items: center;
  justify-content: center;
  top: 8px;
  right: 8px;
`;

const StyledHeartIcon = styled(MIcon)``;

const StyledArrivalsItemImage = styled.ImageBackground`
  height: ${DEVICE_HEIGHT * 0.2}px;
  width: ${DEVICE_WIDTH * 0.43}px;
  border: 1px;
  background: ${theme.colors.backgroundColor};
  border-radius: 6px;
  border-color: ${theme.colors.backgroundColor};
`;

export default NewArrivalItemRow;
