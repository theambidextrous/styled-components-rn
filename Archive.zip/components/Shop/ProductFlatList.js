import React from 'react';
import { FlatList } from 'react-native';
import PropTypes from 'prop-types';
import ProductDetailsView from './ProductDetailsView';
import ProductGridView from './ProductGridView';

const ProductFlatList = ({
  products,
  viewState,
  OnProductPressed,
  fetchMore,
  ...rest
}) => (
  <FlatList
    showsVerticalScrollIndicator={false}
    data={products.items}
    renderItem={({ item, index }) => {
      if (viewState.details === true) {
        return (
          <ProductDetailsView
            testID={`product-entry-${index.toString()}`}
            item={item}
            OnProductPressed={OnProductPressed}
          />
        );
      }
      return (
        <ProductGridView
          testID={`product-entry-${index.toString()}`}
          cols={viewState.cols}
          item={item}
          OnProductPressed={OnProductPressed}
        />
      );
    }}
    onEndReachedThreshold={0.2}
    numColumns={viewState.cols}
    onEndReached={fetchMore}
    keyExtractor={(item, index) => String(index)}
    key={viewState.tracker}
    contentContainerStyle={{ paddingBottom: 90, paddingHorizontal: 0 }}
    {...rest}
  />
);
ProductFlatList.propTypes = {
  products: PropTypes.objectOf(PropTypes.any).isRequired,
  viewState: PropTypes.objectOf(PropTypes.any).isRequired,
  OnProductPressed: PropTypes.func.isRequired,
  fetchMore: PropTypes.func.isRequired
};

export default ProductFlatList;
