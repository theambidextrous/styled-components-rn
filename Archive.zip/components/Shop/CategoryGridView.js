import React from 'react';
import { TouchableOpacity, View, StyleSheet, Dimensions } from 'react-native';
import PropTypes from 'prop-types';
import { useTheme } from 'styled-components';
import { theme } from '@utils/';
import styled from 'styled-components/native';
import ShopActionsText from './ShopActionsText';

const CategoryGridView = ({ item, cols, OnCategoryPressed }) => {
  const shopTheme = useTheme();
  const itemsLabel = `${item.count} items`;
  return (
    <TouchableOpacity onPress={() => OnCategoryPressed(item)}>
      <View style={Styles.marginBottom}>
        <StyledCategoryGridView cols={cols}>
          <StyledCategoryGridImage
            cols={cols}
            imageStyle={{ borderRadius: 4 }}
            resizeMode="contain"
            source={{ uri: item.image }}
          />
          <ShopActionsText
            text={item.name}
            size={16}
            lineHeight={24}
            weight={700}
            transform="none"
            color={theme.colors.textPrimary}
          />
          <ShopActionsText
            text={itemsLabel}
            size={14}
            lineHeight={18}
            weight={300}
            transform="none"
            color={shopTheme.colors.primary || theme.colors.primary}
          />
        </StyledCategoryGridView>
      </View>
    </TouchableOpacity>
  );
};
CategoryGridView.propTypes = {
  item: PropTypes.objectOf(PropTypes.any).isRequired,
  cols: PropTypes.number.isRequired,
  OnCategoryPressed: PropTypes.func
};
CategoryGridView.defaultProps = {
  OnCategoryPressed: () => null
};

const StyledCategoryGridView = styled.View`
  width: ${(props) => {
    if (props.cols === 1) {
      return Dimensions.get('screen').width * 0.9;
    }
    return Dimensions.get('screen').width * 0.45;
  }}px;
  align-items: center;
`;
const StyledCategoryGridImage = styled.ImageBackground`
  margin-bottom: 3px;
  width: ${(props) => (props.cols === 1 ? 320 : 160)}px;
  height: ${(props) => (props.cols === 1 ? 320 : 160)}px;
`;

const Styles = StyleSheet.create({
  marginBottom: {
    marginBottom: 15
  }
});

export default CategoryGridView;
