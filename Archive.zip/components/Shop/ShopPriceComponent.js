import React from 'react';
import { View } from 'react-native';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { theme } from '@utils';
import { useTheme } from 'styled-components';
import ShopActionsText from './ShopActionsText';

const ShopPriceComponent = ({ price, salePrice, direction, ...props }) => {
  const shopTheme = useTheme();
  const salePriceLabel = `$${salePrice}`;
  const priceLabel = `$${price}`;
  return (
    <View style={{ flexDirection: direction, width: '100%' }}>
      {String(price) === String(salePrice) ? (
        <ShopActionsText
          text={priceLabel}
          size={16}
          lineHeight={18}
          weight={500}
          transform="none"
          color={shopTheme.colors.primary || theme.colors.primary}
          {...props}
        />
      ) : (
        <>
          <ShopActionsText
            text={salePriceLabel}
            size={16}
            lineHeight={20}
            weight={500}
            transform="none"
            color={shopTheme.colors.primary || theme.colors.primary}
            {...props}
          />
          <StyledPriceDivider />
          <ShopActionsText
            text={priceLabel}
            size={14}
            lineHeight={18}
            weight={400}
            transform="none"
            color={theme.colors.black}
            {...props}
          />
        </>
      )}
    </View>
  );
};

ShopPriceComponent.propTypes = {
  price: PropTypes.string.isRequired,
  salePrice: PropTypes.string.isRequired,
  direction: PropTypes.string
};
ShopPriceComponent.defaultProps = {
  direction: 'row'
};

const StyledPriceDivider = styled.View`
  width: 10px;
`;
export default ShopPriceComponent;
