import React from 'react';
import { ThemeProvider } from 'styled-components/native';
import PropTypes from 'prop-types';
import { useSelector } from 'react-redux';

const ThemeManager = ({ children }) => {
  const appStoredState = useSelector((state) => state);
  const currentShop = appStoredState.multiStore.themeConfig.appConfig;
  return <ThemeProvider theme={currentShop}>{children}</ThemeProvider>;
};

ThemeManager.propTypes = {
  children: PropTypes.node.isRequired
};
export default ThemeManager;
