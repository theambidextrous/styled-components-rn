import React from 'react';
import PropTypes from 'prop-types';
import { Platform, ScrollView, KeyboardAvoidingView } from 'react-native';

const KeyboardAdaptableView = ({
  canDismissKeyboard = true,
  contentContainerStyle = {},
  children
}) => {
  const behaviour = Platform.OS === 'ios' ? 'padding' : 0;
  const keyboardVerticalOffset = Platform.OS === 'ios' ? 70 : 0;
  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={behaviour}
      keyboardVerticalOffset={keyboardVerticalOffset}
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          ...contentContainerStyle,
          flexGrow: 1
          // justifyContent: 'space-between'
        }}
        keyboardShouldPersistTaps={canDismissKeyboard ? 'never' : 'always'}
      >
        {children}
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

KeyboardAdaptableView.defaultProps = {
  canDismissKeyboard: true,
  contentContainerStyle: {} // can change this not sure of the default value
};

KeyboardAdaptableView.propTypes = {
  canDismissKeyboard: PropTypes.bool,
  contentContainerStyle: PropTypes.objectOf(PropTypes.any),
  children: PropTypes.node.isRequired
};

export default KeyboardAdaptableView;
