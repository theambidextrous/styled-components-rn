import { normalize, theme } from '@utils';
import { StyleSheet } from 'react-native';

// primary Mastercard font
const PRIMARY_FONT_REGULAR = 'MarkOffcPro';
const PRIMARY_FONT_BOLD = 'MarkOffcPro-Bold';
const PRIMARY_FONT_BLACK = 'MarkOffcPro-Black';

const styles = StyleSheet.create({
  base: { color: theme.colors.textPrimary },
  H1: {
    fontFamily: PRIMARY_FONT_BLACK,
    fontSize: normalize(30),
    lineHeight: normalize(41)
  },
  H2: {
    fontFamily: PRIMARY_FONT_BOLD,
    fontSize: normalize(24),
    lineHeight: 33
  },
  H3: {
    fontFamily: PRIMARY_FONT_BOLD,
    fontSize: normalize(18),
    lineHeight: normalize(20)
  },
  H4: {
    fontFamily: PRIMARY_FONT_BOLD,
    fontSize: normalize(16),
    lineHeight: normalize(18)
  },
  H5: {
    fontFamily: PRIMARY_FONT_BOLD,
    fontSize: normalize(12),
    lineHeight: normalize(18)
  },
  P1: {
    fontFamily: PRIMARY_FONT_REGULAR,
    fontSize: normalize(18),
    fontWeight: 'normal',
    lineHeight: normalize(24)
  },
  P2: {
    fontFamily: PRIMARY_FONT_REGULAR,
    fontSize: normalize(16),
    lineHeight: normalize(22)
  },
  P3: {
    fontFamily: PRIMARY_FONT_REGULAR,
    fontSize: normalize(14),
    lineHeight: normalize(19)
  },
  P4: {
    fontFamily: PRIMARY_FONT_REGULAR,
    fontSize: normalize(10),
    lineHeight: normalize(14)
  }
});

export default styles;
