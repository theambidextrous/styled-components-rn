import React from 'react';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import Icon from 'react-native-vector-icons/Feather';
import { theme, DEVICE_WIDTH } from '@utils';
import Text from '../Text';

const Container = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  align-items: center;
  padding: 18px;
  background-color: ${theme.colors.backgroundLight};
  border-bottom-width: 1px;
  border-bottom-color: ${theme.colors.border};
`;

const RowButton = styled.TouchableOpacity`
  flex-direction: row;
  align-items: center;
  padding: 18px 12px 18px 18px;
  background-color: ${theme.colors.backgroundLight};
  border-bottom-width: 1px;
  border-bottom-color: ${theme.colors.border};
`;
const RowWrapper = styled.View`
  margin-left: auto;
  flex-direction: row;
  align-items: center;
`;

const ButtonIconWrapper = styled.View`
  margin-left: 12px;
`;

export const ProfileCard = ({ title, subTitle }) => (
  <Container>
    <Text as="H4">{title}</Text>
    <Text
      ellipsizeMode="tail"
      numberOfLines={1}
      as="P2"
      style={{ width: DEVICE_WIDTH * 0.6, textAlign: 'right' }}
    >
      {subTitle}
    </Text>
  </Container>
);

ProfileCard.defaultProps = {
  subTitle: '_'
};

ProfileCard.propTypes = {
  title: PropTypes.string.isRequired,
  subTitle: PropTypes.string
};

export const ProfileActionRow = ({ title, subTitle, onCardPress }) => (
  <RowButton onPress={onCardPress} activeOpacity={0.9}>
    <Text as="H4">{title}</Text>
    <RowWrapper>
      {subTitle && (
        <Text ellipsizeMode="tail" as="P2">
          {subTitle}
        </Text>
      )}
      <ButtonIconWrapper>
        <Icon name="chevron-right" size={24} color={theme.colors.black} />
      </ButtonIconWrapper>
    </RowWrapper>
  </RowButton>
);
ProfileActionRow.defaultProps = {
  subTitle: ' '
};

ProfileActionRow.propTypes = {
  title: PropTypes.string.isRequired,
  subTitle: PropTypes.string,
  onCardPress: PropTypes.func.isRequired
};
