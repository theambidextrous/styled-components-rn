import React from 'react';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import { theme, getInitials } from '@utils';
import Text from '../Text';

const Container = styled.View`
  width: 120px;
  height: 120px;
  border-radius: 120px;
  margin-bottom: 12px;
  background-color: ${theme.colors.backgroundColor};
  align-items: center;
  justify-content: center;
`;
const Avatar = styled.Image``;
const ProfileAvatar = ({ image, firstName, lastName }) => {
  const name = `${firstName} ${lastName}`;
  return (
    <Container>
      {image ? (
        <Avatar source={{ uri: image }} />
      ) : (
        <Text as="H1">{getInitials(name)}</Text>
      )}
    </Container>
  );
};

ProfileAvatar.defaultProps = {
  firstName: 'Loyalty',
  lastName: 'User',
  image: ''
};

ProfileAvatar.propTypes = {
  image: PropTypes.string,
  firstName: PropTypes.string,
  lastName: PropTypes.string
};

export default ProfileAvatar;
