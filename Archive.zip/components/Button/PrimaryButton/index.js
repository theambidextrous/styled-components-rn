import React from 'react';
import { ActivityIndicator } from 'react-native';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { theme, normalize } from '@utils';

const buttonPropTypes = {
  title: PropTypes.string,
  loadingText: PropTypes.string,
  loading: PropTypes.bool,
  children: PropTypes.node,
  hidden: PropTypes.bool
};

const StyledButton = styled.TouchableOpacity`
  background-color: ${(props) =>
    props.theme.colors.primary || theme.colors.primary};
  color: ${(props) => props.theme.colors.primary || theme.colors.primary};
  align-items: center;
  justify-content: center;
  min-height: 42px;
  padding: 0 16px;
  opacity: ${(props) => (props.disabled ? 0.3 : 90)};
  border-radius: 22px;
`;

const ButtonText = styled.Text`
  color: ${(props) => props.theme.colors.textWhite || theme.colors.textWhite};
  font-family: 'MarkOffcPro-Heavy';
  font-size: ${normalize(16)}px;
  line-height: ${normalize(22)}px;
  justify-content: center;
  align-items: center;
`;

const LoadingWrapper = styled.View`
  flex-direction: row;
  align-items: center;
`;

const LoadingText = styled.Text`
  color: ${(props) => props.theme.colors.textWhite || theme.colors.textWhite};
  font-family: 'MarkOffcPro-Heavy';
  font-size: ${normalize(16)}px;
  line-height: ${normalize(22)}px;
  justify-content: center;
  align-items: center;
  margin-left: 6px;
`;

const PrimaryButton = (props) => {
  const { hidden, title, loading, children, loadingText, ...rest } = props;
  return (
    !hidden && (
      <StyledButton
        activeOpacity={0.5}
        color={theme.colors.primary}
        underlayColor={theme.colors.primary}
        {...rest}
      >
        {loading ? (
          <LoadingWrapper>
            <LoadingText>{loadingText}</LoadingText>
            <ActivityIndicator
              style={{ padding: 12 }}
              size="small"
              color={theme.colors.textWhite}
            />
          </LoadingWrapper>
        ) : (
          <ButtonText>{title || children}</ButtonText>
        )}
      </StyledButton>
    )
  );
};

PrimaryButton.propTypes = buttonPropTypes;

PrimaryButton.defaultProps = {
  loading: false,
  title: null,
  children: '',
  loadingText: null,
  hidden: false
};

export default PrimaryButton;
