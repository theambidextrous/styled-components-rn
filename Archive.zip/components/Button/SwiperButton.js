import React from 'react';
import PropTypes from 'prop-types';
import { Text } from 'react-native';
import StyledSwiperButton from '@components/Button/SwiperButton.styles';
/** swipper next */
export const SwiperNextButton = ({
  nextLabel,
  nextLabelComponent,
  isFilled,
  isSkip,
  ...props
}) => (
  <StyledSwiperButton isFilled={isFilled} isSkip={isSkip} {...props}>
    {nextLabelComponent}
  </StyledSwiperButton>
);
SwiperNextButton.propTypes = {
  isFilled: PropTypes.bool.isRequired,
  isSkip: PropTypes.bool.isRequired,
  nextLabel: PropTypes.string.isRequired,
  nextLabelComponent: PropTypes.objectOf(PropTypes.any).isRequired
};
/** Swiper skip */
export const SwiperSkipButton = ({
  skipLabel,
  skipLabelComponent,
  isFilled,
  isSkip,
  ...props
}) => (
  <StyledSwiperButton isFilled={isFilled} isSkip={isSkip} {...props}>
    <Text>{skipLabelComponent}</Text>
  </StyledSwiperButton>
);
SwiperSkipButton.propTypes = {
  isFilled: PropTypes.bool.isRequired,
  isSkip: PropTypes.bool.isRequired,
  skipLabel: PropTypes.string.isRequired,
  skipLabelComponent: PropTypes.objectOf(PropTypes.any).isRequired
};
/** done */
export const SwiperDoneButton = ({ labelComponent, ...props }) => (
  <StyledSwiperButton isFilled isSkip={false} {...props}>
    {labelComponent}
  </StyledSwiperButton>
);
SwiperDoneButton.propTypes = {
  labelComponent: PropTypes.objectOf(PropTypes.any).isRequired
};
