import { theme } from '@utils';
import { Dimensions } from 'react-native';
import styled from 'styled-components/native';

const StyledSwiperButton = styled.TouchableOpacity`
  border-radius: 20px;
  padding: 12px 20px 12px 20px;
  background-color: ${(props) => {
    if (props.isFilled) {
      return theme.colors.primary;
    }
    return theme.colors.none;
  }};
  position: ${(props) => {
    if (props.isSkip) {
      return 'absolute';
    }
    return 'relative';
  }};
  right: ${(props) => {
    if (props.isSkip) {
      return 0;
    }
    return 63;
  }}%;
  top: ${(props) => {
    if (props.isSkip) {
      return 0;
    }
    return -30;
  }}px;
  bottom: 0%;
  left: ${(props) => {
    if (props.isSkip) {
      return '15%';
    }
    return 'auto';
  }};
  width: ${Dimensions.get('window').width * 0.85}px;
  margin-top: ${(props) => {
    if (props.isSkip) {
      return 10;
    }
    return 0;
  }}px;
  align-self: center;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  height: 44px;
`;

export default StyledSwiperButton;
