import React from 'react';
import { ActivityIndicator } from 'react-native';

import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import theme from '@utils/theme';

const StyledButton = styled.TouchableOpacity`
  color: ${(props) => props.theme.colors.primary || theme.colors.primary};
  align-items: center;
  justify-content: center;
  border-radius: 22px;
  background-color: ${(props) => {
    if (props.active) {
      return props.theme.colors.primary || theme.colors.primary;
    }
    if (props.inactive) {
      return theme.colors.textSecondary;
    }
    return theme.colors.backgroundLight;
  }};
  opacity: ${(props) => (props.disabled ? '0.5' : '1.0')};
`;
const ButtonText = styled.Text`
  color: ${(props) => {
    if (props.active) {
      return theme.colors.textWhite;
    }
    if (props.inactive) {
      return theme.colors.textWhite;
    }
    return theme.colors.textSecondary;
  }};
  font-family: 'MarkOffcPro-Heavy';
  align-items: center;
  text-align: center;
  text-transform: uppercase;
  font-size: 12px;
  line-height: 13px;
  justify-content: center;
  align-items: center;
  padding: 4px 10px;
`;

const PillButton = ({ title, loading, children, ...props }) => (
  <StyledButton {...props}>
    {loading ? (
      <ActivityIndicator
        style={{ padding: 12 }}
        size="small"
        color={theme.colors.textWhite}
      />
    ) : (
      <ButtonText {...props}>{title || children}</ButtonText>
    )}
  </StyledButton>
);

const pillPropTypes = {
  title: PropTypes.string,
  loading: PropTypes.bool,
  children: PropTypes.node
};

PillButton.propTypes = pillPropTypes;

PillButton.defaultProps = {
  loading: false,
  title: null,
  children: ''
};

export default PillButton;
