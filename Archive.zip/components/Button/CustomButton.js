import React from 'react';
import PropTypes from 'prop-types';
import * as ButtonStyles from '@components/Button/CustomButton.styles';

export const CustomBtnTextIconWraper = ({ children }) => (
  <ButtonStyles.CustomBtnTextIconWrapper>
    {children}
  </ButtonStyles.CustomBtnTextIconWrapper>
);
CustomBtnTextIconWraper.propTypes = {
  children: PropTypes.arrayOf(PropTypes.any).isRequired
};
export const CustomButtonText = ({ label, isFilled, isLight }) => (
  <ButtonStyles.StyledCustomButtonText isFilled={isFilled} isLight={isLight}>
    {label}
  </ButtonStyles.StyledCustomButtonText>
);
CustomButtonText.propTypes = {
  label: PropTypes.string.isRequired,
  isFilled: PropTypes.bool.isRequired,
  isLight: PropTypes.bool
};
CustomButtonText.defaultProps = {
  isLight: false
};
export const CustomButton = ({
  labelComponent,
  onPress,
  isFilled,
  isLight
}) => (
  <ButtonStyles.StyledCustomButton
    onPress={onPress}
    isFilled={isFilled}
    isLight={isLight}
  >
    {labelComponent}
  </ButtonStyles.StyledCustomButton>
);
CustomButton.propTypes = {
  labelComponent: PropTypes.objectOf(PropTypes.any).isRequired,
  onPress: PropTypes.func.isRequired,
  isFilled: PropTypes.bool.isRequired,
  isLight: PropTypes.bool
};
CustomButton.defaultProps = {
  isLight: false
};
