import { theme } from '@utils';
import { Dimensions } from 'react-native';
import styled from 'styled-components/native';

export const StyledCustomButton = styled.TouchableOpacity`
  border-radius: 20px;
  padding: 12px 20px 12px 20px;
  background-color: ${(props) => {
    if (props.isFilled && !props.isLight) {
      return theme.colors.primary;
    }
    if (props.isFilled && props.isLight) {
      return theme.colors.textWhite;
    }
    return theme.colors.none;
  }};
  width: ${Dimensions.get('window').width * 0.85}px;
  align-self: center;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  height: 44px;
`;

export const CustomBtnTextIconWrapper = styled.View`
  flex-direction: row;
`;

export const StyledCustomButtonText = styled.Text`
  color: ${(props) => {
    if (props.isFilled && !props.isLight) {
      return theme.colors.textWhite;
    }
    if (props.isFilled && props.isLight) {
      return theme.colors.black;
    }
    return theme.colors.textBlack;
  }};
  height: 22px;
  left: 33.28%;
  right: 32.99%;
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 700;
  font-size: 18px;
  line-height: 22px;
  text-align: center;
  padding-right: 12px;
`;
