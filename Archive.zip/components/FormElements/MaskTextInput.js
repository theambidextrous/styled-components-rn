import React from 'react';
import PropTypes from 'prop-types';
import { TextInputMask } from 'react-native-masked-text';
import styled from 'styled-components/native';

import { useTheme } from 'styled-components';
import { theme, normalize, DEVICE_WIDTH } from '@utils';

const Container = styled.View`
  flex-direction: column;
  margin-bottom: 15px;
`;

const StyledTextInput = styled(TextInputMask)`
  background-color: ${theme.colors.backgroundColor};
  padding: 9px 20px 11px 20px;
  min-width: ${DEVICE_WIDTH / 2.3}px;
  border-radius: 22px;
  font-size: ${normalize(18)}px;
  color: ${theme.colors.textPrimary};
  line-height: 24px;
  font-family: 'MarkOffcPro';
`;

const ErrorText = styled.Text`
  font-size: 12px;
  color: red;
  font-weight: 500;
  font-family: 'MarkOffcPro';
  margin-left: 8px;
  padding-top: 2px;
`;

const MaskTextInput = ({ formikProps, formikKey, ...rest }) => {
  const shopTheme = useTheme();
  return (
    <Container>
      <StyledTextInput
        selectionColor={shopTheme.colors.primary || theme.colors.primary}
        placeholderTextColor={theme.colors.placeHolderText}
        onChangeText={formikProps?.handleChange(formikKey)}
        onBlur={formikProps?.handleBlur(formikKey)}
        keyboardAppearance="light"
        value={formikProps?.values[formikKey]}
        {...rest}
      />

      {formikProps?.touched[formikKey] && formikProps.errors[formikKey] && (
        <ErrorText>
          {formikProps?.touched[formikKey] && formikProps.errors[formikKey]}
        </ErrorText>
      )}
    </Container>
  );
};

MaskTextInput.propTypes = {
  formikProps: PropTypes.objectOf(PropTypes.any).isRequired,
  formikKey: PropTypes.string.isRequired
};

export default MaskTextInput;
