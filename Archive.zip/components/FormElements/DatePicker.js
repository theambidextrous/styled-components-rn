import React, { useState } from 'react';
import {
  Modal,
  Platform,
  View,
  TouchableHighlight,
  StyleSheet,
  Text
} from 'react-native';
import PropTypes from 'prop-types';
import DateTimePicker from '@react-native-community/datetimepicker';
import styled from 'styled-components/native';
import moment from 'moment';

import { theme, normalize, DEVICE_WIDTH } from '@utils';

const Container = styled.TouchableOpacity`
  background-color: ${theme.colors.backgroundColor};
  padding: 9px 20px 11px 20px;
  min-width: ${DEVICE_WIDTH / 2.3}px;
  border-radius: 22px;
  font-size: ${normalize(18)}px;
  color: ${theme.colors.textPrimary};
  line-height: 24px;
  font-family: 'MarkOffcPro';
`;

const Wrapper = styled.View``;

const StyledTextInput = styled.Text`
  background-color: ${theme.colors.backgroundColor};
  min-width: ${DEVICE_WIDTH / 2.3}px;
  border-radius: 22px;
  font-size: ${normalize(18)}px;
  color: ${theme.colors.textPrimary};
  line-height: 24px;
  font-family: 'MarkOffcPro';
`;

const ErrorText = styled.Text`
  font-size: 12px;
  color: red;
  font-weight: 500;
  font-family: 'MarkOffcPro';
  margin-left: 8px;
  margin-bottom: 16px;
`;

const DateTime = ({ onDateChange, formikProps, formikKey }) => {
  const [date, setDate] = useState(null);
  const [show, setShow] = useState(false);

  const onChange = (e, selectDate) => {
    if (selectDate) {
      setDate(moment(selectDate));
    }
  };

  const onDonePress = () => {
    onDateChange(date);
    setShow(false);
  };

  const onAndroidChange = (e, selectDate) => {
    setShow(false);
    if (selectDate) {
      setDate(moment(selectDate));
      onDateChange(selectDate);
    }
  };

  const renderDatePicker = () => (
    <DateTimePicker
      display="spinner"
      themeVariant="light"
      mode="date"
      value={new Date(date)}
      onChange={Platform.OS === 'ios' ? onChange : onAndroidChange}
      maximumDate={new Date(moment().format('YYYY-MM-DD'))}
      minimumDate={
        new Date(moment().subtract(120, 'years').format('YYYY-MM-DD'))
      }
    />
  );

  return (
    <>
      {formikProps.touched[formikKey] && formikProps.errors[formikKey] && (
        <ErrorText>
          {formikProps.touched[formikKey] && formikProps.errors[formikKey]}
        </ErrorText>
      )}
      <Container onPress={() => setShow(true)}>
        <Wrapper>
          <>
            {date === null ? (
              <StyledTextInput style={{ color: theme.colors.placeHolderText }}>
                Date of Birth
              </StyledTextInput>
            ) : (
              <StyledTextInput>{date.format('MM/DD/YYYY')}</StyledTextInput>
            )}
          </>
          {Platform.OS !== 'ios' && show && renderDatePicker()}
          {Platform.OS === 'ios' && (
            <Modal
              transparent={true}
              animationType="none"
              visible={show}
              supportedOrientation={['portrait']}
              onRequestClose={() => setShow(false)}
            >
              <View
                style={{
                  flex: 1,
                  alignItems: 'center',
                  flexDirection: 'column',
                  justifyContent: 'space-around',
                  backgroundColor: 'rgba(46, 53, 50, 0.4)'
                }}
              >
                <TouchableHighlight
                  activeOpacity={1}
                  underlayColor="none"
                  visible={show}
                  style={{
                    flex: 1,
                    alignItems: 'flex-end',
                    flexDirection: 'row'
                  }}
                  onPress={onDonePress}
                >
                  <TouchableHighlight
                    underlayColor={theme.colors.textWhite}
                    style={{
                      flex: 1
                    }}
                  >
                    <View
                      style={{
                        overflow: 'hidden',
                        height: 266,
                        backgroundColor: theme.colors.textWhite,
                        paddingHorizontal: 10,
                        paddingVertical: 10
                      }}
                    >
                      <View
                        style={{
                          marginTop: 20
                        }}
                      >
                        {renderDatePicker()}
                      </View>
                      <TouchableHighlight
                        underlayColor="transparent"
                        onPress={onDonePress}
                        style={[styles.btnText, styles.btnDone]}
                      >
                        <Text
                          style={{
                            fontSize: 16,
                            color: theme.colors.primary,
                            fontWeight: '700',
                            fontFamily: 'MarkOffcPro'
                          }}
                        >
                          Done
                        </Text>
                      </TouchableHighlight>
                    </View>
                  </TouchableHighlight>
                </TouchableHighlight>
              </View>
            </Modal>
          )}
        </Wrapper>
      </Container>
    </>
  );
};

const styles = StyleSheet.create({
  btnText: {
    position: 'absolute',
    top: 0,
    height: 52,
    paddingBottom: 10,
    paddingHorizontal: 20,
    fontSize: 25,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center'
  },
  btnCancel: {
    left: 0
  },
  btnDone: {
    right: 0
  }
});
DateTime.propTypes = {
  onDateChange: PropTypes.func.isRequired,
  formikProps: PropTypes.objectOf(PropTypes.any).isRequired,
  formikKey: PropTypes.string.isRequired
};

export default DateTime;
