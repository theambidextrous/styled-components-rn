import React from 'react';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import { theme } from '@utils';
import Text from '../Text';

const EmptyProfileContainer = styled.View`
  justify-content: center;
  align-items: center;
  padding: 20px;
`;

const H2Wrapper = styled.View`
  padding-bottom: 8px;
  margin-top: 20px;
`;

const H3Wrapper = styled.View``;

const StyledH3 = styled(Text)`
  text-align: center;
  font-size: 13px;
  line-height: 23px;
  color: ${theme.colors.textDarkGrey};
`;

const EmptyState = (props) => {
  const { title, subTitle, ...rest } = props;
  return (
    <EmptyProfileContainer {...rest}>
      <H2Wrapper>
        <Text as="H4" style={{ textAlign: 'center' }}>
          {title}
        </Text>
      </H2Wrapper>
      <H3Wrapper>
        <StyledH3>{`${subTitle}.`}</StyledH3>
      </H3Wrapper>
    </EmptyProfileContainer>
  );
};

EmptyState.propTypes = {
  title: PropTypes.string,
  subTitle: PropTypes.string
};

EmptyState.defaultProps = {
  title: '',
  subTitle: ''
};

export default EmptyState;
