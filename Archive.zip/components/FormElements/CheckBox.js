import CheckBox from '@react-native-community/checkbox'; // official checkbox is no longer supported https://reactnative.dev/docs/checkbox
import PropTypes from 'prop-types';
import React from 'react';
import styled from 'styled-components/native';
import { useTheme } from 'styled-components';
import theme from '@utils/theme';

const Container = styled.View`
  flex-direction: row;
  align-items: flex-start;
  padding: 10px;
  justify-content: center;
`;

const StyledCheckBox = styled(CheckBox)`
  height: 17px;
  width: 17px;
  margin-top: 4px;
`;

const TextContainer = styled.View`
  flex-direction: column;
  margin-left: 2px;
`;

const StyledText = styled.Text`
  font-size: 16px;
  line-height: 22px;
  width: 250px;
  font-family: 'MarkOffcPro';
  text-align: ${(props) => (props.setLeft ? 'left' : 'center')};
  margin-left: ${(props) => (props.setLeft ? 10 : 0)}px;
`;

const ErrorText = styled.Text`
  font-size: 12px;
  color: red;
  font-weight: 400;
  font-family: 'Montserrat';
  padding-top: 8px;
  text-align: center;
`;

const Checkbox = ({ title, formikKey, formikProps, ...rest }) => {
  const { disabled, labelLeft } = rest;
  const shopTheme = useTheme();
  return (
    <Container>
      <>
        <StyledCheckBox
          offAnimationType="flat"
          onAnimationType="flat"
          lineWidth={1.5}
          boxType="square"
          onTintColor={
            disabled === true
              ? theme.colors.lightGrey
              : shopTheme.colors.primary || theme.colors.primary
          }
          tintColors={{
            true:
              disabled === true
                ? theme.colors.lightGrey
                : shopTheme.colors.primary || theme.colors.primary
          }}
          onCheckColor={
            disabled === true
              ? theme.colors.lightGrey
              : shopTheme.colors.primary || theme.colors.primary
          }
          value={formikProps.values[formikKey]}
          onValueChange={(value) => {
            formikProps.setFieldValue(formikKey, value);
          }}
          {...rest}
        />
        <TextContainer>
          <StyledText setLeft={labelLeft}>{title}</StyledText>

          {formikProps.touched[formikKey] && formikProps.errors[formikKey] && (
            <ErrorText>
              {formikProps.touched[formikKey] && formikProps.errors[formikKey]}
            </ErrorText>
          )}
        </TextContainer>
      </>
    </Container>
  );
};

Checkbox.propTypes = {
  title: PropTypes.string.isRequired,
  formikProps: PropTypes.objectOf(PropTypes.any).isRequired,
  formikKey: PropTypes.string.isRequired
};

export default Checkbox;
