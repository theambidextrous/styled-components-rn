import React, { useState } from 'react';
import { Keyboard } from 'react-native';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import DropDownPicker from 'react-native-dropdown-picker';
import theme from '@utils/theme';

const ErrorText = styled.Text`
  font-size: 12px;
  color: red;
  font-weight: 400;
  font-family: 'MarkOffcPro';
  margin-left: 8px;
  margin-bottom: 16px;
`;

const DropDown = ({
  value,
  items,
  setValue,
  onChangeValue,
  setItems,
  formikProps,
  formikKey,
  ...rest
}) => {
  const [open, setOpen] = useState(false);
  return (
    <>
      <DropDownPicker
        listMode="SCROLLVIEW"
        onOpen={() => {
          Keyboard.dismiss();
        }}
        style={{
          backgroundColor: theme.colors.backgroundColor,
          minWidth: 50,
          paddingHorizontal: 20,
          borderRadius: 22,
          borderWidth: 0,
          borderStyle: 'solid',
          borderColor: '#e6e6e7',
          marginBottom: 15,
          height: 44
        }}
        dropDownStyle={{
          color: theme.colors.textPrimary,
          lineHeight: 24,
          borderColor: 'none'
        }}
        textStyle={{
          fontSize: 18,
          fontFamily: 'MarkOffcPro',
          color: theme.colors.textPrimary,
          lineHeight: 24
        }}
        labelStyle={{
          fontFamily: 'MarkOffcPro',
          color: theme.colors.textPrimary
        }}
        dropDownContainerStyle={{
          borderColor: '#e6e6e7'
        }}
        searchTextInputStyle={{
          borderColor: '#e6e6e7',
          fontSize: 16
        }}
        listItemLabelStyle={{
          fontSize: 16
        }}
        searchContainerStyle={{
          borderBottomColor: '#e6e6e7',
          borderColor: '#e6e6e7'
        }}
        customItemContainerStyle={{
          backgroundColor: '#e6e6e7',
          borderColor: '#e6e6e7'
        }}
        customItemLabelStyle={{
          fontStyle: 'italic'
        }}
        placeholder="Select state"
        open={open}
        value={value}
        items={items}
        setOpen={setOpen}
        setValue={setValue}
        onChangeValue={(item) => onChangeValue(item)}
        setItems={setItems}
        {...rest}
      />
      {formikProps.touched[formikKey] && formikProps.errors[formikKey] && (
        <ErrorText>
          {formikProps.touched[formikKey] && formikProps.errors[formikKey]}
        </ErrorText>
      )}
    </>
  );
};

DropDown.defaultProps = {
  value: null
};

DropDown.propTypes = {
  value: PropTypes.string,
  items: PropTypes.array.isRequired,
  setValue: PropTypes.func.isRequired,
  onChangeValue: PropTypes.func.isRequired,
  setItems: PropTypes.func.isRequired,
  formikProps: PropTypes.objectOf(PropTypes.any).isRequired,
  formikKey: PropTypes.string.isRequired
};

export default DropDown;
