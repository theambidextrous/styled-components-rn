import React from 'react';
import styled from 'styled-components/native';
import { theme } from '@utils';

const Container = styled.View`
  border-bottom-width: 1px;
  border-bottom-color: ${theme.colors.border};
  width: 100%;
  padding: 2px 0;
`;

const Divider = () => <Container />;

export default Divider;
