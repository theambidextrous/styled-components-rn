import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet } from 'react-native';
import styled from 'styled-components/native';
import { theme, getTierBadge } from '@utils';

import MemberShipIcon from '../Dashboard/MemberShipIcon';
import Text from '../Text';

const Container = styled.View`
  background-color: ${(props) => props.backgroundColor};
  margin: 0px 20px 20px 20px;
  border-radius: 8px;
`;

const Wrapper = styled.View`
  padding: 20px;
  flex-direction: row;
  align-items: center;
`;

const TierWrapper = styled.View`
  flex-direction: column;
  margin-left: 16px;
`;
const BadgeWrapper = styled.View``;

const styles = StyleSheet.create({
  nextTierText: {
    color: theme.colors.textPrimary,
    fontFamily: 'Montserrat-ExtraBold',
    fontSize: 16,
    lineHeight: 24,
    textAlign: 'left'
  },
  nextTierPointsText: {
    color: theme.colors.textPrimary,
    textAlign: 'left',
    fontSize: 12,
    lineHeight: 18,
    fontFamily: 'Montserrat-Medium'
  }
});
const getTierHeaderColor = (tier = 'bronze') => {
  switch (tier.toUpperCase()) {
    case 'BRONZE':
      return theme.colors.bronzeTier;
    case 'SILVER':
      return theme.colors.platinumTier;
    case 'GOLD':
      return theme.colors.goldTier;
    case 'PLATINUM':
      return theme.colors.platinumTier;
    default:
      return theme.colors.bronzeTier;
  }
};

const NextTierCard = ({ nextTier, nextTierRemainingPoints, ...props }) => (
  <Container backgroundColor={getTierHeaderColor(nextTier)} {...props}>
    <Wrapper>
      <BadgeWrapper>
        <MemberShipIcon
          style={{ width: 50, height: 50 }}
          source={getTierBadge(nextTier)}
        />
      </BadgeWrapper>
      <TierWrapper>
        <Text as="H3" style={styles.nextTierText}>
          {`${nextTier} Loyalty Tier`}
        </Text>
        <Text as="P4" style={styles.nextTierPointsText}>
          {`Earn ${nextTierRemainingPoints} points to unlock`}
        </Text>
      </TierWrapper>
    </Wrapper>
  </Container>
);

NextTierCard.propTypes = {
  nextTier: PropTypes.string.isRequired,
  nextTierRemainingPoints: PropTypes.number.isRequired
};
export default NextTierCard;
