import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet } from 'react-native';
import styled from 'styled-components/native';
import { theme, getTierBadge } from '@utils';
import Text from '../Text';
import MemberShipIcon from '../Dashboard/MemberShipIcon';

const Container = styled.View`
  background-color: ${theme.colors.mediumBlack};
  margin: 20px;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  border-radius: 8px;
`;

const Wrapper = styled.View`
  padding: 20px;
`;

const TextWrapper = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;

const TierWrapper = styled.View`
  margin-top: 16px; ;
`;

const BadgeWrapper = styled.View`
  align-items: center;
  justify-content: center;
`;

const styles = StyleSheet.create({
  titleText: {
    color: theme.colors.textWhite,
    textTransform: 'uppercase',
    fontSize: 22,
    textAlign: 'center'
  },
  pointsText: {
    color: theme.colors.primary,
    textTransform: 'uppercase',
    textAlign: 'center',
    fontSize: 18,
    lineHeight: 24,
    marginRight: 8
  },
  pointsTitle: {
    color: theme.colors.textWhite,
    textTransform: 'uppercase',
    textAlign: 'center',
    fontSize: 14,
    fontWeight: '600'
  },
  TierTitle: {
    color: theme.colors.textWhite,
    textTransform: 'uppercase',
    textAlign: 'center',
    fontFamily: 'Montserrat-Regular',
    fontSize: 14,
    fontWeight: '500'
  }
});

const PointsBanner = ({ tierName, tierPoints, spendablePoints }) => (
  <Container>
    <Wrapper>
      <BadgeWrapper>
        <MemberShipIcon
          style={{ width: 60, height: 60 }}
          source={getTierBadge(tierName)}
        />
      </BadgeWrapper>
      <Text style={styles.titleText} as="H1">
        You have
      </Text>
      <TextWrapper>
        <Text style={styles.pointsText} as="H1">
          {tierPoints}
        </Text>
        <Text style={styles.pointsTitle} as="P3">
          Tier Points
        </Text>
      </TextWrapper>
      <TextWrapper>
        <Text style={styles.pointsText} as="H1">
          {spendablePoints}
        </Text>
        <Text style={styles.pointsTitle} as="P3">
          Spendable Points
        </Text>
      </TextWrapper>
      <TierWrapper>
        <Text style={styles.TierTitle} as="P3">
          You are currently on
        </Text>
        <Text style={styles.TierTitle} as="P3">
          {`${tierName} loyalty tier`}
        </Text>
      </TierWrapper>
    </Wrapper>
  </Container>
);
PointsBanner.propTypes = {
  tierName: PropTypes.string.isRequired,
  tierPoints: PropTypes.number.isRequired,
  spendablePoints: PropTypes.number.isRequired
};
export default PointsBanner;
