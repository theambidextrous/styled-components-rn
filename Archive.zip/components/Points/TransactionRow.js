import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';

import { theme, DEVICE_WIDTH } from '@utils/index';
import Text from '../Text';

const Container = styled.View`
  flex-direction: row;
  border-bottom-width: 0.5px;
  border-bottom-color: ${theme.colors.border};
  background-color: ${theme.colors.backgroundLight};
  align-items: center;
  justify-content: space-between;
  padding: 20px 20px 0 20px;
`;
const PointsPill = styled.View`
  align-items: center;
  justify-content: center;
  border-radius: 22px;
  background-color: ${(props) =>
    props.theme.colors.primary || theme.colors.primary};
`;
const PointsWrapper = styled.View``;
const HeaderWrapper = styled.View`
  flex-direction: column;
  padding: 0 0 10px 0;
`;

const nameTextStyle = {
  fontFamily: 'Montserrat-SemiBold',
  width: DEVICE_WIDTH * 0.62,
  textAlign: 'left',
  fontSize: 14,
  lineHeight: 18,
  marginBottom: 4,
  color: theme.colors.textPrimary
};

const dateTextStyle = {
  color: theme.colors.textPrimary,
  fontSize: 13,
  fontWeight: '400',
  fontFamily: 'MarkOffcPro'
};

const pointsTextStyle = {
  color: theme.colors.textWhite,
  fontSize: 14,
  fontFamily: 'Montserrat-SemiBold',
  textAlign: 'center',
  paddingHorizontal: 10,
  paddingVertical: 4
};

const PointsTransaction = ({
  transactionName,
  transactionDate,
  transactionPoints
}) => (
  <Container>
    <HeaderWrapper>
      <Text
        style={nameTextStyle}
        as="H3"
        ellipsizeMode="tail"
        numberOfLines={1}
      >
        {transactionName}
      </Text>
      <Text style={dateTextStyle} as="H4">
        {transactionDate}
      </Text>
    </HeaderWrapper>
    <PointsWrapper>
      <PointsPill>
        {transactionPoints > 0 ? (
          <Text style={pointsTextStyle} as="H3">
            {`+${transactionPoints} pts`}
          </Text>
        ) : (
          <Text style={pointsTextStyle} as="H3">
            {`${transactionPoints} pts`}
          </Text>
        )}
      </PointsPill>
    </PointsWrapper>
  </Container>
);
PointsTransaction.propTypes = {
  transactionName: PropTypes.string.isRequired,
  transactionDate: PropTypes.string.isRequired,
  transactionPoints: PropTypes.number.isRequired
};

export default PointsTransaction;
