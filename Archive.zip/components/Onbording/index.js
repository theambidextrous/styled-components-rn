import {
  SwiperButtonIcon,
  SwiperButtonText,
  SwiperContent,
  SwiperImage,
  SwiperTextIconWraper,
  SwiperTitle,
  DotsComponent
} from './Swiper';

export {
  SwiperButtonIcon,
  SwiperButtonText,
  SwiperContent,
  SwiperImage,
  SwiperTextIconWraper,
  SwiperTitle,
  DotsComponent
};
