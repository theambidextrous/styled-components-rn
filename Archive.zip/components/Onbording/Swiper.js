import { theme } from '@utils';
import React from 'react';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import * as Styles from '@components/Onbording/Swiper.styles';

const circularDotImage = require('@assets/images/tutorial/circular_dot.png');
const buttonDotImage = require('@assets/images/tutorial/button_dot.png');

export const SwiperButtonIcon = ({ ...props }) => (
  <Styles.StyledSwiperButtonIcon {...props} />
);
export const SwiperTextIconWraper = ({ children }) => (
  <Styles.StyledViewWrapper>{children}</Styles.StyledViewWrapper>
);
SwiperTextIconWraper.propTypes = {
  children: PropTypes.arrayOf(PropTypes.any).isRequired
};

export const SwiperImage = ({ source }) => (
  <Styles.StyledOnboardingPageImage source={source} resizeMode="contain" />
);
SwiperImage.propTypes = {
  source: PropTypes.any.isRequired
};

export const SwiperTitle = ({ title }) => (
  <Styles.StyledTitleText>{title}</Styles.StyledTitleText>
);
SwiperTitle.propTypes = {
  title: PropTypes.string.isRequired
};

export const SwiperContent = ({ content }) => (
  <Styles.StyledContentText>{content}</Styles.StyledContentText>
);
SwiperContent.propTypes = {
  content: PropTypes.string.isRequired
};

export const SwiperButtonText = ({ label, isFilled }) => {
  const StyledButtonText = styled.Text`
    color: ${isFilled ? theme.colors.textWhite : theme.colors.textBlack};
    height: 22px;
    font-family: Montserrat;
    font-style: normal;
    font-weight: 700;
    font-size: 18px;
    line-height: 22px;
    text-align: center;
    align-items: center;
    justify-content: center;
  `;
  return <StyledButtonText>{label}</StyledButtonText>;
};
SwiperButtonText.propTypes = {
  label: PropTypes.string.isRequired,
  isFilled: PropTypes.bool.isRequired
};

export const DotsComponent = ({ selected }) => {
  if (selected === true) {
    return <Styles.StyledImage resizeMode="contain" source={buttonDotImage} />;
  }
  return <Styles.StyledImage resizeMode="contain" source={circularDotImage} />;
};
DotsComponent.propTypes = {
  selected: PropTypes.bool.isRequired
};
