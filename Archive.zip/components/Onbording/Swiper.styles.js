import { Dimensions } from 'react-native';
import styled from 'styled-components/native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { theme } from '@utils';

export const StyledOnboardingPageImage = styled.Image`
  width: 100%;
  max-width: ${Dimensions.get('screen').height * 0.35}px;
  height: 200px;
  margin-bottom: 30px;
  margin-top: 40px;
`;

export const StyledTitleText = styled.Text`
  font-size: 24px;
  line-height: 28px;
  text-align: center;
  font-family: MontrealSerialBold;
  color: ${theme.colors.textBlack};
  margin-bottom: 15px;
`;

export const StyledContentText = styled.Text`
  font-size: 19px;
  text-align: center;
  font-weight: normal;
  line-height: 23px;
  font-family: Montreal Regular;
  color: ${theme.colors.textDarkGrey};
  padding: 0px 34px 0px 34px;
  width: ${Dimensions.get('window').width * 0.85}px;
  margin-bottom: 80px;
`;

export const StyledImage = styled.Image`
  width: 20px;
  position: relative;
  bottom: 80px;
`;

export const StyledViewWrapper = styled.View`
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;

export const StyledSwiperButtonIcon = styled(Icon)`
  color: ${theme.colors.textWhite};
`;
