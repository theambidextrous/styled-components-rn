import React from 'react';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import theme from '@utils/theme';

const Container = styled.View`
  flex-direction: column;
  margin-top: 24px;
`;

const StyledTitle = styled.Text`
  font-size: 24px;
  line-height: 36px;
  margin-bottom: 4px;
  color: ${theme.colors.textPrimary};
  font-family: 'Montserrat-ExtraBold';
`;

const StyledSubtitle = styled.Text`
  font-size: 14px;
  line-height: 18px;
  font-family: 'MarkOffcPro';
  color: ${theme.colors.textSecondary};
`;

const SectionText = ({ title, subTitle }) => (
  <Container>
    <StyledTitle>{title}</StyledTitle>
    {subTitle && <StyledSubtitle>{subTitle}</StyledSubtitle>}
  </Container>
);

SectionText.defaultProps = {
  subTitle: ''
};

SectionText.propTypes = {
  title: PropTypes.string.isRequired,
  subTitle: PropTypes.string
};

export default SectionText;
