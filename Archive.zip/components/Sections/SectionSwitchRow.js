import React from 'react';
import { Platform, StyleSheet } from 'react-native';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import theme from '@utils/theme';
import { useTheme } from 'styled-components';

const Container = styled.View`
  flex-direction: row;
  align-items: center;
  min-height: 60px;
  justify-content: space-between;
`;

const StyledText = styled.Text`
  font-size: 18px;
  line-height: 24px;
  color: ${theme.colors.textPrimary};
  font-family: 'MarkOffcPro';
`;

const StyledSwitch = styled.Switch`
  align-items: center;
  justify-content: center;
`;

const SectionOffers = ({ title, formikProps, formikKey }) => {
  const shopTheme = useTheme();

  return (
    <Container>
      <StyledText>{title}</StyledText>

      <StyledSwitch
        value={formikProps.values[formikKey]}
        trackColor={{
          false: '#767577',
          true: shopTheme.colors.primary || theme.colors.primary
        }}
        thumbColor="#f4f3f4"
        onValueChange={(value) => {
          formikProps.setFieldValue(formikKey, value);
          if (formikKey === 'daily' && value === true) {
            formikProps.setFieldValue('weekly', false);
            formikProps.setFieldValue('monthly', false);
            formikProps.setFieldValue('offersPreference', 'DAILY');
          }
          if (formikKey === 'weekly' && value === true) {
            formikProps.setFieldValue('daily', false);
            formikProps.setFieldValue('monthly', false);
            formikProps.setFieldValue('offersPreference', 'WEEKLY');
          }
          if (formikKey === 'monthly' && value === true) {
            formikProps.setFieldValue('weekly', false);
            formikProps.setFieldValue('daily', false);
            formikProps.setFieldValue('offersPreference', 'MONTHLY');
          }
        }}
        style={Jsx.switchTransform}
      />
    </Container>
  );
};

const SectionNotifications = ({
  title,
  formikProps,
  formikKey,
  push,
  remove
}) => {
  const shopTheme = useTheme();
  return (
    <Container>
      <StyledText>{title}</StyledText>
      <StyledSwitch
        value={formikProps.values[formikKey]}
        thumbColor="#f4f3f4"
        trackColor={{
          false: '#767577',
          true: shopTheme.colors.primary || theme.colors.primary
        }}
        onValueChange={(value) => {
          formikProps.setFieldValue(formikKey, value);
          if (formikKey === 'allNotifications' && value === true) {
            formikProps.setFieldValue('emailNotification', true);
            formikProps.setFieldValue('smsNotification', true);
            formikProps.setFieldValue('inAppNotification', true);
            // update the notificationChannels state by adding the
            // values to the end of an array.
            // push: (obj: any) => void:
            push('EMAIL');
            push('SMS');
            push('IN_APP_NOTIFICATIONS');
          }
          if (formikKey === 'allNotifications' && value === false) {
            formikProps.setFieldValue('emailNotification', false);
            formikProps.setFieldValue('smsNotification', false);
            formikProps.setFieldValue('inAppNotification', false);
            // when all are toggled off just return an empty array and update
            // the notificationChannels state instead of removing each.
            formikProps.setFieldValue('notificationChannels', []);
          }

          if (formikKey === 'emailNotification' && value === true) {
            push('EMAIL');
          }
          if (formikKey === 'emailNotification' && value === false) {
            formikProps.setFieldValue('allNotifications', false);
            // here we remove the index of the item and not the object itself
            // TODO: find a cleaner way to make the code below more DRY.
            remove(formikProps.values.notificationChannels.indexOf('EMAIL'));
          }
          if (formikKey === 'smsNotification' && value === true) {
            push('SMS');
          }
          if (formikKey === 'smsNotification' && value === false) {
            formikProps.setFieldValue('allNotifications', false);
            remove(formikProps.values.notificationChannels.indexOf('SMS'));
          }
          if (formikKey === 'inAppNotification' && value === true) {
            push('IN_APP_NOTIFICATIONS');
          }
          if (formikKey === 'inAppNotification' && value === false) {
            formikProps.setFieldValue('allNotifications', false);
            remove(
              formikProps.values.notificationChannels.indexOf(
                'IN_APP_NOTIFICATIONS'
              )
            );
          }
        }}
        style={Jsx.switchTransform}
      />
    </Container>
  );
};

const Jsx = StyleSheet.create({
  switchTransform: {
    transform: [
      { scaleX: Platform.OS === 'ios' ? 0.9 : 1.1 },
      { scaleY: Platform.OS === 'ios' ? 0.9 : 1.1 }
    ]
  }
});
SectionOffers.propTypes = {
  title: PropTypes.string.isRequired,
  formikProps: PropTypes.objectOf(PropTypes.any).isRequired,
  formikKey: PropTypes.string.isRequired
};

SectionNotifications.propTypes = {
  title: PropTypes.string.isRequired,
  formikProps: PropTypes.objectOf(PropTypes.any).isRequired,
  formikKey: PropTypes.string.isRequired,
  push: PropTypes.func.isRequired,
  remove: PropTypes.func.isRequired
};
export { SectionOffers, SectionNotifications };
