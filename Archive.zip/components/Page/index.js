import PageBodyFiltersHolder from './PageBodyFiltersHolder';
import PageBodyTitleHolder from './PageBodyTitleHolder';

export { PageBodyFiltersHolder, PageBodyTitleHolder };
