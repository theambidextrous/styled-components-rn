import React from 'react';
import { View, StyleSheet } from 'react-native';
import PropTypes from 'prop-types';
import { theme } from '@utils/';
import { ShopActionsText } from '../Shop';

const PageBodyTitleHolder = ({ title, subtitle }) => (
  <View style={Styles.titleView}>
    <ShopActionsText
      text={title}
      size={30}
      lineHeight={36}
      weight={700}
      transform="none"
      color={theme.colors.textPrimary}
    />
    <ShopActionsText
      text={subtitle}
      size={14}
      lineHeight={18}
      weight={400}
      transform="none"
      color={theme.colors.textSecondary}
    />
  </View>
);
PageBodyTitleHolder.propTypes = {
  title: PropTypes.string,
  subtitle: PropTypes.string
};
PageBodyTitleHolder.defaultProps = {
  title: 'bold title',
  subtitle: 'thin title'
};

const Styles = StyleSheet.create({
  titleView: {
    marginHorizontal: 10
  }
});

export default PageBodyTitleHolder;
