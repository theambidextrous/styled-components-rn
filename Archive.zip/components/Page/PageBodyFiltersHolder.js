import React from 'react';
import { TouchableOpacity, StyleSheet } from 'react-native';
import PropTypes from 'prop-types';
import { theme } from '@utils/';
import { useTheme } from 'styled-components';
import MIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import styled from 'styled-components/native';
import { ShopActionsText } from '../Shop';

const allImage = require('@assets/images/others/all.png');

const FilterIconsMapper = [
  'view-agenda-outline',
  'view-grid-outline',
  'checkbox-blank-outline'
];
const PageBodyFiltersHolder = ({ active, ActiveStateHandler }) => {
  const shopTheme = useTheme();
  return (
    <StyledPageBodyFiltersOuterHolder style={Styles.titleView}>
      <StyledPageBodyFiltersInnerLeft>
        <StyledAllIcon source={allImage} />
        <ShopActionsText
          text="All"
          size={16}
          lineHeight={20}
          weight={500}
          transform="none"
          color={theme.colors.textPrimary}
        />
      </StyledPageBodyFiltersInnerLeft>
      <StyledPageBodyFiltersInnerRight>
        {FilterIconsMapper.map((name, key) => (
          <TouchableOpacity key={key} onPress={() => ActiveStateHandler(key)}>
            <MIcon
              style={Styles.iconFilter}
              name={name}
              size={24}
              color={
                key === active
                  ? shopTheme.colors.primary || theme.colors.primary
                  : theme.colors.textPrimary
              }
            />
          </TouchableOpacity>
        ))}
      </StyledPageBodyFiltersInnerRight>
    </StyledPageBodyFiltersOuterHolder>
  );
};
PageBodyFiltersHolder.propTypes = {
  active: PropTypes.number,
  ActiveStateHandler: PropTypes.func
};
PageBodyFiltersHolder.defaultProps = {
  active: 0,
  ActiveStateHandler: () => null
};

const StyledPageBodyFiltersOuterHolder = styled.View`
  flex-direction: row;
  height: 42px;
  border-bottom-width: 0.5px;
  border-bottom-color: ${theme.colors.border};
`;
const StyledPageBodyFiltersInnerLeft = styled.View`
  flex-direction: row;
  flex: 1;
  justify-content: flex-start;
  align-items: center;
`;
const StyledPageBodyFiltersInnerRight = styled.View`
  flex-direction: row;
  flex: 1;
  justify-content: flex-end;
  align-items: center;
`;
const StyledAllIcon = styled.Image`
  height: 22px;
  width: 22px;
  margin-right: 12px;
`;

const Styles = StyleSheet.create({
  titleView: {
    marginHorizontal: 0,
    marginTop: 15,
    paddingLeft: 20,
    paddingRight: 10
  },
  allIcon: {
    borderWidth: 1,
    borderColor: theme.colors.border,
    width: 23,
    height: 23,
    marginRight: 10
  },
  iconFilter: {
    marginRight: 10
  }
});

export default PageBodyFiltersHolder;
