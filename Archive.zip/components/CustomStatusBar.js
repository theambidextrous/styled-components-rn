import React from 'react';
import { StatusBar } from 'react-native';
import { theme } from '@utils';
import PropTypes from 'prop-types';

const CustomStatusBar = ({ isLightContent }) => (
  <StatusBar
    translucent
    animated={false}
    backgroundColor={theme.colors.none}
    barStyle={isLightContent ? 'light-content' : 'dark-content'}
  />
);
CustomStatusBar.propTypes = {
  isLightContent: PropTypes.bool.isRequired
};
export default CustomStatusBar;
