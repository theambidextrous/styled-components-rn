import styled from 'styled-components/native';
import { theme, DEVICE_WIDTH } from '@utils';

export const Container = styled.View`
  border-bottom-width: 1px;
  border-bottom-color: ${theme.colors.border};
  padding: 20px;
`;

export const Wrapper = styled.View`
  flex-direction: row;
  align-items: center;
  margin-bottom: 15px;
`;

export const ProductImage = styled.Image`
  background-color: ${theme.colors.backgroundLight};
  border-radius: 6px;
  width: 100px;
  height: 100px;
  padding: 2px 0;
  border-color: ${theme.colors.backgroundColor};
`;

export const DetailsWrapper = styled.View`
  flex-direction: column;
  margin-left: 12px;
`;

export const RemoveButton = styled.TouchableOpacity`
  position: relative;
  bottom: 16px;
  width: 40px;
  height: 40px;
  margin-left: auto;
  background-color: ${theme.colors.danger};
  border-radius: 40px;
  align-items: center;
  justify-content: center;
`;

export const AttributeSection = styled.View`
  flex-direction: row;
  justify-content: space-between;
`;

export const Pill = styled.TouchableOpacity`
  flex-direction: row;
  background-color: ${theme.colors.backgroundColor};
  padding: 10px 24px 10px 24px;
  border-radius: 22px;
  align-items: center;
  width: ${DEVICE_WIDTH * 0.27}px;
`;

export const ColorCircle = styled.View`
  background-color: ${(props) => props.color}
  padding: 12px;
  border-radius: 12px;
`;

export const DropDownIcon = styled.View`
  margin-left: auto;
`;

export const categoryStyles = {
  marginBottom: 12,
  fontSize: 14,
  width: 170,
  alignSelf: 'flex-start'
};
