import React from 'react';
import FastImage from 'react-native-fast-image';
import { StyleSheet } from 'react-native';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';

import { theme } from '@utils';
import Text from '../Text';

const skuArtwork = require('@assets/images/others/sku2.png');

const SKuImage = styled(FastImage)`
  padding: 2px 4px;
`;

const Container = styled.View`
  border-radius: 10px;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin: 0 6px;
`;

const Wrapper = styled.View`
  flex-direction: column;
  align-items: center;
  padding: 6px 16px;
`;

const RedeemButton = styled.TouchableOpacity`
  padding: 6px 12px;
  background-color: ${(props) =>
    props.isDark ? theme.colors.black : theme.colors.black};
  border-radius: 20px;
  align-self: flex-start;
`;

export const OfferImage = styled.Image`
  border-radius: 4px;
  width: 80px;
  height: 60px;
`;
const headlineStyles = {
  textTransform: 'uppercase',
  fontSize: 14,
  lineHeight: 28,
  color: theme.colors.black
};
const buttonStyles = {
  textTransform: 'uppercase',
  fontSize: 10,
  lineHeight: 12,
  color: theme.colors.textWhite
};

const OfferBanner = ({ offer, onPressHandler, isDark }) =>
  offer.active === true && (
    <SKuImage
      source={skuArtwork}
      defaultSource={skuArtwork}
      imageStyle={[StyleSheet.absoluteFill]}
      // resizeMode=""
    >
      <Container>
        <Wrapper>
          <Text as="H1" style={headlineStyles}>
            {offer.headline}
          </Text>
          <RedeemButton isDark={isDark} onPress={() => onPressHandler(offer)}>
            <Text as="H1" style={buttonStyles}>
              Redeem offer
            </Text>
          </RedeemButton>
        </Wrapper>
        <OfferImage source={{ uri: offer.artwork }} resizeMode="contain" />
      </Container>
    </SKuImage>
  );

OfferBanner.propTypes = {
  offer: PropTypes.objectOf(PropTypes.any).isRequired,
  onPressHandler: PropTypes.func.isRequired,
  isDark: PropTypes.bool
};
OfferBanner.defaultProps = {
  isDark: false
};

export default OfferBanner;
