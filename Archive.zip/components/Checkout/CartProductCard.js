import React from 'react';
import Icon from 'react-native-vector-icons/MaterialIcons';
import PropTypes from 'prop-types';
import { useTheme } from 'styled-components';

import { theme } from '@utils';
import Text from '../Text';

import {
  Container,
  Wrapper,
  ProductImage,
  DetailsWrapper,
  RemoveButton,
  AttributeSection,
  Pill,
  categoryStyles,
  ColorCircle,
  DropDownIcon
} from './Checkout.styles';

// check for colors and sizes that are empty to prevent the app from breaking
function isString(value) {
  return typeof value === 'string' || value instanceof String;
}

const ExpandMore = () => (
  <DropDownIcon>
    <Icon
      name="expand-more"
      size={24}
      style={{
        color: theme.colors.textBlack
      }}
    />
  </DropDownIcon>
);

const CartProductCard = ({
  image,
  title,
  category,
  price,
  onRemove,
  size,
  color,
  quantity,
  onQuantityPress,
  onColorPress,
  onSizePress
}) => {
  // theme
  const shopTheme = useTheme();
  return (
    <Container>
      <Wrapper>
        <ProductImage source={{ uri: image }} resizeMode="contain" />
        <DetailsWrapper>
          <Text
            as="H4"
            style={{ fontWeight: '500', width: 170 }}
            ellipsizeMode="tail"
            numberOfLines={1}
          >
            {isString(title) && title}
          </Text>
          <Text style={categoryStyles} ellipsizeMode="tail" numberOfLines={1}>
            {isString(category) && category}
          </Text>
          <Text
            style={{
              fontWeight: '500',
              color: shopTheme.colors.primary || theme.colors.primary
            }}
          >
            {`$${price}`}
          </Text>
        </DetailsWrapper>
        <RemoveButton onPress={onRemove}>
          <Icon
            name="close"
            size={24}
            style={{
              color: theme.colors.textWhite
            }}
          />
        </RemoveButton>
      </Wrapper>
      <AttributeSection>
        <Pill onPress={onQuantityPress}>
          <Text as="P1">{`${quantity}`}</Text>
          <ExpandMore />
        </Pill>
        {isString(color) && (
          <Pill onPress={onColorPress}>
            <ColorCircle color={color.toLowerCase()} />
            <ExpandMore />
          </Pill>
        )}
        {isString(size) && (
          <Pill onPress={onSizePress}>
            <Text as="P1">{size}</Text>
            <ExpandMore />
          </Pill>
        )}
      </AttributeSection>
    </Container>
  );
};
CartProductCard.defaultProps = {
  size: '',
  color: ''
};

CartProductCard.propTypes = {
  image: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  category: PropTypes.string.isRequired,
  price: PropTypes.string.isRequired,
  onRemove: PropTypes.func.isRequired,
  size: PropTypes.string,
  color: PropTypes.string,
  quantity: PropTypes.number.isRequired,
  onSizePress: PropTypes.func.isRequired,
  onColorPress: PropTypes.func.isRequired,
  onQuantityPress: PropTypes.func.isRequired
};

export default CartProductCard;
