import React from 'react';
import { TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { useTheme } from 'styled-components';

import { theme } from '@utils';
import Text from '../Text';

const Container = styled.View`
  flex-direction: column;
  border-bottom-width: 1px;
  border-bottom-color: ${theme.colors.border};
`;

const Wrapper = styled.View`
  padding: 20px;
`;

const HeaderWraper = styled.View`
  flex-direction: row;
  justify-content: space-between;
  padding: 0 0 10px 0;
`;

const ConfirmationDetailsRow = ({
  header,
  subHeader,
  onPress,
  isFullLength
}) => {
  const shopTheme = useTheme();
  return (
    <Container>
      <Wrapper>
        <HeaderWraper>
          <Text style={{ fontFamily: 'Montserrat-Bold' }} as="H4">
            {header}
          </Text>
          <TouchableOpacity onPress={onPress}>
            <Text
              style={{
                color: shopTheme.colors.primary || theme.colors.primary
              }}
            >
              Edit
            </Text>
          </TouchableOpacity>
        </HeaderWraper>
        <>
          <Text
            style={{ width: isFullLength ? '100%' : 213, alignItems: 'center' }}
            as="P3"
          >
            {subHeader}
          </Text>
        </>
      </Wrapper>
    </Container>
  );
};

ConfirmationDetailsRow.propTypes = {
  header: PropTypes.string.isRequired,
  subHeader: PropTypes.any.isRequired,
  onPress: PropTypes.func,
  isFullLength: PropTypes.bool
};

ConfirmationDetailsRow.defaultProps = {
  onPress: () => null,
  isFullLength: false
};

export default ConfirmationDetailsRow;
