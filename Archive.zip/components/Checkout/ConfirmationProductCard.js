import React from 'react';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import { useTheme } from 'styled-components';

import { theme } from '@utils';
import Text from '@components/Text';

const Container = styled.View``;

const Wrapper = styled.View`
  flex-direction: row;
  padding: 20px;
  align-items: flex-start;
`;

const ProductImage = styled.Image`
  background-color: ${theme.colors.backgroundLight};
  border-radius: 6px;
  width: 100px;
  height: 110px;
  /* border: 1px; */
  padding: 2px 0;
  border-color: ${theme.colors.backgroundColor};
`;

const ProductDetails = styled.View`
  flex-direction: column;
  margin-left: 15px;
  width: 180px;
`;

const PriceDetails = styled.View`
  flex-direction: column;
  margin-left: auto;
`;

const categoryStyles = {
  alignSelf: 'flex-start',
  marginBottom: 5
};
const skuTextStyles = {
  color: theme.colors.textSecondary
};
const ConfirmationProductCard = ({
  image,
  title,
  category,
  price,
  size,
  color,
  quantity
}) => {
  const shopTheme = useTheme();

  const priceStyle = {
    color: shopTheme.colors.primary || theme.colors.primary,
    fontFamily: 'Montserrat-Medium',
    fontWeight: '600',
    textAlign: 'right',
    alignSelf: 'flex-start'
  };
  return (
    <Container>
      <Wrapper>
        <ProductImage source={{ uri: image }} resizeMode="cover" />
        <ProductDetails>
          <Text as="H4" ellipsizeMode="tail" numberOfLines={1}>
            {title}
          </Text>
          <Text
            as="P3"
            style={categoryStyles}
            ellipsizeMode="tail"
            numberOfLines={1}
          >
            {category}
          </Text>
          {size && <Text as="P3" style={skuTextStyles}>{`Size: ${size}`}</Text>}
          {color && (
            <Text as="P3" style={skuTextStyles}>{`Color: ${color}`}</Text>
          )}
          <Text as="P3" style={skuTextStyles}>{`Quantity: x${quantity}`}</Text>
        </ProductDetails>
        <PriceDetails>
          <Text style={priceStyle} as="P1">
            {`$${price}`}
          </Text>
          {/* <Text style={discountPriceStyle} as="P1">
          {money(0)}
        </Text> */}
        </PriceDetails>
      </Wrapper>
    </Container>
  );
};

ConfirmationProductCard.defaultProps = {
  size: '',
  color: ''
};

ConfirmationProductCard.propTypes = {
  image: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  category: PropTypes.string.isRequired,
  price: PropTypes.string.isRequired,
  size: PropTypes.string,
  color: PropTypes.string,
  quantity: PropTypes.number.isRequired
};

export default ConfirmationProductCard;
