import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components/native';
import { ifIphoneX } from 'react-native-iphone-x-helper';
import { useTheme } from 'styled-components';

import { theme } from '@utils';
import { PrimaryButton } from '@components/Button';
import Text from '@components/Text';

const Container = styled.View`
  background-color: ${theme.colors.checkoutRowBg};
  padding: 16px 20px 16px 20px;
`;

const Wrapper = styled.View`
  margin-bottom: 18px;
`;

const OrderWrapper = styled.View`
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
`;

const CheckoutRow = ({
  onPress,
  totalAmount,
  btnText,
  loading,
  disabled,
  discountedAmount,
  isDark
}) => {
  const shopTheme = useTheme();
  return (
    <Container
      style={{
        ...ifIphoneX(
          {
            paddingBottom: 26
          },
          {
            paddingBottom: 16
          }
        )
      }}
    >
      <Wrapper>
        <OrderWrapper>
          <Text as="H3">Order amount:</Text>
          <Text
            style={
              isDark
                ? { color: theme.colors.black }
                : { color: shopTheme.colors.primary || theme.colors.primary }
            }
            as="H3"
          >
            {`$${totalAmount}`}
          </Text>
        </OrderWrapper>
        {Number(discountedAmount) > 0 && (
          <OrderWrapper>
            <Text style={{ color: theme.colors.textSecondary }} as="P3">
              Your total discount:
            </Text>
            <Text style={{ color: theme.colors.textSecondary }} as="P3">
              {`- $${discountedAmount}`}
            </Text>
          </OrderWrapper>
        )}
      </Wrapper>
      <PrimaryButton
        style={isDark ? { backgroundColor: theme.colors.black } : {}}
        disabled={disabled}
        loading={loading}
        onPress={onPress}
      >
        {btnText}
      </PrimaryButton>
    </Container>
  );
};

CheckoutRow.propTypes = {
  onPress: PropTypes.func,
  btnText: PropTypes.string.isRequired,
  totalAmount: PropTypes.number,
  discountedAmount: PropTypes.number,
  loading: PropTypes.bool,
  disabled: PropTypes.bool,
  isDark: PropTypes.bool
};
CheckoutRow.defaultProps = {
  totalAmount: 1850,
  discountedAmount: 0,
  onPress: () => {},
  loading: false,
  disabled: false,
  isDark: false
};
export default CheckoutRow;
