import React from 'react';
import { ActivityIndicator } from 'react-native';
import styled from 'styled-components/native';

const StyledView = styled.View`
  flex: 1;
  justify-content: center;
  flex-direction: row;
  padding: 10px;
`;

const LoadingIndicator = () => (
  <StyledView>
    <ActivityIndicator size="small" color="#000000" />
  </StyledView>
);

export default LoadingIndicator;
