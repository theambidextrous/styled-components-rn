import { showMessage } from 'react-native-flash-message';
import { theme } from '@utils';

const TriggerLocalNotification = ({
  message,
  type,
  icon,
  onPress,
  style,
  duration
}) => {
  const { colors } = theme;
  const color = (type === 'info' && colors.danger)
  || (type === 'error' && colors.danger)
  || (type === 'danger' && colors.danger)
  || (type === 'success' && colors.black)
  || colors.primary; // prettier-ignore

  showMessage({
    duration: duration || 1500,
    floating: true,
    message,
    backgroundColor: color,
    color: 'white',
    icon,
    style,
    onPress,
    position: 'bottom'
  });
};
export default TriggerLocalNotification;
