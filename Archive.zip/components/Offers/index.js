import TouchableTab from './TouchableTab';
import OffersFlatList from './OffersFlatList';

export { TouchableTab, OffersFlatList };
