import React, { useState } from 'react';
import Collapsible from 'react-native-collapsible';
import { StyleSheet, View, Platform } from 'react-native';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import Icon from 'react-native-vector-icons/FontAwesome';
import { useTheme } from 'styled-components';

import { theme, DEVICE_HEIGHT } from '@utils';
import Text from '../Text';
import { PrimaryButton } from '../Button';

const placeholderArtWork =
  'https://res.cloudinary.com/ds0w1lnot/image/upload/v1636726808/shutterstock_1159198297_qwasus.png'; // prettier-ignore

const OfferCard = ({ offer, OnActivatePressed, loading }) => {
  // console.log('offer', offer);
  const shopTheme = useTheme();
  const [isCollapsed, setisCollapsed] = useState(true);
  const toggleExpanded = () => {
    setisCollapsed(!isCollapsed);
  };

  return (
    <>
      <OfferImage
        resizeMode="cover"
        blurRadius={3}
        imageStyle={{ borderTopRightRadius: 10, borderTopLeftRadius: 10 }}
        source={{
          uri: offer.artwork ? offer.artwork : placeholderArtWork
        }}
      >
        <View
          style={[
            StyleSheet.absoluteFill,
            {
              backgroundColor: 'rgba(0, 0, 0, 0.4)',
              borderTopRightRadius: 10,
              borderTopLeftRadius: 10
            }
          ]}
        />
        <OfferDescriptionWrapper>
          <Text style={TextStyle.OfferTitle}>
            {offer.title.split(' ').slice(0, 3).join(' ')}
          </Text>
          {/* <Text style={TextStyle.OfferDescription}>
            For every $100 spent at starbucks
          </Text> */}
        </OfferDescriptionWrapper>
      </OfferImage>
      {/* {offer.active === true && (
        <ActivatedContainer>
          <Text style={TextStyle.ActivatedText}>Activated</Text>
        </ActivatedContainer>
      )} */}

      <Container
        style={{
          ...Platform.select({
            android: {
              borderColor: 'transparent', // Required to show shadows on Android for some reason !?!?
              shadowColor: '#000',
              shadowOffset: {
                width: 2,
                height: 2
              },
              shadowOpacity: 0.3,
              shadowRadius: 5,

              elevation: 3
            }
          })
        }}
      >
        <ToggleButton
          onPress={toggleExpanded}
          hitSlop={{ top: 50, bottom: 50, left: 50, right: 50 }}
        >
          <Text
            style={{
              fontSize: 14,
              lineHeight: 18,
              fontWeight: 'bold',
              textAlign: 'center',
              textTransform: 'capitalize',
              color: shopTheme.colors.primary || theme.colors.primary
            }}
          >
            {isCollapsed ? 'View Offer Details' : 'Hide Offer Details'}
          </Text>
          <ButtonIcon>
            {isCollapsed ? (
              <Icon
                name="chevron-down"
                size={14}
                color={shopTheme.colors.primary || theme.colors.primary}
              />
            ) : (
              <Icon
                name="chevron-up"
                size={12}
                color={shopTheme.colors.primary || theme.colors.primary}
              />
            )}
          </ButtonIcon>
        </ToggleButton>
        <Collapsible collapsed={isCollapsed} align="center">
          <CollapsibleView>
            <Text style={TextStyle.OfferText}>{offer.subtitle}</Text>
            {offer.active === false && offer.source === 'PCLO' && (
              <PrimaryButton
                onPress={() => OnActivatePressed(offer)}
                disabled={loading}
                loading={loading}
                loadingText="Activating"
              >
                Activate this Offer
              </PrimaryButton>
            )}

            {offer.active === true &&
              offer.source === 'SESSIONM_REWARD_STORE_OFFER' && (
                <PrimaryButton
                  onPress={() => OnActivatePressed(offer)}
                  disabled={loading}
                  loading={loading}
                  loadingText="Activating"
                >
                  Activate this Offer
                </PrimaryButton>
              )}

            {offer.active === true && offer.source === 'PCLO' && (
              <PrimaryButton hidden loading={loading} disabled={true}>
                Activated
              </PrimaryButton>
            )}

            {offer.active === null && (
              <PrimaryButton hidden disabled={true}>
                Activated
              </PrimaryButton>
            )}
          </CollapsibleView>
        </Collapsible>
      </Container>
    </>
  );
};
const OfferImage = styled.ImageBackground`
  width: 100%;
  min-height: ${DEVICE_HEIGHT * 0.165}px;
`;

const OfferDescriptionWrapper = styled.View`
  flex: 1;
  align-items: flex-end;
  justify-content: flex-end;
`;

const Container = styled.View`
  background-color: ${theme.colors.textWhite};
  box-shadow: 2px 2px 2px rgba(0, 0, 0, 0.1);
  padding: 13px 24px;
  border-bottom-right-radius: 10px;
  border-bottom-left-radius: 10px;
  margin-bottom: 20px;
`;

const CollapsibleView = styled.View``;

const ButtonIcon = styled.View`
  margin-left: 16px;
`;

const ToggleButton = styled.TouchableOpacity`
  flex-direction: row;
  align-items: center;
  justify-content: center;
`;

const TextStyle = StyleSheet.create({
  OfferTitle: {
    fontSize: 32,
    flexWrap: 'wrap',
    lineHeight: 40,
    textAlign: 'right',
    color: theme.colors.textWhite,
    paddingRight: 14,
    paddingLeft: 10,
    paddingTop: 6,
    marginBottom: 15
  },
  OfferDescription: {
    fontSize: 15,
    lineHeight: 20,
    textAlign: 'right',
    fontWeight: '400',
    color: theme.colors.textWhite,
    marginBottom: 15,
    paddingRight: 14
  },
  ActivatedText: {
    fontSize: 14,
    lineHeight: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    textTransform: 'capitalize',
    color: theme.colors.textWhite
  },
  OfferText: {
    fontSize: 14,
    lineHeight: 18,
    textAlign: 'left',
    marginTop: 16,
    marginBottom: 16,
    color: theme.colors.black
  }
});
OfferCard.propTypes = {
  offer: PropTypes.objectOf(PropTypes.any).isRequired,
  OnActivatePressed: PropTypes.func.isRequired,
  loading: PropTypes.bool.isRequired
};

export default OfferCard;
