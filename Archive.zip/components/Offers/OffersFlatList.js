import React from 'react';
import { FlatList } from 'react-native';
import PropTypes from 'prop-types';

import OfferCard from './OfferCard';

const FilterOffers = (offers) => offers;
const OffersFlatList = ({ offers, OnActivatePressed, loading }) => (
  <FlatList
    showsVerticalScrollIndicator={false}
    data={FilterOffers(offers)}
    renderItem={({ item }) => (
      <OfferCard
        offer={item}
        loading={loading}
        OnActivatePressed={OnActivatePressed}
      />
    )}
    onEndReachedThreshold={1}
    // onEndReached={fetchMore}
    numColumns={1}
    contentContainerStyle={{ paddingBottom: 50 }}
  />
);

OffersFlatList.propTypes = {
  offers: PropTypes.arrayOf(PropTypes.any).isRequired,
  OnActivatePressed: PropTypes.func.isRequired,
  loading: PropTypes.bool.isRequired
  // fetchMore: PropTypes.func.isRequired
};

export default OffersFlatList;
