import React from 'react';
import { Dimensions, StyleSheet } from 'react-native';
import styled from 'styled-components/native';
import { theme } from '@utils';
import PropTypes from 'prop-types';

const TouchableTab = ({ active, ActiveHandler }) => (
  <TouchableTabContainer>
    <TouchableTabHolder
      active={active === 1}
      onPress={() => ActiveHandler(1)}
      style={Jsx.TouchableTabLeft}
    >
      <TouchableTabText>New Offers</TouchableTabText>
    </TouchableTabHolder>
    <TouchableTabHolder
      active={active === 2}
      onPress={() => ActiveHandler(2)}
      style={Jsx.TouchableTabRight}
    >
      <TouchableTabText>Activated</TouchableTabText>
    </TouchableTabHolder>
  </TouchableTabContainer>
);

TouchableTab.propTypes = {
  active: PropTypes.number.isRequired,
  ActiveHandler: PropTypes.func.isRequired
};

const TouchableTabContainer = styled.View`
  height: 29px;
  width: ${Dimensions.get('screen').width * 0.9}px;
  margin-top: 15px;
  flex-direction: row;
`;
const TouchableTabHolder = styled.TouchableOpacity`
  flex: 1;
  height: 29px;
  justify-content: center;
  align-items: center;
  background-color: ${(props) => {
    if (props.active) {
      return theme.colors.primary;
    }
    return theme.colors.black;
  }};
`;
const TouchableTabText = styled.Text`
  font-size: 10px;
  color: ${theme.colors.textWhite};
  font-family: MarkOffcPro;
  font-weight: 700;
  line-height: 13px;
`;
const Jsx = StyleSheet.create({
  TouchableTabLeft: {
    borderTopLeftRadius: 15,
    borderBottomLeftRadius: 15
  },
  TouchableTabRight: {
    borderTopRightRadius: 15,
    borderBottomRightRadius: 15
  }
});

export default TouchableTab;
