import React, { useEffect, useRef } from 'react';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import { Animated, Modal, PanResponder } from 'react-native';

import { theme, DEVICE_HEIGHT } from '@utils';

const Overlay = styled.View`
  flex: 1;
  background-color: rgba(0, 0, 0, 0.3);
  justify-content: flex-end;
`;

const SliderIndicatorRow = styled.View`
  flex-direction: row;
  margin-bottom: 4px;
  align-items: center;
  justify-content: center;
`;

const SliderIndicator = styled.View`
  background-color: ${theme.colors.indicator};
  height: 5px;
  width: 45px;
  border-radius: 5px;
`;

const ContainerStyles = {
  backgroundColor: 'white',
  paddingTop: 12,
  paddingHorizontal: 12,
  borderTopRightRadius: 12,
  borderTopLeftRadius: 12,
  paddingBottom: 12,
  minHeight: 300,
  maxHeight: 450
};

const BottomSheet = ({ onDismiss, visible, children }) => {
  const screenHeight = DEVICE_HEIGHT;
  const panY = useRef(new Animated.Value(screenHeight)).current;

  const resetPositionAnim = Animated.timing(panY, {
    toValue: 0,
    duration: 300,
    useNativeDriver: true
  });

  const closeAnim = Animated.timing(panY, {
    toValue: screenHeight,
    duration: 500,
    useNativeDriver: true
  });

  const translateY = panY.interpolate({
    inputRange: [-1, 0, 1],
    outputRange: [0, 0, 1]
  });

  const handleDismiss = () => closeAnim.start(onDismiss);

  useEffect(() => {
    resetPositionAnim.start();
  }, [resetPositionAnim]);

  const panResponders = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => false,
      onPanResponderMove: Animated.event([null, { dy: panY }], {
        useNativeDriver: false
      }),
      onPanResponderRelease: (_, gs) => {
        if (gs.dy > 0 && gs.vy > 2) {
          return handleDismiss();
        }
        return resetPositionAnim.start();
      }
    })
  ).current;
  return (
    <Modal
      animated
      animationType="fade"
      visible={visible}
      transparent
      onRequestClose={handleDismiss}
    >
      <Overlay>
        <Animated.View
          style={{ ...ContainerStyles, transform: [{ translateY }] }}
          {...panResponders.panHandlers}
        >
          <SliderIndicatorRow>
            <SliderIndicator />
          </SliderIndicatorRow>
          {children}
        </Animated.View>
      </Overlay>
    </Modal>
  );
};

BottomSheet.defaultProps = {
  onDismiss: () => {}
};

BottomSheet.propTypes = {
  visible: PropTypes.bool.isRequired,
  children: PropTypes.node.isRequired,
  onDismiss: PropTypes.func
};

export default BottomSheet;
