import React, { useState, useEffect } from 'react';
import styled from 'styled-components/native';
import { Modal, Animated, Dimensions } from 'react-native';
import PropTypes from 'prop-types';

const StyledContainer = styled.View`
  flex: 1;
  background-color: rgba(46, 53, 50, 0.8);
  align-items: center;
`;

const StyledModalContainer = styled(Animated.View)`
  width: 85%;
  background-color: white;
  padding: 32px 35px;
  border-radius: 8px;
  elevation: 20;
  margin-top: ${Dimensions.get('screen').height / 5}px;
  justify-content: center;
`;

const ModalPopUp = ({ visible, children }) => {
  const [showModal, setShowModal] = useState(visible);
  const scaleValue = React.useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const toggleModal = () => {
      if (visible) {
        setShowModal(true);
        Animated.spring(scaleValue, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true
        }).start();
      } else {
        setShowModal(false);
      }
    };
    toggleModal();
  }, [visible, scaleValue]);

  return (
    <Modal transparent visible={showModal}>
      <StyledContainer>
        <StyledModalContainer style={[{ transform: [{ scale: scaleValue }] }]}>
          {children}
        </StyledModalContainer>
      </StyledContainer>
    </Modal>
  );
};

ModalPopUp.propTypes = {
  visible: PropTypes.bool.isRequired,
  children: PropTypes.node.isRequired
};

export default ModalPopUp;
