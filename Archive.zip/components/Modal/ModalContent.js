import React from 'react';
import styled from 'styled-components/native';
import PropTypes from 'prop-types';
import theme from '@utils/theme';

const successImage = require('@assets/images/others/success.png');

const StyledModalTitle = styled.Text`
  font-family: 'MontrealSerialBold';
  font-size: 30px;
  line-height: 36px;
  text-align: center;
  color: ${theme.colors.modalTextBlack};
  margin-bottom: 15px;
`;
const StyledModalSubTitle = styled.Text`
  font-family: 'MarkOffcPro';
  font-size: 16px;
  line-height: 20px;
  text-align: center;
  color: #4a4a4a;
  margin-bottom: 23px;
`;
const BorderLine = styled.View`
  border: 1px solid #f5f5f5;
`;
const ModalImage = styled.Image`
  height: 70px;
  width: 70px;
  align-self: center;
  margin: 23px 0;
`;

const ModalContent = ({ hideImage, title, message }) => (
  <>
    {!hideImage && <ModalImage source={successImage} />}
    <StyledModalTitle>{title}</StyledModalTitle>
    <StyledModalSubTitle>{message}</StyledModalSubTitle>
    <BorderLine />
  </>
);

ModalContent.defaultProps = {
  hideImage: false
};

ModalContent.propTypes = {
  title: PropTypes.string.isRequired,
  hideImage: PropTypes.bool,
  message: PropTypes.string.isRequired
};

export default ModalContent;
